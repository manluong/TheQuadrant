<?php
class Cosmos_Core_Team extends Cosmos_Core_Custom_Post_Model{

	private $post_type = 'cosmos_team';
	private $post_taxonomy = 'cosmos_team_cat';
	private $html_format;

	public function __construct(){
		$this->meta_attributes();
		$this->set_meta_attributes();
		$this->post_meta_prefix = $this->post_type . '_';
		$this->taxonomy_cat = $this->post_taxonomy;
		$this->html_format = $this->set_default_options();
	}
	public function meta_attributes(){
		$meta_atts = array(
			'information' => esc_html__('Information', 'pix-core'),
			'quote'       => esc_html__('Quote', 'pix-core'),
			'icon'        => esc_html__('Icon', 'pix-core'),
			'position'    => esc_html__('Position', 'pix-core'),
			'phone'       => esc_html__('Phone', 'pix-core'),
			'email'       => esc_html__('Email', 'pix-core'),
		);
		$this->post_meta_atts = array_merge($meta_atts, Cosmos_Core_Params::get( 'teammbox_social'));
	}
	public function set_meta_attributes(){
		$meta_arr = array();
		$meta_label_arr = array();
		foreach ( $this->post_meta_atts as $att => $name ){
			$key = $att;
			$meta_arr[$key] = '';
			$meta_label_arr[$key] = $name;
		}
		$this->post_meta_def = $meta_arr;
		$this->post_meta = $meta_arr;
		$this->post_meta_label = $meta_label_arr;
	}
	public function init( $atts = array(), $query_args = array() ){
		// set attributes
		$default_atts = array(
			'layout'       => 'team',
			'offset_post'  => '0',
			'limit_post'   => '-1',
			'sort_by'      => 'post__in',
			'category_slug'=> '',
			'column'       => '3',
			'team_id'      => '',
			'post_id'      => ''
		);
		$atts = array_merge( $default_atts, $atts );

		if ( $atts['team_id'] ){
			$atts['post_id'][0] = $atts['team_id'];
		} else{
			if ( $atts['method'] == 'cat' ){
				$atts['post_id'] = $this->parse_cat_slug_to_post_id(
					$this->taxonomy_cat,
					$atts['category_list'],
					$this->post_type
				);
			} elseif ( $atts['method'] == 'team' ){
				$atts['post_id'] = $this->parse_list_to_array( 'team_id', $atts['team_list'] );
			}
		}
		$this->attributes = $atts;

		// query
		$default_args = array(
			'post_type'=> $this->post_type,
		);
		$query_args = array_merge( $default_args, $query_args );
		// setting
		$this->setting( $query_args);
	}
	public function setting( $query_args ){
		if ( !isset( $this->attributes['uniq_id'] ) ){
			$this->attributes['uniq_id'] = $this->post_type . '-' .Cosmos_Core::make_id();
		}
		// query
		$this->query = $this->get_query( $query_args, $this->attributes );
		$this->post_count = 0;
		if ( $this->query->have_posts() ){
			$this->post_count = $this->query->post_count;
		}
		// image size
		$this->get_thumb_size();
		$this->set_responsive_class();
		$custom_css = $this->add_custom_css();
		if( $custom_css ) {
			do_action( COSMOS_CORE_ADD_INLINE_CSS, $custom_css );
		}
	}
	public function reset(){
		wp_reset_postdata();
	}
	public function add_custom_css(){
		$sc_id = $this->attributes['uniq_id'];
		$title_color       = $this->attributes['title_color'];
		$position_color    = $this->attributes['position_color'];
		$description_color = $this->attributes['description_color'];
		$icon_color        = $this->attributes['icon_color'];
		$icon_bg_color     = $this->attributes['icon_bg_color'];
		$side_color        = $this->attributes['side_color'];
		if (isset($this->attributes['dot_color'])) {
			$dot_color = $this->attributes['dot_color'];
		}
		if (isset($this->attributes['dot_hover_color'])) {
			$dot_hover_color = $this->attributes['dot_hover_color'];
		}
		if (isset($this->attributes['title_quote_color'])) {
			$title_quote_color = $this->attributes['title_quote_color'];
		}
		if (isset($this->attributes['title_quote_color'])) {
			$quote_color = $this->attributes['quote_color'];
		}
		$custom_css = '';
		if ( ! empty( $title_color ) ) {
		    $custom_css .= sprintf('.%1$s .team-wrap .slide-text .team-title {color: %2$s;}', esc_attr($sc_id), esc_attr($title_color) );
		}
		if ( ! empty( $position_color ) ) {
		    $custom_css .= sprintf('.%1$s .team-wrap .slide .slide-text .team-position {color: %2$s;}', esc_attr($sc_id), esc_attr($position_color) );
		}
		if ( ! empty( $description_color ) ) {
		    $custom_css .= sprintf('.%1$s .team-wrap .slide-text .team-descrition {color: %2$s;}', esc_attr($sc_id), esc_attr($description_color) );
		}
		if ( ! empty( $icon_color ) ) {
		    $custom_css .= sprintf('.%1$s .team-wrap .img-slide .team-link1 .social-icon {color: %2$s;}', esc_attr($sc_id), esc_attr($icon_color) );
		}
		if ( ! empty( $icon_bg_color ) ) {
		    $custom_css .= sprintf('.%1$s .team-wrap .slide .slide-text .team-link2:after {background-color: %2$s;}', esc_attr($sc_id), esc_attr($icon_bg_color) );
		}
		if ( ! empty( $side_color ) ) {
		    $custom_css .= sprintf('.%1$s .team-wrap .slide .slide-text .team-link2:before {background-color: %2$s;}', esc_attr($sc_id), esc_attr($side_color) );
		}
		if ( ! empty( $dot_color ) ){
			$custom_css .= sprintf( '.%1$s .section_team .owl-theme .owl-controls .owl-page span {background-color:%2$s}', esc_attr($sc_id), esc_attr($dot_color) );
		}
		if ( ! empty( $dot_hover_color ) ){
			$custom_css .= sprintf( '.%1$s .section_team .owl-theme .owl-controls .owl-page.active span, .%1$s .section_team .owl-theme .owl-controls .owl-page:hover span {background-color:%2$s}', esc_attr($sc_id), esc_attr($dot_hover_color) );
		}

		if ( ! empty( $title_quote_color ) ) {
		    $custom_css .= sprintf('.%1$s .section_team.style-1 .carousel-items .team-wrap .info-text .info-text-title {color: %2$s;}', esc_attr($sc_id), esc_attr($title_quote_color) );
		}
		if ( ! empty( $quote_color ) ) {
		    $custom_css .= sprintf('.%1$s .section_team.style-1 .carousel-items .team-wrap .info-text .info-text-content {color: %2$s;}', esc_attr($sc_id), esc_attr($quote_color) );
		}
		return $custom_css;
	}
	public function set_responsive_class( $atts = array() ){
		$class = '';
		$column= $this->attributes['column'];
		$def   = array(
			'1'=> 'column-1 col-xs-12',
			'2'=> 'column-2 col-lg-6 col-md-6 col-sm-6 col-xs-12',
			'3'=> 'column-3 col-lg-4 col-md-4 col-sm-6 col-xs-12',
			'4'=> 'column-4 col-lg-3 col-md-3 col-sm-6 col-xs-12',
		);

		if ( $column && isset($def[$column])){
			return $this->attributes['responsive-class'] = $def[$column];
		} else{
			return $this->attributes['responsive-class'] = $def['3'];
		}
	}
	public function set_default_options( $html_options = array() ){
		$defaults = array(
			'title_format'       => '<a href="%2$s"><p class="team-title" data-type="title">%1$s</p></a>',
			'position_format'    => '<span class="team-position" data-type="title">%1$s</span>',
			'description_format' => '<span class="team-descrition" data-type="title">%1$s</span>',
			'icon_format'        => '<i class="%1$s social-icon bg-non" aria-hidden="true"></i>',
			'image_format'       => '<a href="%2$s">%1$s</a>',
			'information_format' => '<span class="team-descrition" data-type="title">%1$s</span>',
			'title_quote_format' => '<span class="info-text-title" data-type="title">%1$s</span>',
			'quote_format'       => '<div class="info-text-content" data-type="content">“ %1$s ”</div>'
		);
		$html_options = array_merge( $defaults, $html_options );
		return $html_options;
	}
	public function get_thumb_size(){
		$params = Cosmos_Core_Params::get( 'block_image_size', $this->attributes['layout'] );
		$this->attributes['thumb-size'] = Cosmos_Core_Util::get_thumb_size( $params, $this->attributes );
	}

	/****************/
	/*  RENDER HTML **********************************************************/
	/****************/
    public function render_sc( $html_options = array() )
    {
        /*
            %1$s is image
	        %2$s is title
	        %3$s is position
	        %4$s is information
            %5$s is icon
            %6$s is social
            %7$s is quote
        */
    	$html_options['thumb_class'] = 'img-responsive img-full';
    	$html_options['title_format'] = '<a href="%2$s"><p class="team-title" data-type="title">%1$s</p></a>';
    	$html_options['image_format'] = '<a href="%2$s">%1$s</a>';
        $this->html_format = $this->set_default_options( $html_options );
        if ( $this->query->have_posts() ) {
            while ( $this->query->have_posts() ) {
                $this->query->the_post();
                $this->loop_index();
                printf( $html_options['html_format'],
                    $this->get_featured_image($html_options),
                    $this->get_title($html_options),
                    $this->get_meta_position($html_options),
                    $this->get_meta_information(),
                    $this->get_meta_icon(),
                    $this->get_social(),
                    $this->get_meta_quote()
                );
            }
            $this->reset();
        }
    }

    public function render_team_list( $html_options = array() )
    {
        /*
            %1$s is image
	        %2$s is title
	        %3$s is position
	        %4$s is information
            %5$s is icon
            %6$s is social
            %7$s is column
        */
    	$html_options['thumb_class'] = 'img-responsive img-full';
    	$html_options['title_format'] = '<a href="%2$s"><p class="team-title" data-type="title">%1$s</p></a>';
    	$html_options['image_format'] = '<a href="%2$s">%1$s</a>';
        $this->html_format = $this->set_default_options( $html_options );
        if ( $this->query->have_posts() ) {
            while ( $this->query->have_posts() ) {
                $this->query->the_post();
                $this->loop_index();
                printf( $html_options['html_format'],
                    $this->get_featured_image($html_options),
                    $this->get_title($html_options),
                    $this->get_meta_position($html_options),
                    $this->get_meta_information(),
                    $this->get_meta_icon(),
                    $this->get_social(),
                    $this->set_responsive_class()
                );
            }
			$this->reset();
			if( $this->attributes['pagination'] == 'yes' ) {	
				echo Cosmos_Core_Pagination::paging_nav( $this->query->max_num_pages, 2, $this->query);
			}
        }
    }



	/*******************/
	/* FUNCTION CUSTOM **********************************************************/
	/*******************/
	public function get_current_category(){
		$term   = $this->get_current_taxonomy( $this->taxonomy_cat );
		$format = $this->html_format['category_format'];

		$out    = '';
		if ( $term ){
			$out = sprintf( $format, esc_html( $term['name'] ) );
		}
		return $out;
	}
	public function get_meta_position(){
		$format = '%1$s';
		if ( isset($this->html_format['position_format']) ){
			$format = $this->html_format['position_format'];
		}
		$val = $this->post_meta['position'];

		$out = '';
		if ( !empty($val) ){
			$out = sprintf( $format, esc_html( $val ) );
		}
		return $out;
	}
	public function get_meta_phone(){
		$format = $this->html_format['phone_format'];
		$phone  = $this->post_meta['phone'];
		$phoneRe= str_replace(' ', '', $phone);
		if ( empty( $phone ) ){
			return '';
		}
		$out = sprintf( $format, esc_html($phone), esc_html($phoneRe) );
		return $out;
	}
	public function get_meta_email(){
		$format = $this->html_format['email_format'];
		$out    = $this->post_meta['email'];
		if ( empty( $out ) ){
			return '';
		}
		$out = sprintf( $format, esc_html($out) );
		return $out;
	}
	public function get_image_featured() {

	}
	public function get_meta_icon() {
		$format = '%1$s';
		if ( isset($this->html_format['icon_format']) ){
			$format = $this->html_format['icon_format'];
		}
		$val = $this->post_meta['icon'];

		$out = '';
		if ( !empty($val) ){
			$out = sprintf( $format, esc_html( $val ) );
		}
		return $out;
	}
	public function get_meta_quote() {
		//quote_format
		$format = $format_title = '%1$s';
		if ( isset($this->html_format['quote_format']) ){
			$format = $this->html_format['quote_format'];
		}
		if ( isset($this->html_format['title_quote_format']) ){
			$format_title = $this->html_format['title_quote_format'];
		}
		$val = $this->post_meta['quote'];
		$out = '';
		if(!empty($this->attributes['title_quote_text'])) {
			$out .= sprintf( $format_title, esc_html( $this->attributes['title_quote_text'] ) );
		}
		if ( !empty($val) ){
			if((int)($this->attributes['quote_length']) > 0){
				$val = wp_trim_words($val,(int)($this->attributes['quote_length']));
			}
			$out .= sprintf( $format, esc_html( $val ) );
		}
		return $out;
	}

	public function get_meta_information(){
		$format = '%1$s';
		if ( isset($this->html_format['information_format']) ){
			$format = $this->html_format['information_format'];
		}
		$val = $this->post_meta['information'];
		$out = '';
		if ( !empty($val) ){
			if((int)($this->attributes['description_length']) > 0){
				$val = wp_trim_words($val,(int)($this->attributes['description_length']));
			}
			$out = sprintf( $format, esc_html( $val ) );
		}
		return $out;
	}
	public function get_social(){
		$out    = '';
		$format = '<a href="%2$s" class="row-edit social-item"><i class="fa fa-%1$s social-icon" aria-hidden="true"></i></a>';
		if ( isset($this->html_format['social_format']) ){
			$format = $this->html_format['social_format'];
		}
		$social_group = Cosmos_Core_Params::teammbox_social();
		
		foreach ( $social_group as $social => $social_text ){
			$href = $this->post_meta[$social];
			if ( !empty($href) ){
				
				$href = $this->post_meta[$social];
				$out .= sprintf( $format, esc_attr( $social ), esc_url( $href ) );
			}
			
		}
		return $out;
	}

}