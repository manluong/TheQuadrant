<?php

$video_id = esc_attr( $id );
$video_type = esc_attr($source);
$video_info_id = 'video_info_' . esc_attr( $id );
$video_button_id = 'video_button_id_' . esc_attr( $id );
$video_player_id = 'video_player_id' . esc_attr( $id );
$video_src = null;
$button_html = '';
$video_html = '';

$uniq_id = 'sc-video-'.esc_attr( $id );
$custom_css = '';

$image_background = wp_get_attachment_image_src($image_background, 'full', false);
if ( ! empty ($image_background) ) { 
    $image_src = $image_background[0];
    $image_width = $image_background[1];
    $image_height = $image_background[2];
} else {
    $image_src = NULL;
    $image_width = NULL;
    $image_height = NULL;
}

if( ! empty( $title_color ) ){
    $custom_css .= '.%1$s.sc-video .video-container .video-text .main-title {color:%2$s;}' ."\n";
}
if( ! empty( $sub_title_color ) ){
    $custom_css .= '.%1$s.sc-video .video-container .video-text .sub-title {color:%3$s;}' ."\n";
}
if( ! empty( $description_color ) ){
    $custom_css .= '.%1$s.sc-video .video-container .video-text .description {color:%4$s;}' ."\n";
}
if( ! empty( $button_color ) ){
    $custom_css .= '.%1$s.sc-video .video-container button.button-play {color:%5$s; border:solid 1px %5$s;}' ."\n";
}
if( ! empty( $button_hover_color ) ){
    $custom_css .= '.%1$s.sc-video .video-container button.button-play:hover {color:%6$s; border:solid 1px %6$s;}' ."\n";
}
if( ! empty( $image_src ) ){
    $custom_css .= '.%1$s.sc-video .video-container .video-info {background-image:url("%7$s");}' ."\n";
}
if( ! empty( $height_video ) ){
    $custom_css .= '@media screen and (min-width: 768px) { .%1$s.sc-video .video-container { height:%8$s; } }' ."\n";
}

if ( ! empty( $custom_css ) ) {
    $custom_css = sprintf($custom_css,
            esc_attr($uniq_id),
            esc_attr($title_color),
            esc_attr($sub_title_color),
            esc_attr($description_color),
            esc_attr($button_color),
            esc_attr($button_hover_color),
            esc_attr($image_src),
            esc_attr($height_video)
            );
    do_action( COSMOS_CORE_ADD_INLINE_CSS, $custom_css );
}

switch ($video_type) {
    case 'youtube':
        if ( ! empty($youtube_id) ) {
            $video_src = "https://www.youtube.com/embed/" . esc_attr($youtube_id) . "?enablejsapi=1&showinfo=0";
            $video_html = '';
        }
        break;
    case 'video':
        if ( ! empty($video_upload) ) {
            $video_src = wp_get_attachment_url($video_upload);
            $video_html = '';
        }
    default:
        # code...
        break;
}
$button_format = '<button class="button-play" id="%1$s" data-video-id="%2$s" data-info-id="%3$s" data-player-id="%4$s" data-button-id="%5$s" data-type="%6$s"><i class="fa fa-play" aria-hidden="true"></i></button>';
$button_html = sprintf($button_format,
        esc_attr($video_button_id),
        esc_attr($video_id),
        esc_attr($video_info_id),
        esc_attr($video_player_id), 
        esc_attr($video_button_id),
        esc_attr($video_type)
        );
?>
<div class="pix-shortcode sc-video <?php echo esc_attr($uniq_id).' '.esc_attr( $extra_class )?> animate-run" data-animate="<?php echo esc_attr($css_animation); ?>" data-delay="<?php echo (int) esc_attr($delay_animation); ?>">
<?php if( ! empty($video_src) ) { ?>
    <div class="video-container">
        <div class="video-info" 
                id="<?php echo esc_attr($video_info_id) ?>" 
                data-video-id="<?php echo esc_attr($video_id) ?>" 
                data-info-id="<?php echo esc_attr($video_info_id) ?>" 
                data-player-id="<?php echo esc_attr($video_player_id) ?>" 
            >
            <div class="video-text">
                <?php if ($button_position == 'on') { echo ($button_html); } ?> 
                <?php if ( ! empty ($sub_title) ) { ?> 
                    <h2 class="sub-title"><?php echo esc_html($sub_title) ?></h2>
                <?php } ?>
                <?php if ( ! empty ($title) ) { ?> 
                    <h1 class="main-title"><?php echo esc_html($title) ?></h1>
                <?php } ?>
                <?php if ( ! empty ($description) ) { ?> 
                    <p class="description hidden-xs"><?php echo wp_kses_post($description) ?></p>
                <?php } ?>
                <?php if ($button_position == 'under') { echo ($button_html); } ?> 
            </div>
        </div>
        <div class="video-scource">
            <?php if ($video_type == 'youtube') { ?>
               <iframe frameborder="0" allowfullscreen="" class="video-full-width" 
                    src="<?php echo esc_attr($video_src) ?>" 
                    id="<?php echo esc_attr($video_id) ?>" 
                    data-video-id="<?php echo esc_attr($video_id) ?>" 
                    data-info-id="<?php echo esc_attr($video_info_id) ?>" 
                    data-player-id="<?php echo esc_attr($video_player_id) ?>" 
                ></iframe>
            <?php } else { ?>
                <video loop class="video-full-width" 
                    id="<?php echo esc_attr($video_id) ?>" 
                    data-video-id="<?php echo esc_attr($video_id) ?>" 
                    data-info-id="<?php echo esc_attr($video_info_id) ?>" 
                    data-player-id="<?php echo esc_attr($video_player_id) ?>" >
                    <source src="<?php echo esc_attr($video_src) ?>" type='video/mp4'>
                </video>
            <?php } ?>
        </div>
    </div>
 <?php } ?>
</div>