<?php
$model = new Cosmos_Core_Team();
$model->init( $atts );
$custom_css = "";
$sc_name    = 'team-list';
$sc_id      = $model->attributes['uniq_id'];
$block_class= $atts['extra_class'] . ' ' . $sc_id;

$css_animation = '';
$css_animation_class = '';
$delay_animation = 0;
$css_animation_parent = '';
$css_animation_parent_class = '';
$delay_animation_parent = 0;

if ( !empty($model->attributes['css_animation']) && !empty($model->attributes['is_parent_animation']) && $model->attributes['is_parent_animation'] != 'yes') {
	$css_animation = $model->attributes['css_animation'];
	$css_animation_class = 'animate-run';
	$delay_animation = (int) $model->attributes['delay_animation'];
}

if ( !empty($model->attributes['css_animation']) && !empty($model->attributes['is_parent_animation']) && $model->attributes['is_parent_animation'] == 'yes') {
	$css_animation_parent = $model->attributes['css_animation'].'-children';
	$css_animation_parent_class = 'animate-run';
	$delay_animation_parent = (int) $model->attributes['delay_animation'];
}


$column            = $model->attributes['column'];
$title_color       = $model->attributes['title_color'];
$position_color    = $model->attributes['position_color'];
$description_color = $model->attributes['description_color'];
$icon_color        = $model->attributes['icon_color'];
$icon_bg_color     = $model->attributes['icon_bg_color'];
$side_color        = $model->attributes['side_color'];

?>

<div class="pix-shortcode <?php echo esc_attr("sc-$sc_name");?> <?php  echo esc_attr($block_class) ?> <?php echo esc_attr($css_animation_class); ?>"  data-animate="<?php echo esc_attr($css_animation); ?>" data-delay="<?php echo esc_attr($delay_animation); ?>" data-id="<?php echo esc_attr($sc_id);?>">
	<div class="section_team style-2 row-eq-height flex-wrap <?php echo esc_attr($css_animation_parent_class);?>" data-animate="<?php echo esc_attr($css_animation_parent); ?>" data-delay="<?php echo esc_attr($delay_animation_parent); ?>">
		<?php 
			/*
				%1$s is image
		        %2$s is title
		        %3$s is position
		        %4$s is information
		        %5$s is icon
		        %6$s is social
		        %7$s is column
			*/
			$html_format = ('
					<div class="team-wrap %7$s">
					    <div class="slide slide-center col-lg-3 padding0">
					        <div class="img-slide">
				              	%1$s
				            	<div class="team-link1">%5$s</div>
					        </div>
					        <div class="slide-text">
					            %2$s
					            %3$s
					            %4$s
					          	<div class="social-group">%6$s</div>
					          	<div class="team-link2"></div>
					        </div>
					    </div>
					</div>
					');
			$html_option = array(
					'html_format' => $html_format
				);
			$model->render_team_list($html_option);
		?>
	</div>
</div>