<?php
$sc_controller = new Cosmos_Core_Shortcodes_Controller();
$style = array(
	esc_html__( 'Style 1', 'pix-core' ) => '1',
	esc_html__( 'Style 2', 'pix-core' ) => '2',
);
$contact_form_arr = array(esc_html__( '-None-', 'slzexploore-core' ) => '');
$args = array (
			'post_type'     => 'wpcf7_contact_form',
			'post_per_page' => -1,
			'status'        => 'publish',
			'suppress_filters' => false,
		);
$post_arr = get_posts( $args );
foreach( $post_arr as $post ){
	$k = ( !empty( $post->post_title ) )? $post->post_title : $post->post_name;
	$contact_form_arr[$k] =  $post->ID ;
}
$params = array(
	array(
		'type'        => 'dropdown',
		'admin_label' => true,
		"class"       => "",
		'heading'     => esc_html__( 'Style Contact Form', 'pix-core' ),
		'param_name'  => 'style',
		'value'       => $style,
		'description' => esc_html__( 'Select style contact form.',  'pix-core'  )
	),
	array(
		'type'        => 'dropdown',
		'heading'     => esc_html__( 'Contact Form', 'pix-core' ),
		'param_name'  => 'contact_form',
		'value'       => $contact_form_arr,
		'description' => esc_html__( 'Choose contact form to display contact page.', 'pix-core' )
	),
	array(
		'type'        => 'textfield',
		'heading'     => esc_html__( 'Block title', 'pix-core' ),
		'param_name'  => 'title',
		'description' => esc_html__( 'Please input title to show.', 'pix-core' ),
		'dependency'  => array(
			'element' 	=> 'style',
			'value'   	=> array('2')
		),
	),
	array(
		'type'        => 'textarea',
		'heading'     => esc_html__( 'Description', 'pix-core' ),
		'param_name'  => 'description',
		'value'       => '',
		'description' => esc_html__( 'Enter description.', 'pix-core' ),
		'dependency'  => array(
			'element'   => 'style',
			'value'     => array('2')
		),
	),
	array(
		'type'       => 'param_group',
		'heading'    => esc_html__( 'Icon Content', 'pix-core' ),
		'param_name' => 'icon_data',
		'callbacks'   => array(
		   'after_add' => 'vcChartParamAfterAddCallback'
		),
		'params'     => array(
			array(
				'type'       => 'iconpicker',
				'heading'    => esc_html__( 'Choose icon', 'pix-core' ),
				'param_name' => 'icon_url',
				'description'=> esc_html__( 'Please choose icon to show', 'pix-core' ),
			),
			array(
				'type'       => 'textfield',
				'holder'     => 'div',
				'heading'    => esc_html__( 'Icon Title', 'pix-core' ),
				'param_name' => 'icon_title',
				'admin_label'=> true,
				'description'=> esc_html__( 'Please input icon title to show.', 'pix-core' ),
			),
			array(
				'type'       => 'textarea',
				'holder'     => 'div',
				'heading'    => esc_html__( 'Icon Description', 'pix-core' ),
				'param_name' => 'icon_description',
				'description'=> esc_html__( 'Please enter the icon description', 'pix-core' ),
			),
		)
	),
	array(
		'type'       => 'colorpicker',
		'heading'    => esc_html__( 'Title Color', 'pix-core' ),
		'param_name' => 'title_color',
		'description'=> esc_html__( 'Choose color for Title', 'pix-core' ),
		'group'      => esc_html__( 'Custom', 'pix-core' ),
		'dependency'  => array(
			'element' 	=> 'style',
			'value'   	=> array('2')
		),
	),
	array(
		"type"        => "colorpicker",
		"heading"     => esc_html__( "Description Color", 'pix-core' ),
		"param_name"  => "description_color",
		"description" => esc_html__( "Choose description color.", 'pix-core' ),
		'group'       => esc_html__('Custom', 'pix-core'),
		'dependency'  => array(
			'element' 	=> 'style',
			'value'   	=> array('2')
		),
	),
	array(
		'type'       => 'colorpicker',
		'heading'    => esc_html__( 'Input Color', 'pix-core' ),
		'param_name' => 'input_color',
		'description'=> esc_html__( 'Choose color for input', 'pix-core' ),
		'group'      => esc_html__( 'Custom', 'pix-core' ),
	),
	array(
		'type'       => 'colorpicker',
		'heading'    => esc_html__( 'Input Placeholder Color', 'pix-core' ),
		'param_name' => 'placeholder_color',
		'description'=> esc_html__( 'Choose color for input placeholder', 'pix-core' ),
		'group'      => esc_html__( 'Custom', 'pix-core' ),
	),
	array(
		'type'       => 'colorpicker',
		'heading'    => esc_html__( 'Input Background Color', 'pix-core' ),
		'param_name' => 'input_bg_color',
		'description'=> esc_html__( 'Choose color for input background', 'pix-core' ),
		'group'      => esc_html__( 'Custom', 'pix-core' ),
	),
	array(
		'type'       => 'colorpicker',
		'heading'    => esc_html__( 'Input Border Color', 'pix-core' ),
		'param_name' => 'input_border_color',
		'description'=> esc_html__( 'Choose color for input border', 'pix-core' ),
		'group'      => esc_html__( 'Custom', 'pix-core' ),
	),
	array(
		'type'       => 'colorpicker',
		'heading'    => esc_html__( 'Button Text Color', 'pix-core' ),
		'param_name' => 'button_text_color',
		'group'      => esc_html__( 'Custom', 'pix-core' ),
	),
	array(
		'type'       => 'colorpicker',
		'heading'    => esc_html__( 'Button Color', 'pix-core' ),
		'param_name' => 'button_color',
		'group'      => esc_html__( 'Custom', 'pix-core' ),
	),
	array(
		'type'       => 'colorpicker',
		'heading'    => esc_html__( 'Button Text Color On Hover', 'pix-core' ),
		'param_name' => 'button_text_hover_color',
		'group'      => esc_html__( 'Custom', 'pix-core' ),
	),
	array(
		'type'       => 'colorpicker',
		'heading'    => esc_html__( 'Button Color On Hover', 'pix-core' ),
		'param_name' => 'button_hover_color',
		'group'      => esc_html__( 'Custom', 'pix-core' ),
	),
	array(
		'type'       => 'colorpicker',
		'heading'    => esc_html__( 'Error Color', 'pix-core' ),
		'param_name' => 'error_color',
		'description'=> esc_html__( 'Choose Color for error.', 'pix-core' ),
		'group'      => esc_html__( 'Custom', 'pix-core' )
	),
	array(
		'type'       => 'colorpicker',
		'heading'    => esc_html__( 'Form Background Color', 'pix-core' ),
		'param_name' => 'form_bg_color',
		'description'=> esc_html__( 'Choose color for input', 'pix-core' ),
		'group'      => esc_html__( 'Custom', 'pix-core' ),
		'dependency'    => array(
			'element'=> 'style',
			'value'         => array( '2' )
		),
	),
	array(
		"type"        => "colorpicker",
		"class"       => "",
		"heading"     => esc_html__( "Icon Color", 'pix-core' ),
		"param_name"  => "icon_color",
		"description" => esc_html__( "Choose the icon color.", 'pix-core' ),
		'group'       => esc_html__('Custom Icon', 'pix-core'),
		'dependency'    => array(
			'element'=> 'style',
			'value'         => array( '2' )
		),
	),
	array(
		"type"        => "colorpicker",
		"class"       => "",
		"heading"     => esc_html__( "Background Icon Color", 'pix-core' ),
		"param_name"  => "icon_bg_color",
		"description" => esc_html__( "Choose color for background icon.", 'pix-core' ),
		'group'       => esc_html__('Custom Icon', 'pix-core'),
		'dependency'    => array(
			'element'=> 'style',
			'value'         => array( '2' )
		),
	),
	array(
		'type'       => 'colorpicker',
		'heading'    => esc_html__( 'Icon Title Color', 'pix-core' ),
		'param_name' => 'icon_title_color',
		'description'=> esc_html__( 'Choose color for title', 'pix-core' ),
		'group'      => esc_html__( 'Custom Icon', 'pix-core' ),
		'dependency'    => array(
			'element'=> 'style',
			'value'         => array( '2' )
		),
	),
	array(
		'type'       => 'colorpicker',
		'heading'    => esc_html__( 'Icon Description Color', 'pix-core' ),
		'param_name' => 'icon_description_color',
		'description'=> esc_html__( 'Choose color for description', 'pix-core' ),
		'group'      => esc_html__( 'Custom Icon', 'pix-core' ),
		'dependency'    => array(
			'element'=> 'style',
			'value'         => array( '2' )
		),
	),
	array(
		"type"        => "colorpicker",
		"class"       => "",
		"heading"     => esc_html__( "Background Sidebar Icon Color", 'pix-core' ),
		"param_name"  => "side_icon_bg_color",
		"description" => esc_html__( "Choose color for background sidebar icon.", 'pix-core' ),
		'group'       => esc_html__('Custom Icon', 'pix-core'),
		'dependency'    => array(
			'element'=> 'style',
			'value'         => array( '2' )
		),
	),
	array(
		'type'           => 'textfield',
		'heading'        => esc_html__( 'Extra Class', 'pix-core' ),
		'param_name'     => 'extra_class',
		'description'    => esc_html__( 'Enter extra class name.', 'pix-core' ),
	),
	$sc_controller->cosmos_animation_style(),
	$sc_controller->cosmos_animation_delay(),


);
$base = 'pixcore_contact_form_sc';
vc_map(array(
	'name'       => esc_html__( 'PIX Contact Form', 'pix-core' ),
	'base'       => $base,
	'class'      => 'pixcore-sc',
	'icon'       => 'icon-'.$base,
	'category'   => COSMOS_CORE_SC_CATEGORY,
	'description'=> esc_html__( 'Contact Form Of Block', 'pix-core' ),
	'params'     => $params
));