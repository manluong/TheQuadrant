<?php
/**
 * Controller Top.
 * 
 * @since 1.0
 */
Cosmos_Core::load_class( 'Abstract' );

class Cosmos_Core_Top_Controller extends Cosmos_Core_Abstract {

	// share post
	public function get_share_link( $args = array()) {
		$this->render( 'share_link', array( 'args' => $args ));
	}
	
	// team list in archive page
	public function show_team_list( $args = array() ) {
		$column = 3;
		if( isset( $args['has_sidebar'] ) && $args['has_sidebar'] != 'none' ){
			$column = 2;
		}
		$limit_post = get_option('posts_per_page');
		$currentObject = get_queried_object();
		$category_slug = '';
		if ( is_tax('cosmos_team_cat') ) {
			$category_slug = $currentObject->slug;
		}
		$shortcode = sprintf( '[pixcore_team_list_sc column="%1$s" pagination="yes" limit_post="%2$s" category_slug="%3$s"]',
								esc_attr( $column ),
								esc_attr( $limit_post ),
								esc_attr( $category_slug )
							);
		echo do_shortcode( $shortcode );
	}

}