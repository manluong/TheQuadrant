<?php
$sc_controller = new Cosmos_Core_Shortcodes_Controller();
$style = array(
	esc_html__('Style 1', 'pix-core')		=> '1',
	esc_html__('Style 2', 'pix-core')		=> '2',
	esc_html__('Style 3', 'pix-core')		=> '3',
	esc_html__('Style 4', 'pix-core')		=> '4',
	esc_html__('Style 5', 'pix-core')		=> '5',
);

$params = array(
	array(
		'type'       => 'dropdown',
		'heading'    => esc_html__( 'Style', 'pix-core' ),
		'param_name' => 'style',
		'value'      => $style,
		'admin_label'=> true,
		'std'        => '1',
		'description'=> esc_html__( 'Choose style to show.', 'pix-core' )
	),
	array(
		'type'       => 'iconpicker',
		'heading'    => esc_html__( 'Choose icon', 'pix-core' ),
		'param_name' => 'icon',
		'description'=> esc_html__( 'Please choose icon to show', 'pix-core' ),
	),
	array(
		'type'       => 'textfield',
		'heading'    => esc_html__( 'Title', 'pix-core' ),
		'param_name' => 'title',
		'admin_label'=> true,
		'description'=> esc_html__( 'Please input title to show.', 'pix-core' ),
	),
	array(
		'type'       => 'textarea',
		'heading'    => esc_html__( 'Description', 'pix-core' ),
		'param_name' => 'description',
		'description'=> esc_html__( 'Please enter the description', 'pix-core' ),
	),
	array(
		'type'       => 'textfield',
		'heading'    => esc_html__( 'Height Box', 'pix-core' ),
		'param_name' => 'height',
		'description'=> esc_html__( 'Set height for icon box. Unit is px, input only number. Exam: 20', 'pix-core' ),
	),
	array(
		'type'       => 'colorpicker',
		'heading'    => esc_html__( 'Icon color', 'pix-core' ),
		'param_name' => 'icon_color',
		'description'=> esc_html__( 'Choose color for Icon', 'pix-core' ),
		'group'      => esc_html__( 'Custom', 'pix-core' ),
	),
	array(
		'type'       => 'colorpicker',
		'heading'    => esc_html__( 'Icon color Hover', 'pix-core' ),
		'param_name' => 'icon_hover_color',
		'description'=> esc_html__( 'Choose color for icon when hover', 'pix-core' ),
		'group'      => esc_html__( 'Custom', 'pix-core' ),
	),
	array(
		'type'       => 'colorpicker',
		'heading'    => esc_html__( 'Title Color', 'pix-core' ),
		'param_name' => 'title_color',
		'description'=> esc_html__( 'Choose color for title', 'pix-core' ),
		'group'      => esc_html__( 'Custom', 'pix-core' ),
	),
	array(
		'type'       => 'colorpicker',
		'heading'    => esc_html__( 'Title Color Hover', 'pix-core' ),
		'param_name' => 'title_hover_color',
		'description'=> esc_html__( 'Choose color for title when hover', 'pix-core' ),
		'group'      => esc_html__( 'Custom', 'pix-core' ),
	),
	array(
		'type'       => 'colorpicker',
		'heading'    => esc_html__( 'Description Color', 'pix-core' ),
		'param_name' => 'description_color',
		'description'=> esc_html__( 'Choose color for description', 'pix-core' ),
		'group'      => esc_html__( 'Custom', 'pix-core' ),
	),
	array(
		'type'       => 'colorpicker',
		'heading'    => esc_html__( 'Description Color Hover', 'pix-core' ),
		'param_name' => 'description_hover_color',
		'description'=> esc_html__( 'Choose color for description when hover', 'pix-core' ),
		'group'      => esc_html__( 'Custom', 'pix-core' ),
	),
	array(
		'type'       => 'colorpicker',
		'heading'    => esc_html__( 'Border Color', 'pix-core' ),
		'param_name' => 'border_color',
		'description'=> esc_html__( 'Choose color for border', 'pix-core' ),
		'group'      => esc_html__( 'Custom', 'pix-core' ),
	),
	array(
		'type'       => 'colorpicker',
		'heading'    => esc_html__( 'Boder Color Hover', 'pix-core' ),
		'param_name' => 'border_hover_color',
		'description'=> esc_html__( 'Choose color for border when hover', 'pix-core' ),
		'group'      => esc_html__( 'Custom', 'pix-core' ),
	),
	array(
		'type'       => 'colorpicker',
		'heading'    => esc_html__( 'Background Icon Color', 'pix-core' ),
		'param_name' => 'bg_icon_color',
		'description'=> esc_html__( 'Choose color for background of icon', 'pix-core' ),
		'group'      => esc_html__( 'Custom', 'pix-core' ),
		'dependency'    => array(
			'element'		=> 'style',
			'value'         => array( '2', '3', '5' )
		),
	),
	array(
		'type'       => 'colorpicker',
		'heading'    => esc_html__( 'Background Icon Color Hover', 'pix-core' ),
		'param_name' => 'bg_hover_color',
		'description'=> esc_html__( 'Choose color for background of icon when hover', 'pix-core' ),
		'group'      => esc_html__( 'Custom', 'pix-core' ),
		'dependency'    => array(
			'element'		=> 'style',
			'value'         => array( '2', '3' )
		),
	),
	array(
		'type'       => 'colorpicker',
		'heading'    => esc_html__( 'Background Color', 'pix-core' ),
		'param_name' => 'bg_color',
		'description'=> esc_html__( 'Choose color for background', 'pix-core' ),
		'group'      => esc_html__( 'Custom', 'pix-core' ),
		'dependency'    => array(
			'element'		=> 'style',
			'value'         => array( '4', '5' )
		),
	),
	array(
		'type'       => 'colorpicker',
		'heading'    => esc_html__( 'Line Color', 'pix-core' ),
		'param_name' => 'line_color',
		'description'=> esc_html__( 'Choose color for line', 'pix-core' ),
		'group'      => esc_html__( 'Custom', 'pix-core' ),
		'dependency'    => array(
			'element'		=> 'style',
			'value'         => array( '4' )
		),
	),
	array(
		'type'           => 'textfield',
		'heading'        => esc_html__( 'Extra Class', 'pix-core' ),
		'param_name'     => 'extra_class',
		'description'    => esc_html__( 'Enter extra class name.', 'pix-core' ),
	),
	$sc_controller->cosmos_animation_style(),
	$sc_controller->cosmos_animation_delay(),

);
vc_map(array(
	'name'       => esc_html__( 'PIX Icon Box', 'pix-core' ),
	'base'       => 'pixcore_icon_box_sc',
	'class'      => 'pixcore-sc',
	'icon'       => 'icon-pixcore_icon_box_sc',
	'category'   => COSMOS_CORE_SC_CATEGORY,
	'description'=> esc_html__( 'Icon Box Of Block', 'pix-core' ),
	'params'     => $params
));