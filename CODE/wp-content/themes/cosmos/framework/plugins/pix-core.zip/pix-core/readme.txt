== PixCore ==
Contributors: pixartthemes
Tags: custom post type, shortcode, metabox.

PixCore plugin compatible with Cosmos Wordpress template.

Thanks for your support and feel free to contact us any time. 
Our support forum is here:

http://support.pixartthemes.com/