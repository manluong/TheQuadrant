<?php
class Cosmos_Core_Faq extends Cosmos_Core_Custom_Post_Model{

	private $post_type = 'cosmos_faq';
	private $post_taxonomy = 'cosmos_faq_cat';
	private $html_format;

	public function __construct(){
		$this->meta_attributes();
		$this->set_meta_attributes();
		$this->post_meta_prefix = $this->post_type . '_';
		$this->taxonomy_cat = $this->post_taxonomy;
		$this->html_format = $this->set_default_options();
	}
	public function meta_attributes(){
		$this->post_meta_atts = array(
			
		);
	}
	public function set_meta_attributes(){
		$meta_arr = array();
		$meta_label_arr = array();
		foreach ( $this->post_meta_atts as $att => $name ){
			$key = $att;
			$meta_arr[$key] = '';
			$meta_label_arr[$key] = $name;
		}
		$this->post_meta_def = $meta_arr;
		$this->post_meta = $meta_arr;
		$this->post_meta_label = $meta_label_arr;
	}
	public function init( $atts = array(), $query_args = array() ){
		// set attributes
		$default_atts = array(
			'layout'       	=> 'faq',
			'offset_post'  	=> '0',
			'limit_post'   	=> '-1',
			'sort_by'      	=> 'post__in',
			'category_slug'	=> '',
			'faq_id'      	=> '',
			'post_id'      	=> ''
		);
		$atts = array_merge( $default_atts, $atts );
		if ( $atts['faq_id'] ){
			$atts['post_id'][0] = $atts['faq_id'];
		} else{
			if ( $atts['method'] == 'cat' ){
				$atts['post_id'] = $this->parse_cat_slug_to_post_id(
					$this->taxonomy_cat,
					$atts['category_list'],
					$this->post_type
				);
			} elseif ( $atts['method'] == 'faq' ){
				$atts['post_id'] = $this->parse_list_to_array( 'post_id', $atts['post_list'] );
			}
		}

		$this->attributes = $atts;

		// query
		$default_args = array(
			'post_type'=> $this->post_type,
		);
		$query_args = array_merge( $default_args, $query_args );
		// setting
		$this->setting( $query_args);
	}
	public function setting( $query_args ){
		if ( !isset( $this->attributes['uniq_id'] ) ){
			$this->attributes['uniq_id'] = $this->post_type . '-' .Cosmos_Core::make_id();
		}
		// query
		$this->query = $this->get_query( $query_args, $this->attributes );
		$this->post_count = 0;
		if ( $this->query->have_posts() ){
			$this->post_count = $this->query->post_count;
		}
		// image size
		// $this->get_thumb_size();
		// $this->set_responsive_class();
		$custom_css = $this->add_custom_css();
		if( $custom_css ) {
			do_action( COSMOS_CORE_ADD_INLINE_CSS, $custom_css );
		}
	}
	public function reset(){
		wp_reset_postdata();
	}
	public function add_custom_css(){
		$sc_id = $this->attributes['uniq_id'];
		$custom_css = '';
		return $custom_css;
	}
	public function set_responsive_class( $atts = array() ){
		$class = '';
		$column= $this->attributes['column'];
		$def   = array(
			'1'=> 'column-1 col-xs-12',
			'2'=> 'column-2 col-sm-6',
			'3'=> 'column-3 col-md-4 col-sm-6',
			'4'=> 'column-4 col-lg-3 col-md-4 col-sm-6',
		);

		if ( $column && isset($def[$column])){
			return $this->attributes['responsive-class'] = $def[$column];
		} else{
			return $this->attributes['responsive-class'] = $def['2'];
		}
	}
	public function set_default_options( $html_options = array() ){
		$defaults = array(
			'image_format'			=> '%1$s',
		);
		$html_options = array_merge( $defaults, $html_options );
		return $html_options;
	}
	public function get_thumb_size(){
		$params = Cosmos_Core_Params::get( 'block_image_size', $this->attributes['layout'] );
		$this->attributes['thumb-size'] = Cosmos_Core_Util::get_thumb_size( $params, $this->attributes );
	}

	/****************/
	/*  RENDER HTML **********************************************************/
	/****************/
	public function render_faq_sc( $html_options = array() ) {
		$this->html_format = $this->set_default_options( $html_options );
		if( $this->query->have_posts() ) {
			while ( $this->query->have_posts() ) {
				$this->query->the_post();
				$this->loop_index();
				$html_options = $this->html_format;

				printf( $html_options['html_format'],
					$this->get_title( $html_options ),
					$this->get_content( $html_options )
				);
			}
			$this->reset();
		}
	}


	/*******************/
	/* FUNCTION CUSTOM **********************************************************/
	/*******************/

}