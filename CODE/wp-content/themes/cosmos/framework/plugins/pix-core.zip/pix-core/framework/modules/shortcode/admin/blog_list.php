<?php
$sc_controller = new Cosmos_Core_Shortcodes_Controller();
$style = array(
    esc_html__('Style 1', 'pix-core') =>1,
    esc_html__('Style 2', 'pix-core') =>2,
);
$category = Cosmos_Core_Com::get_category2slug_array();
$tag      = Cosmos_Core_Com::get_tax_options2slug( 'post_tag', array('empty' => esc_html__( '-All tags-', 'pix-core' ) ) );
$author   = Cosmos_Core_Com::get_user_login2id(array(), array('empty' => esc_html__( '-All authors-', 'pix-core' ) ) );
$orderby  = Cosmos_Core_Params::get('sort-blog');
$yes_no   = array(
	esc_html__('No', 'pix-core') => '',
	esc_html__('Yes', 'pix-core')=> 'yes',
);
$true_false   = array(
    esc_html__('Yes', 'pix-core')=> 'true',
	esc_html__('No', 'pix-core') => 'false',
);
$column = array(
    esc_html__( 'One', 'pix-core' )  => '1',
    esc_html__( 'Two', 'pix-core' )  => '2',
    esc_html__( 'Three', 'pix-core' )=> '3',
    esc_html__( 'Four', 'pix-core' ) => '4',
);
$show_content  = array(
	esc_html__('Empty', 'pix-core')      => '',
	esc_html__('Excerpt', 'pix-core')      => 'excerpt',
	esc_html__('Full Content', 'pix-core') => 'content'
);
$post_formats  = get_theme_support( 'post-formats' );
$format        = array( esc_html__( '-All formats-', 'pix-core' ) => '' );
if( is_array($post_formats[0]) ){
	foreach( $post_formats[0] as $val ){
		$format[ ucfirst( $val ) ] = $val;
	}
}
$params = array(
	array(
        'type'       => 'dropdown',
        'heading'    => esc_html__( 'Style', 'pix-core' ),
        'admin_label'=> true,
        'param_name' => 'style',
        'value'      => $style,
        'std'        => '1',
        'description'=> esc_html__( 'Choose style display.', 'pix-core' )
    ),
    array(
        'type'       => 'dropdown',
        'heading'    => esc_html__( 'Column', 'pix-core' ),
        'param_name' => 'column',
        'value'      => $column,
        'std'        => '1',
        'description'=> esc_html__( 'Choose column number will be displayed.', 'pix-core' ),
        'dependency'  => array(
            'element' => 'style',
            'value'   => array('1')
        ),
    ),
	array(
		'type'        => 'textfield',
		'heading'     => esc_html__( 'Limit Posts', 'pix-core' ),
		'param_name'  => 'limit_post',
		'value'       => '-1',
		'description' => esc_html__( 'Enter limit of posts per page. If it blank the limit posts will be the number from Wordpress settings -> Reading. If you want show all, enter "-1".', 'pix-core' )
	),
	array(
		'type'        => 'textfield',
		'heading'     => esc_html__( 'Offset Posts', 'pix-core' ),
		'param_name'  => 'offset_post',
		'value'       => '0',
		'description' => esc_html__( 'Enter offset to pass over posts. If you want to start on record 6, using offset 5.', 'pix-core' )
	),
    array(
		'type'        => 'dropdown',
		'heading'     => esc_html__( 'Show Category', 'pix-core' ),
		'param_name'  => 'show_category',
		'value'       => $yes_no,
        'std'         =>'yes',
		'description' => esc_html__( 'Choose what you want to display as category of post.', 'pix-core' )
	),
	array(
		'type'        => 'dropdown',
		'heading'     => esc_html__( 'Show Content or Excerpt', 'pix-core' ),
		'param_name'  => 'show_content',
		'value'       => $show_content,
        'std'         =>'excerpt',
		'description' => esc_html__( 'Choose what you want to display as content of post.', 'pix-core' )
	),
    array(
		'type'        => 'textfield',
		'heading'     => esc_html__( 'Title Length', 'pix-core' ),
		'param_name'  => 'title_length',
		'value'       => '',
		'description' => esc_html__( 'Enter limit of text will be truncated. If it is empty, the default is not cut. It will trim word', 'pix-core' ),
	),
	array(
		'type'        => 'textfield',
		'heading'     => esc_html__( 'Excerpt Length', 'pix-core' ),
		'param_name'  => 'excerpt_length',
		'value'       => '',
		'description' => esc_html__( 'Enter limit of text will be truncated. If it is empty, the default is not cut. It will trim word', 'pix-core' ),
        'dependency'  => array(
            'element' => 'show_content',
            'value'   => array('excerpt', 'content')
        ),
	),
	array(
		'type'        => 'dropdown',
		'heading'     => esc_html__( 'Sort By', 'pix-core' ),
		'param_name'  => 'sort_by',
		'value'       => $orderby,
		'description' => esc_html__( 'Choose criteria to display.', 'pix-core' )
	),
	array(
		'type'        => 'dropdown',
		'heading'     => esc_html__( 'Pagination', 'pix-core' ),
		'param_name'  => 'pagination',
		'value'       => $yes_no,
		'std'         => 'yes',
		'description' => esc_html__( 'Show pagination.', 'pix-core' ),
	),
	array(
		'type'        => 'textfield',
		'heading'     => esc_html__( 'Button Text', 'pix-core' ),
		'param_name'  => 'button_text',
		'value'       => esc_html__( 'Read More', 'pix-core' ),
		'description' => esc_html__( 'Enter button text.', 'pix-core' )
	),
	array(
		'type'        => 'textfield',
		'heading'     => esc_html__( 'Extra Class', 'pix-core' ),
		'param_name'  => 'extra_class',
		'description' => esc_html__( 'Enter extra class.', 'pix-core' )
	),
	array(
		'type'       => 'param_group',
		'heading'    => esc_html__( 'Category', 'pix-core' ),
		'param_name' => 'category_list',
		'params'     => array(
			array(
				'type'        => 'dropdown',
				'admin_label' => true,
				'heading'     => esc_html__( 'Add Category', 'pix-core' ),
				'param_name'  => 'category_slug',
				'value'       => $category,
				'description' => esc_html__( 'Choose special category to filter', 'pix-core'  )
			),
		),
		'value'       => '',
		'description' => esc_html__( 'Default no filter by category.', 'pix-core' ),
		'group'       => esc_html__( 'Filter', 'pix-core' ),
	),
	array(
		'type'       => 'param_group',
		'heading'    => esc_html__( 'Tag', 'pix-core' ),
		'param_name' => 'tag_list',
		'params'     => array(
			array(
				'type'        => 'dropdown',
				'admin_label' => true,
				'heading'     => esc_html__( 'Add Tag', 'pix-core' ),
				'param_name'  => 'tag_slug',
				'value'       => $tag,
				'description' => esc_html__( 'Choose special tag to filter', 'pix-core'  )
			),
		),
		'value'       => '',
		'description' => esc_html__( 'Default no filter by tag.', 'pix-core' ),
		'group'       => esc_html__( 'Filter', 'pix-core' ),
	),
	array(
		'type'       => 'param_group',
		'heading'    => esc_html__( 'Author', 'pix-core' ),
		'param_name' => 'author_list',
		'params'     => array(
			array(
				'type'        => 'dropdown',
				'admin_label' => true,
				'heading'     => esc_html__( 'Add Author', 'pix-core' ),
				'param_name'  => 'author',
				'value'       => $author,
				'description' => esc_html__( 'Choose special author to filter', 'pix-core'  )
			),
		),
		'value'       => '',
		'description' => esc_html__( 'Default no filter by author.', 'pix-core' ),
		'group'       => esc_html__( 'Filter', 'pix-core' ),
	),
	array(
		'type'       => 'param_group',
		'heading'    => esc_html__( 'Post Formats', 'pix-core' ),
		'param_name' => 'format_list',
		'params'     => array(
			array(
				'type'        => 'dropdown',
				'admin_label' => true,
				'heading'     => esc_html__( 'Add Author', 'pix-core' ),
				'param_name'  => 'post_format',
				'value'       => $format,
				'description' => esc_html__( 'Choose special post format to filter', 'pix-core'  )
			),
		),
		'value'       => '',
		'description' => esc_html__( 'Default no filter by post format.', 'pix-core' ),
		'group'       => esc_html__( 'Filter', 'pix-core' ),
	),
	array(
		'type'            => 'checkbox',
		'heading'         => esc_html__( 'Include Sticky Posts', 'pix-core' ),
		'param_name'      => 'show_sticky',
		'value'           => array( esc_html__( 'Yes', 'pix-core' ) => 'yes' ),
		'description'     => esc_html__( 'Checked to show sticky posts.', 'pix-core' ),
		'group'           => esc_html__('Filter', 'pix-core')
	),
	array(
		'type'        	=> 'colorpicker',
		'heading'     	=> esc_html__( 'Category Color', 'pix-core' ),
		'param_name'  	=> 'category_color',
		'description' 	=> esc_html__( 'Choose color category', 'pix-core' ),
		'group'			=> esc_html__('Custom style', 'pix-core')
	),
	array(
		'type'        	=> 'colorpicker',
		'heading'     	=> esc_html__( 'Title Color', 'pix-core' ),
		'param_name'  	=> 'title_color',
		'description' 	=> esc_html__( 'Choose color title', 'pix-core' ),
		'group'			=> esc_html__('Custom style', 'pix-core')
	),
	array(
		'type'        	=> 'colorpicker',
		'heading'     	=> esc_html__( 'Meta Color', 'pix-core' ),
		'param_name'  	=> 'meta_color',
		'description' 	=> esc_html__( 'Choose color meta', 'pix-core' ),
		'group'			=> esc_html__('Custom style', 'pix-core')
	),
	array(
		'type'        	=> 'colorpicker',
		'heading'     	=> esc_html__( 'Excerpt Color', 'pix-core' ),
		'param_name'  	=> 'excerpt_color',
		'description' 	=> esc_html__( 'Choose color excerpt', 'pix-core' ),
		'group'			=> esc_html__('Custom style', 'pix-core')
	),
	array(
		'type'        	=> 'colorpicker',
		'heading'     	=> esc_html__( 'Button Color', 'pix-core' ),
		'param_name'  	=> 'button_color',
		'description' 	=> esc_html__( 'Choose color button', 'pix-core' ),
		'group'			=> esc_html__('Custom style', 'pix-core')
	),
	array(
		'type'        	=> 'colorpicker',
		'heading'     	=> esc_html__( 'Button Color Hover', 'pix-core' ),
		'param_name'  	=> 'button_color_hv',
		'description' 	=> esc_html__( 'Choose color button when hover', 'pix-core' ),
		'group'			=> esc_html__('Custom style', 'pix-core')
	),
    array(
		'type'        => 'dropdown',
		'heading'     => esc_html__( 'Auto Play', 'pix-core' ),
		'param_name'  => 'autoplay',
		'value'		  => $true_false,
		'std'		  => 'false',
		'description' => esc_html__('Turn autoplay yes or no for the slider'),
		'group'		  => esc_html__('Carousel', 'pix-core'),
	),
	array(
		'type'        => 'textfield',
		'heading'     => esc_html__( 'Auto Play Time Out', 'pix-core' ),
		'param_name'  => 'timeout',
		'value'  	  => '3000',
		'description' => esc_html__('Set autoplay timing (miliseconds) between slides'),
		'group'		  => esc_html__('Carousel', 'pix-core'),
		'dependency'  => array(
            'element' => 'autoplay',
            'value'   => array('true')
        ),
	),
	$sc_controller->cosmos_animation_style(),
	$sc_controller->cosmos_animation_delay(),
	array(
		'type'        => 'dropdown',
        'heading'     => esc_html__( 'Animation To Children', 'pix-core' ),
        'param_name'  => 'is_parent_animation',
        'value'       => array(
                            esc_html__('Yes', 'pix-core')=> 'yes',
                            esc_html__('No', 'pix-core') => 'no',
                        ),
        'std'         => 'no',
        'description' => esc_html__('Apply run animation to children element'),
        'group'       => esc_html__('Animation', 'pix-core'),
	)            
);
vc_map(array(
	'name'               => esc_html__( 'PIX Blog List', 'pix-core' ),
	'base'               => 'pixcore_blog_list_sc',
	'class'              => 'pixcore-sc',
	'icon'               => 'icon-pixcore_blog_list_sc',
	'category'           => COSMOS_CORE_SC_CATEGORY,
	'description'        => esc_html__( 'Blog of list', 'pix-core' ),
	'params'             => $params
));

