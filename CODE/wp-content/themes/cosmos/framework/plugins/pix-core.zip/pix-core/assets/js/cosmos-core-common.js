;(function($) {
	"use strict";
	$.fn.pixCom = function(){};
	var $this = $.fn.pixCom;
	$.fn.pixCom.colorCss = "pixcore-meta-color";
	// convert to int
	$.fn.pixCom.cnvInt = function( obj ) {
		var iVal = obj;
		if ( typeof iVal !== 'undefined' ) {
			iVal = parseInt( iVal, 10 );
		}
		if(isNaN(iVal)) {
			iVal = 0
		}
		return iVal;
	};
	$.fn.pixCom.reloadMetaColor = function( cls ) {
		if ( typeof cls == 'undefined' ) {
			cls = $.fn.pixCom.colorCss;
		}
		$("." + cls ).wpColorPicker();
	}
	
	//slider post type
	$.fn.pixCom.pixcore_slider = function () {
		$('#slider-show-button').change(function (){
			
			if($(this).val() == 'yes'){
				$(this).parents('.pix-meta-row').next('.button-option').addClass('open');
			}else{
				$(this).parents('.pix-meta-row').next('.button-option').removeClass('open');
			}
		})
	};
	$.fn.pixCom.pixcore_tooltip = function () {
		jQuery('.pixcore-tooltip').each(function() {
			var position = jQuery(this).data('position');
			var contentAsHTML = Boolean(jQuery(this).data('content-as-html'));
			jQuery(this).tooltipster({
				contentAsHTML: contentAsHTML,
				position: position,
				offsetX:5,
				offsetY:5,
				maxWidth:500,
				interactive:true,
				//autoClose:false
			});
		});
	};
	$.fn.pixCom.pixcore_link = function () {
		$( '.pix-link-build').click( function ( e ) {
			var $block,
				$input,
				$url_label,
				$title_label,
				value_object,
				$link_submit,
				$pix_link_submit,
				dialog;
			e.preventDefault();
			$block = $( this ).closest( '.pix-link' );
			$input = $block.find( '.wpb_pix_param_value' );
			$url_label = $block.find( '.url-label' );
			$title_label = $block.find( '.title-label' );
			value_object = $input.data( 'json' );
			$link_submit = $( '#wp-link-submit' );
			$pix_link_submit = $( '<input type="submit" name="pix-link-submit" id="pix-link-submit" class="button-primary" value="Set Link">' );
			$link_submit.hide();
			$( "#pix-link-submit" ).remove();
			$pix_link_submit.insertBefore( $link_submit );
			if ( ! window.wpLink && $.fn.wpdialog && $( '#wp-link' ).length ) {
				dialog = {
					$link: false,
					open: function () {
						this.$link = $( '#wp-link' ).wpdialog( {
							title: wpLinkL10n.title,
							width: 480,
							height: 'auto',
							modal: true,
							dialogClass: 'wp-dialog',
							zIndex: 300000
						} );
					},
					close: function () {
						this.$link.wpdialog( 'close' );
					}
				};
			} else {
				dialog = window.wpLink;
			}
			dialog.open( 'content' );
			console.log(typeof dialog);
			if ( _.isString( value_object.url ) ) {

				$( '#wp-link-url' ).length ? $( '#wp-link-url' ).val( value_object.url ) : $( '#url-field' ).val( value_object.url );
			}
			if ( _.isString( value_object.title ) ) {
				$( '#wp-link-text' ).length ? $( '#wp-link-text' ).val( value_object.title ) : $( '#link-title-field' ).val( value_object.title );
			}
			if ( $( '#wp-link-target' ).length ) {
				$( '#wp-link-target' ).prop( 'checked', ! _.isEmpty( value_object.target ) );
			} else {
				$( '#link-target-checkbox' ).prop( 'checked', ! _.isEmpty( value_object.target ) );
			}
			$pix_link_submit.unbind( 'click.pixLink' ).bind( 'click.pixLink', function ( e ) {
				e.preventDefault();
				e.stopImmediatePropagation();
				var options = {},
					string;
				options.url = $( '#wp-link-url' ).length ? $( '#wp-link-url' ).val() : $( '#url-field' ).val();
				options.title = $( '#wp-link-text' ).length ? $( '#wp-link-text' ).val() : $( '#link-title-field' ).val();
				var $checkbox = $( '#wp-link-target' ).length ? $( '#wp-link-target' ) : $( '#link-target-checkbox' );
				options.target = $checkbox[0].checked ? ' _blank' : '';
				string = _.map( options, function ( value, key ) {
					if ( _.isString( value ) && 0 < value.length ) {
						return key + ':' + encodeURIComponent( value );
					}
				} ).join( '|' );
				$input.val( string );
				$input.data( 'json', options );
				$url_label.attr( 'value', options.url + options.target );
				$title_label.attr( 'value',options.title );

				dialog.close();
				$link_submit.show();
				$pix_link_submit.unbind( 'click.pixLink' );
				$pix_link_submit.remove();
				// remove pix-link hooks for wpLink
				$( '#wp-link-cancel' ).unbind( 'click.pixLink' );
				window.wpLink.textarea = '';
				$checkbox.attr( 'checked', false );
				return false;
			} );
			$( '#wp-link-cancel' ).unbind( 'click.pixLink' ).bind( 'click.pixLink', function ( e ) {
				e.preventDefault();
				dialog.close();
				// remove pix-link hooks for wpLink
				$pix_link_submit.unbind( 'click.pixLink' );
				$pix_link_submit.remove();
				// remove pix-link hooks for wpLink
				$( '#wp-link-cancel' ).unbind( 'click.pixLink' );
				window.wpLink.textarea = '';
			} );
		} );
	};

})(jQuery);
