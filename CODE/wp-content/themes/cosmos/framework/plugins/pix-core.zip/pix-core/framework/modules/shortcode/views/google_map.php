<?php
$uniq_id = 'sc-google-map-'.esc_attr( $id );
$custom_css = '';
if( !empty( $title_color ) ){
    $custom_css .= '.%1$s.sc-google-map .iw-container .iw-title {color:%2$s;}' ."\n";
    $custom_css .= '.%1$s.sc-google-map .map_3 .content .location .content-title {color:%2$s;}' ."\n";
}
if( !empty( $description_color ) ){
    $custom_css .= '.%1$s.sc-google-map .iw-container .iw-content {color:%3$s;}' ."\n";
    $custom_css .= '.%1$s.sc-google-map .map_3 .content .location .content-description {color:%3$s;}' ."\n";
}
if( !empty( $content_hover_color ) ){
    $custom_css .= '.%1$s.sc-google-map .map_3 .content .location:hover .content-title {color:%4$s;}' ."\n";
    $custom_css .= '.%1$s.sc-google-map .map_3 .content .location:hover .content-description {color:%4$s;}' ."\n";
}
if( !empty( $title_active_color ) ){
    $custom_css .= '.%1$s.sc-google-map .map_3 .content .location.active .content-title {color:%5$s;}' ."\n";
}
if( !empty( $description_active_color ) ){
    $custom_css .= '.%1$s.sc-google-map .map_3 .content .location.active .content-description {color:%6$s;}' ."\n";
}
if( !empty( $location_bg_active_color ) ){
    $custom_css .= '.%1$s.sc-google-map .map_3 .content .location.active {background-color:%7$s;}' ."\n";
}
if ( ! empty ($height_map) ) {
    $custom_css .= '.%1$s.sc-google-map .g-map {height:%8$spx;}' ."\n";
}
if ( !empty( $custom_css ) ) {
    $custom_css = sprintf($custom_css,
            esc_attr($uniq_id),
            esc_attr($title_color),
            esc_attr($description_color),
            esc_attr($content_hover_color),
            esc_attr($title_active_color),
            esc_attr($description_active_color),
            esc_attr($location_bg_active_color),
            esc_attr(floatval($height_map))
            );
    do_action( COSMOS_CORE_ADD_INLINE_CSS, $custom_css );
}

$map_id = 'map_' . esc_attr( $id );
$function_name = 'func_' . esc_attr( $id );
$info_window_id = 'info_window_' . esc_attr( $id );
if ( ! empty ($api_key) ) {
    $api_key = esc_attr( $api_key );
} else {
    $api_key = NULL;
}
if ( ! empty ($latitude) ) {
    $latitude = esc_attr( $latitude );
} else {
    $latitude = 0;
}
if ( ! empty ($longitude) ) {
    $longitude = esc_attr( $longitude );
} else {
    $longitude = 0;
}
if ( ! empty ($zoom_map) ) {
    $zoom_map = esc_attr( $zoom_map );
} else {
    $zoom_map = NULL;
}
if ( ! empty ($image_marker_url) ) { 
    $image_marker_url = esc_attr( $image_marker_url );
} else {
    $image_marker_url = NULL;
}

$image_marker = wp_get_attachment_image_src($image_marker, 'full', false);
if ( ! empty ($image_marker) ) { 
    $image_src = $image_marker[0];
    $image_width = $image_marker[1];
    $image_height = $image_marker[2];
} else {
    $image_src = NULL;
    $image_width = NULL;
    $image_height = NULL;
}
if ( ! empty ($zoom_map) && (intval($zoom_map) >= 3 || intval($zoom_map) <= 23) ){
    $zoom_map = intval($zoom_map);
} else {
    $zoom_map = '';
}

$class = (esc_attr($content_type) == 1) ? 'hidden' : '';
?>
<div class="pix-shortcode sc-google-map <?php echo esc_attr($uniq_id).' '.esc_attr( $extra_class )?>">
  <?php if ( ! empty ($locations) && is_array($locations) ) { ?>
    <div class="map_3">
      <div class="g-info content <?php echo esc_attr($class) ?>" id="<?php echo esc_attr($info_window_id) ?>">
        <?php
          foreach ($locations as $key => $item) { 
            $title = $description = '';
            if ( ! empty ($item['latitude']) && ! empty ($item['longitude'])) { 
              $latitude    = $item['latitude'];
              $longitude   = $item['longitude'];
              $title       = isset($item['title']) ? $item['title'] : '';
              $description = isset($item['description']) ? $item['description'] : '';
              if (empty($title) && empty($description)) {
                $title = 'Location ' . ($key + 1);
              }
              $location_id = 'location_' . esc_attr( $id ) . '_' . $key . '_' . rand(100, 9999);
              ?>
              <p class="location" 
                  data-id="<?php echo esc_attr($location_id) ?>"
                  data-latitude="<?php echo esc_attr($latitude) ?>"
                  data-longitude="<?php echo esc_attr($longitude) ?>" 
                  data-title="<?php echo esc_attr($title) ?>" 
                  data-description="<?php echo wp_kses_post($description) ?>"
                  data-map-id="<?php echo esc_attr($map_id) ?>"
                  data-marker-id="" 
                >
                <span class="content-title"><?php echo esc_attr($title) ?></span>
                <span class="content-description"><?php echo wp_kses_post($description) ?></span>
              </p>
        <?php } 
            } ?>
      </div>
      <div class="g-map" id="<?php echo esc_attr($map_id) ?>" 
           data-latitude="<?php echo esc_attr($latitude) ?>" 
           data-longitude="<?php echo esc_attr($longitude) ?>" 
           data-zoom="<?php echo esc_attr($zoom_map) ?>"
           data-marker="<?php echo esc_attr($image_src) ?>"
           data-marker-width="<?php echo esc_attr($image_width) ?>"
           data-marker-height="<?php echo esc_attr($image_height) ?>"
           data-location-id="<?php echo esc_attr($info_window_id) ?>"
           data-style-map="<?php echo esc_attr($style) ?>"
           data-content-type="<?php echo esc_attr($content_type) ?>"
           >
      </div>
    </div>
  <?php } ?>
</div>