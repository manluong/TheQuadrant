<?php
$custom_css = "";
$sc_name    = 'contac-form';
$sc_id      = $sc_name .'-'. $id;
$block_class= $extra_class . ' ' . $sc_id;

if(!empty( $title) && !empty( $title_color)){
	$custom_css .= sprintf( '.%1$s .detail-comment .text-more {color: %2$s;}',
		esc_attr( $sc_id ),
		esc_attr( $title_color )
	);
}
if(!empty( $error_color)){
	$custom_css .= sprintf( '.%1$s .wpcf7-not-valid-tip, .%1$s .wpcf7-validation-errors{color: %2$s;}',
		esc_attr( $sc_id ),
		esc_attr( $error_color )
	);
}
if(!empty($input_color)){
	$custom_css .= sprintf( '.%1$s .section_contact .form input[type=text], .%1$s .section_contact .form textarea, .%1$s .section_contact .form input[type=tel], .%1$s .section_contact .form input[type=email] {color:%2$s;}',
		esc_attr( $sc_id ),
		esc_attr($input_color)
	);
}
if(!empty($placeholder_color)){
	$custom_css .= sprintf( '.%1$s .section_contact.style-1 .input--border-orange:-ms-input-placeholder,
      .%1$s .section-contact2 .input--border-orange:-ms-input-placeholder,
      .%1$s .section_contact.style-3 .input--border-orange:-ms-input-placeholder,
      .%1$s .section_contact.style-4 .input--border-orange:-ms-input-placeholder,
      .%1$s .section-contact5 .input--border-orange:-ms-input-placeholder,
      .%1$s .section_contact.style-6 .input--border-orange:-ms-input-placeholder {color:%2$s;}',
      	esc_attr( $sc_id ),
		esc_attr($placeholder_color)
	);
    $custom_css .= sprintf( '.%1$s .section_contact.style-1 .input--border-orange::-moz-placeholder,
      .%1$s .section-contact2 .input--border-orange::-moz-placeholder,
      .%1$s .section_contact.style-3 .input--border-orange::-moz-placeholder,
      .%1$s .section_contact.style-4 .input--border-orange::-moz-placeholder,
      .%1$s .section-contact5 .input--border-orange::-moz-placeholder,
      .%1$s .section_contact.style-6 .input--border-orange::-moz-placeholder {color:%2$s;}',
      	esc_attr( $sc_id ),
		esc_attr($placeholder_color)
	);
    $custom_css .= sprintf( '.%1$s .section_contact.style-1 .input--border-orange:-moz-placeholder,
      .%1$s .section-contact2 .input--border-orange:-moz-placeholder,
      .%1$s .section_contact.style-3 .input--border-orange:-moz-placeholder,
      .%1$s .section_contact.style-4 .input--border-orange:-moz-placeholder,
      .%1$s .section-contact5 .input--border-orange:-moz-placeholder,
      .%1$s .section_contact.style-6 .input--border-orange:-moz-placeholder {color:%2$s;}',
      	esc_attr( $sc_id ),
		esc_attr($placeholder_color)
	);
    $custom_css .= sprintf( '.%1$s .section_contact.style-1 .input--border-orange::-webkit-input-placeholder,
      .%1$s .section-contact2 .input--border-orange::-webkit-input-placeholder,
      .%1$s .section_contact.style-3 .input--border-orange::-webkit-input-placeholder,
      .%1$s .section_contact.style-4 .input--border-orange::-webkit-input-placeholder,
      .%1$s .section-contact5 .input--border-orange::-webkit-input-placeholder,
      .%1$s .section_contact.style-6 .input--border-orange::-webkit-input-placeholder {color:%2$s;}',
		esc_attr( $sc_id ),
		esc_attr($placeholder_color)
	);

	$custom_css .= sprintf( '.%1$s .section_contact.style-1 .textarea--border-orange:-ms-input-placeholder,
      .%1$s .section-contact2 .textarea--border-orange:-ms-input-placeholder,
      .%1$s .section_contact.style-3 .textarea--border-orange:-ms-input-placeholder,
      .%1$s .section_contact.style-4 .textarea--border-orange:-ms-input-placeholder,
      .%1$s .section-contact5 .textarea--border-orange:-ms-input-placeholder,
      .%1$s .section_contact.style-6 .textarea--border-orange:-ms-input-placeholder {color:%2$s;}',
      	esc_attr( $sc_id ),
		esc_attr($placeholder_color)
	);
    $custom_css .= sprintf( '.%1$s .section_contact.style-1 .textarea--border-orange::-moz-placeholder,
      .%1$s .section-contact2 .textarea--border-orange::-moz-placeholder,
      .%1$s .section_contact.style-3 .textarea--border-orange::-moz-placeholder,
      .%1$s .section_contact.style-4 .textarea--border-orange::-moz-placeholder,
      .%1$s .section-contact5 .textarea--border-orange::-moz-placeholder,
      .%1$s .section_contact.style-6 .textarea--border-orange::-moz-placeholder {color:%2$s;}',
      	esc_attr( $sc_id ),
		esc_attr($placeholder_color)
	);
    $custom_css .= sprintf( '.%1$s .section_contact.style-1 .textarea--border-orange:-moz-placeholder,
      .%1$s .section-contact2 .textarea--border-orange:-moz-placeholder,
      .%1$s .section_contact.style-3 .textarea--border-orange:-moz-placeholder,
      .%1$s .section_contact.style-4 .textarea--border-orange:-moz-placeholder,
      .%1$s .section-contact5 .textarea--border-orange:-moz-placeholder,
      .%1$s .section_contact.style-6 .textarea--border-orange:-moz-placeholder {color:%2$s;}',
      	esc_attr( $sc_id ),
		esc_attr($placeholder_color)
	);
    $custom_css .= sprintf( '.%1$s .section_contact.style-1 .textarea--border-orange::-webkit-input-placeholder,
      .%1$s .section-contact2 .textarea--border-orange::-webkit-input-placeholder,
      .%1$s .section_contact.style-3 .textarea--border-orange::-webkit-input-placeholder,
      .%1$s .section_contact.style-4 .textarea--border-orange::-webkit-input-placeholder,
      .%1$s .section-contact5 .textarea--border-orange::-webkit-input-placeholder,
      .%1$s .section_contact.style-6 .textarea--border-orange::-webkit-input-placeholder {color:%2$s;}',
		esc_attr( $sc_id ),
		esc_attr($placeholder_color)
	);
}
if(!empty($input_bg_color)){
	$custom_css .= sprintf( '.%1$s .section_contact .form input[type=text], .%1$s .section_contact .form textarea {background-color:%2$s;}',
		esc_attr( $sc_id ),
		esc_attr($input_bg_color)
	);
}
if(!empty($input_border_color)){
	$custom_css .= sprintf( '.%1$s .section_contact.style-1 .textarea--border-orange,
		.%1$s .section-contact2 .textarea--border-orange,
		.%1$s .section_contact.style-3 .textarea--border-orange,
		.%1$s .section_contact.style-4 .textarea--border-orange,
		.%1$s .section-contact5 .textarea--border-orange,
		.%1$s .section_contact.style-6 .textarea--border-orange,
		.%1$s .section_contact.style-1 .input--border-orange,
		.%1$s .section-contact2 .input--border-orange,
		.%1$s .section_contact.style-3 .input--border-orange,
		.%1$s .section_contact.style-4 .input--border-orange,
		.%1$s .section-contact5 .input--border-orange,
		.%1$s .section_contact.style-6 .input--border-orange {border-color:%2$s;}',
		esc_attr( $sc_id ),
		esc_attr($input_border_color)
	);
}
if(!empty($button_color)){
	$custom_css .= sprintf( '.%1$s .section_contact .form input[type=submit]{background-color:%2$s;}',
		esc_attr( $sc_id ),
		esc_attr($button_color)
	);
}
if(!empty($button_hover_color)){
	$custom_css .= sprintf( '.%1$s .section_contact .form input[type=submit]:hover{background-color:%2$s;}',
		esc_attr( $sc_id ),
		esc_attr($button_hover_color)
	);
}
if(!empty($button_text_color)){
	$custom_css .= sprintf( '.%1$s .section_contact .form input[type=submit]{color:%2$s;}',
		esc_attr( $sc_id ),
		esc_attr($button_text_color)
	);
}
if(!empty($button_text_hover_color)){
	$custom_css .= sprintf( '.%1$s .section_contact .form input[type=submit]:hover{color:%2$s;}',
		esc_attr( $sc_id ),
		esc_attr($button_text_hover_color)
	);
}
if(!empty($form_bg_color)){
	$custom_css .= sprintf( '.%1$s .section_contact.style-3 .col-left.bg-img {background:%2$s;}',
		esc_attr( $sc_id ),
		esc_attr($form_bg_color)
	);
}


if(!empty($icon_color)){
	$custom_css .= sprintf( '.%1$s .section_contact.style-3 .style-2.contact-infomation .contact__image .fa {color:%2$s;}',
		esc_attr( $sc_id ),
		esc_attr($icon_color)
	);
}
if(!empty($icon_bg_color)){
	$custom_css .= sprintf( '.%1$s .section_contact.style-3 .style-2.contact-infomation .contact__image .fa {background:%2$s;}',
		esc_attr( $sc_id ),
		esc_attr($icon_bg_color)
	);
}
if(!empty($icon_title_color)){
	$custom_css .= sprintf( '.%1$s .section_contact.style-3 .style-2.contact-infomation .contact__title {color:%2$s;}',
		esc_attr( $sc_id ),
		esc_attr($icon_title_color)
	);
}
if(!empty($icon_description_color)){
	$custom_css .= sprintf( '.%1$s .section_contact.style-3 .style-2.contact-infomation .contact__content {color:%2$s;}',
		esc_attr( $sc_id ),
		esc_attr($icon_description_color)
	);
}
if(!empty($side_icon_bg_color)){
	$custom_css .= sprintf( '.%1$s .section_contact.style-3 .col-right.bg-img {background:%2$s;}',
		esc_attr( $sc_id ),
		esc_attr($side_icon_bg_color)
	);
}
//display custom css
if( !empty( $custom_css ) ){
	do_action( COSMOS_CORE_ADD_INLINE_CSS, $custom_css );
}

$has_icon_data = (!empty($icon_data[0])) ? TRUE : FALSE;
?>

<div class="pix-shortcode <?php echo esc_attr("sc-$sc_name");?> <?php  echo esc_attr($block_class) ?> animate-run" data-animate="<?php echo esc_attr($css_animation); ?>" data-delay="<?php echo (int) esc_attr($delay_animation); ?>">
	<?php if ($style == 1) { ?> 
		<div class="section_contact style-1">
			<?php if ( !empty( $contact_form ) && COSMOS_CORE_WPCF7_ACTIVE ) { 
				echo do_shortcode('[contact-form-7 id="'.$contact_form.'" title="'.esc_attr($title).'" html_id="contact-form-'.esc_attr($id).'" html_class="contact-form"]');
			} ?>
		</div>
	<?php } else { ?> 
		<div class="section_contact style-3">
			<div class="eq-row-height">
				<div class="padding0 col-md-<?php echo ($has_icon_data) ? '8' : '12' ?> col-xs-12">
	                <div class="col-left bg-img">
	                    <div class="row">
	                        <div class="col-md-10 col-md-offset-1 col-xs-12" >
	                            <div class="header">
	                                <div class="header__title--color-white">
	                                    <span data-type="title"><?php echo esc_html($title) ?></span>
	                                </div>
	                                <div class="header__description">
	                                    <span data-type="content"><?php echo esc_html($description) ?></span>
	                                </div>
	                            </div>
	                            <?php if ( !empty( $contact_form ) && COSMOS_CORE_WPCF7_ACTIVE ) { 
									echo do_shortcode('[contact-form-7 id="'.$contact_form.'" title="'.esc_attr($title).'" html_id="contact-form-'.esc_attr($id).'" html_class="contact-form"]');
								} ?>
	                        </div>
	                    </div>
	                </div>
	            </div>
	            <?php if ($has_icon_data) { ?> 
		            <div class="padding0 col-md-4 col-xs-12">
		                <div class="col-right bg-img eq-row-height flex-wrap align-items-center" >
		                <?php
		          			foreach ($icon_data as $key => $item) { 
	  						$icon_url = ! empty($item['icon_url']) ? $item['icon_url'] : '';
	  						$icon_title = ! empty($item['icon_title']) ? $item['icon_title'] : '';
	  						$icon_description = ! empty($item['icon_description']) ? $item['icon_description'] : '';
	  					?>
		                    <div class="contact-infomation style-2">
		                        <div class="contact__image">
		                            <i class="<?php echo esc_html($icon_url) ?>" aria-hidden="true"></i>
		                        </div>
		                        <div class="contact__title">
		                            <span data-type="title"><?php echo esc_html($icon_title) ?></span>
		                        </div>
		                        <div class="contact__content">
		                            <p data-type="content"><?php echo esc_html($icon_description) ?></p>
		                        </div>
		                    </div>
		                <?php } ?>
		                </div>
		            </div>
	            <?php } ?>
	        </div>
		</div>
	<?php } ?>
</div>