<?php
$uniq_id = 'sc-demo-app-'.esc_attr( $id );
$custom_css = '';
$bg_img = wp_get_attachment_image_src($image_background, '',false);
if($style == 1) {
    if( !empty($first_title_color) ) {
        $custom_css .= '.%1$s .section_demo.style-2 .col-right .demo-description-1 span {color:%2$s}'."\n";
    }
    if( !empty($last_title_color) ){
        $custom_css .= '.%1$s .section_demo.style-2 .col-right .demo-description-1 {color:%3$s}'."\n";
    }
    if( !empty($description_color) ){
        $custom_css .= '.%1$s .section_demo.style-2 .col-right .demo-description-2 {color:%4$s;}' ."\n";
    }
    if( !empty( $bg_color ) ){
        $custom_css .= '.%1$s .section_demo.style-2 {background-color:%6$s;}' ."\n";
    }
    if( !empty($image_background) ){
        $custom_css .= '.%1$s .section_demo.style-2 .col-left {background-image:url(%7$s)}'."\n";
    }
} else {
    if( !empty($title_color) ) {
        $custom_css .= '.%1$s .section_demo.style-3 .demo-watch {color:%5$s}'."\n";
    }
    if( !empty($description_color) ){
        $custom_css .= '.%1$s .section_demo.style-3 .demo-text {color:%4$s;}' ."\n";
    }
    if( !empty( $bg_color ) ){
        $custom_css .= '.%1$s .section_demo.style-3 .video-youtube {background-color:%6$s;}' ."\n";
    }
}

if ( !empty( $custom_css ) ) {
    $custom_css = sprintf($custom_css,
            esc_attr($uniq_id),
            esc_attr($first_title_color),
            esc_attr($last_title_color),
            esc_attr($description_color),
            esc_attr($title_color),
            esc_attr($bg_color),
            esc_attr($bg_img[0])
            );
    do_action( COSMOS_CORE_ADD_INLINE_CSS, $custom_css );
}
?>
<div class="pix-shortcode sc-demo-app <?php echo esc_attr($uniq_id).' '.esc_attr( $extra_class )?> animate-run" data-animate="<?php echo esc_attr($css_animation); ?>" data-delay="<?php echo (int) esc_attr($delay_animation); ?>">
<?php if($style == 1) { ?>
    <div class="row-builder section_demo style-2">
        <div class="row margin0">
            <div class="col-lg-6 col-xs-12 padding0">
                <div class="col-left">
                    <div class="video-youtube">
                        <a class="fancybox-video fancybox.iframe" <?php echo !empty($youtube_id) ? "href='http://www.youtube.com/embed/".esc_attr($youtube_id)."?autoplay=1'" : "href='javascrpipt:;'"; ?>>
                            <img src="<?php echo COSMOS_PUBLIC_URI . '/images/demo/button-play.png'?>" alt="button play" data-type="image-link">
                        </a>
                    </div>
                </div>
            </div>
            <div class="col-lg-6 col-xs-12 padding0">
                <div class="col-right" data-type="bg">
                    <div class="content">
                        <p class="demo-description-1" data-type="title">
                            <?php if(!empty($first_title)) { ?>
                            <span><?php echo esc_attr($first_title) ?></span>
                            <?php }
                                if(!empty($last_title)) {
                                    echo esc_attr($last_title);
                                }
                            ?>
                        </p>
                        <?php if(!empty($description)) { ?>
                        <div class="demo-description-2" data-type="content">
                            <?php echo esc_attr($description) ?>
                        </div>
                        <?php } ?>
                        <?php if(!empty($values) || is_array($values)) { ?>
                        <div class="download-app animate-run" data-animate="bounceIn-children" data-delay="200">
                            <?php foreach ($values as $value) {
                                if ( !empty($value['url']) ) {
                                    $value['url'] = Cosmos_Core_Util::get_link_to_attr($value['url']);
                                }
                            ?>
                            <a <?php echo !empty($value['url']) ? $value['url'] : "href='javascrpipt:;'"; ?>>
                                <?php if(!empty($value['image'])) { ?>
                                <?php echo wp_get_attachment_image($value['image'], '',false, array('class'=>'img-responsive','data-type'=>'image-link')); ?>
                                <?php } ?>
                            </a>
                            <?php } ?>
                        </div>
                        <?php } ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php } else { ?>
    <div  class="row-builder section_demo style-3" >
        <div class="video-youtube" >
            <?php if(!empty($image_background)) { echo wp_get_attachment_image($image_background, '',false, array('data-type'=>'image', 'class' => '')); } ?>
            <div class="demo-content">
                <a class="fancybox-video fancybox.iframe" <?php echo !empty($youtube_id) ? "href='http://www.youtube.com/embed/".esc_attr($youtube_id)."?autoplay=1'" : "href='javascrpipt:;'"; ?>>
                    <img src="<?php echo COSMOS_PUBLIC_URI . '/images/demo/button-play.png'?>" alt="button play" data-type="image-link">
                </a>
                <?php if(!empty($title)) { ?>
                <p class="demo-watch" data-type="title"><?php echo esc_attr($title) ?></p>
                <?php } if(!empty($description)) { ?>
                <p class="demo-text">
                    <span data-type="title"><?php echo esc_attr($description) ?></span>
                </p>
                <?php } ?>
            </div>
        </div>
    </div>
<?php } ?>
</div>