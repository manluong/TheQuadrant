<?php
$uniq_id = 'sc-screenshot-'.esc_attr( $id );
$custom_css = '';
$size_img = '';
if($image_size == 1) {
	$size_img = 'full';
} else if($image_size == 2) {
	$size_img = 'cosmos-thumb-300x550';
} else {
	$size_img = 'cosmos-thumb-600x600';
}
if($style == 1) {
	if( !empty($dot_color) ) {
		$custom_css .= '.%1$s .section_screenshot.style-2 .owl-theme .owl-controls .owl-page span {border-color:%2$s}'."\n";
	}
	if( !empty($dot_hover_color) ) {
		$custom_css .= '.%1$s .section_screenshot.style-2 .owl-theme .owl-controls.clickable .owl-page:hover span {border-color:%3$s}'."\n";
	}
	if( !empty($active_dot_color) ) {
		$custom_css .= '.%1$s .section_screenshot.style-2 .owl-theme .owl-controls .owl-page.active span {border-color:%4$s}'."\n";
	}
} else {
	if( !empty($title_color) ) {
		$custom_css .= '.%1$s .screenshot-counter-count span {color:%5$s}'."\n";
	}
	if( !empty($title_des_color) ) {
		$custom_css .= '.%1$s .screenshot-counter-description-text1 span {color:%6$s}'."\n";
	}
	if( !empty($description_color) ) {
		$custom_css .= '.%1$s .screenshot-counter-description-text2 span {color:%7$s}'."\n";
	}
	if( !empty($border_color) ) {
		$custom_css .= '.%1$s .section_screenshot.style-3 .screenshot-counter-description {border-color:%8$s}'."\n";
	}
}

if ( !empty( $custom_css ) ) {
	$custom_css = sprintf($custom_css,
			esc_attr($uniq_id),
			esc_attr($dot_color),
			esc_attr($dot_hover_color),
			esc_attr($active_dot_color),
			esc_attr($title_color),
			esc_attr($title_des_color),
			esc_attr($description_color),
			esc_attr($border_color)
			);
	do_action( COSMOS_CORE_ADD_INLINE_CSS, $custom_css );
}
?>
<div data-id="<?php echo esc_attr($uniq_id)?>" class="pix-shortcode sc-screenshot <?php echo esc_attr($uniq_id).' '.esc_attr( $extra_class )?> animate-run" data-animate="<?php echo esc_attr($css_animation); ?>" data-delay="<?php echo (int) esc_attr($delay_animation); ?>">
<?php
if($style == 1) {
	if(is_array($image_arr) || !empty($image_arr)) { ?>
	<div class="section_screenshot style-2 <?php echo esc_attr($uniq_id)?>" data-type="bg" data-item="<?php echo esc_attr($item)?>" data-autoplay="<?php echo esc_attr($autoplay)?>" data-shownav="<?php echo esc_attr($show_nav)?>" data-showdots="<?php echo esc_attr($show_dot)?>">
	    <div class="screenshot-content">
	        <div class="carousel">
	            <div class="carousel-items">
	            <?php for ($i = 0; $i < count($image_arr); $i++) {
	            	$image_src_arr = array();
		        	if(!empty($image_arr[$i])) {
		        		$image_src_arr = wp_get_attachment_image_src($image_arr[$i], $size_img ,false);

		        ?>
	                <a class="fancybox-thumb" data-fancybox-group="fancybox-thumb-<?php echo esc_attr($uniq_id)?>" href="<?php echo esc_url($image_src_arr[0])?>">
	                    <?php echo wp_get_attachment_image($image_arr[$i], $size_img ,false, array('data-type'=>'image')); ?>
	                </a>
	            <?php } } ?>
	            </div>
	            <div class="carousel-prev" data-type="icon">
	                <i class="fa fa-angle-left" aria-hidden="true"></i>
	            </div>
	            <div class="carousel-next" data-type="icon">
	                <i class="fa fa-angle-right" aria-hidden="true"></i>
	            </div>
	        </div>
	    </div>
    </div>
<?php } 
	} else {
		if(is_array($values) || !empty($values)) {
?>
	<div class="section_screenshot style-3 <?php echo esc_attr($uniq_id)?>" data-type="bg" data-autoplay="<?php echo esc_attr($autoplay)?>">
		<div class="screenshot-content">
            <div class="row row-eq-height">
                <div class="col-sm-6 col-sm-offset-0 col-xs-10 col-xs-offset-1">
                    <div class="carousel">
                        <div class="carousel-items">
                        <?php $i=0; foreach ($values as $value) { $i++; ?>
                            <?php echo wp_get_attachment_image($value['image'], $size_img ,false, array('data-text'=>'screenshot-tab'.esc_attr($i), 'data-type'=>'image')); ?>
                        <?php } ?>
                        </div>
                        <div class="carousel-prev" data-type="icon">
                            <i class="fa fa-angle-left" aria-hidden="true"></i>
                        </div>
                        <div class="carousel-next" data-type="icon">
                            <i class="fa fa-angle-right" aria-hidden="true"></i>
                        </div>
                    </div>
                </div>
                <div class="col-sm-6 col-xs-12">
	                <?php $i=0; foreach ($values as $value) { $i++; ?>
	                    <div data-text="screenshot-tab<?php echo esc_attr($i) ?>" class="screenshot-counter active">
	                        <div class="screenshot-counter-count">
	                            <span data-tyle="title"><?php echo esc_attr($i).'/'.count($values).': '. esc_attr($value['title']) ?></span>
	                        </div>
	                        <div class="screenshot-counter-description">
	                        <?php if(!empty($value['title_des'])) { ?>
	                            <div class="screenshot-counter-description-text1">
	                                <span data-type="title"><?php echo esc_attr($value['title_des']) ?></span>
	                            </div>
	                        <?php } if(!empty($value['description'])) { ?>
	                            <div class="screenshot-counter-description-text2">
	                                <span data-type="content"><?php echo esc_attr($value['description']) ?></span>
	                            </div>
	                        <?php } ?>
	                        </div>
	                    </div>
	                <?php } ?>
                </div>
            </div>
        </div>
	</div>
<?php } } ?>
</div>


