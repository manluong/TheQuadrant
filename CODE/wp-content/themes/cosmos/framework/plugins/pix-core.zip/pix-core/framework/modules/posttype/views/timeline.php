<?php $prefix='cosmos_timeline_'; ?>
<div class="pix-custom-meta" >
	<div class="pix-meta-row" >
		<div class="pix-desc">
			<span><?php esc_html_e( 'Timeline Images', 'pix-core' );?></span>
			<p class="description"><?php esc_html_e( 'Images should have minimum size: 800x600. Bigger size images will be cropped automatically.', 'pix-core' );?></p>
		</div>
		<div class="pix-field">
			<?php $this->gallery( $prefix . 'meta['. $prefix .'timeline_images]', $data_meta['timeline_images'] ); ?>
		</div>
	</div>
	<div class="pix-meta-row" >
		<div class="pix-desc">
			<span><?php esc_html_e( 'Date', 'pix-core' );?></span>
			<span class="f-right"><?php $this->tooltip_html( esc_html__( 'Date of timeline.', 'pix-core' ) );?></span>
		</div>
		<div class="pix-field">
			<?php echo ( $this->date_picker( $prefix .'meta['. $prefix .'date]',
					$this->get_field( $data_meta, 'date' ),
					array( 'class' => 'pix-block' ) ) );?>
		</div>
	</div>
	<div class="pix-meta-row" >
		<div class="pix-desc">
			<span><?php esc_html_e( 'Description', 'pix-core' );?></span>
			<span class="f-right"><?php $this->tooltip_html( esc_html__( 'Description of timeline.', 'pix-core' ) );?></span>
		</div>
		<div class="pix-field">
			<?php echo ( $this->text_area( $prefix .'meta['.$prefix.'description]',
					$this->get_field( $data_meta, 'description' ),
					array('class'=>'pix-block','rows' => '6') ) );?>
		</div>
	</div>
</div>