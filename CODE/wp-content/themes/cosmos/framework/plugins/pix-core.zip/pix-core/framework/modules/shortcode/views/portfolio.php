<?php
$model      = new Cosmos_Core_Portfolio();
$model->init( $atts );
$custom_css = "";
$sc_id      = $model->attributes['uniq_id'];
$block_class= $model->attributes['extra_class'] . ' ' . $sc_id;

$css_animation = '';
$css_animation_class = '';
$delay_animation = 0;
$css_animation_parent = '';
$css_animation_parent_class = '';
$delay_animation_parent = 0;

if ( !empty($model->attributes['css_animation']) && !empty($model->attributes['is_parent_animation']) && $model->attributes['is_parent_animation'] != 'yes') {
	$css_animation = $model->attributes['css_animation'];
	$css_animation_class = 'animate-run';
	$delay_animation = (int) $model->attributes['delay_animation'];
}

if ( !empty($model->attributes['css_animation']) && !empty($model->attributes['is_parent_animation']) && $model->attributes['is_parent_animation'] == 'yes') {
	$css_animation_parent = $model->attributes['css_animation'].'-children';
	$css_animation_parent_class = 'animate-run';
	$delay_animation_parent = (int) $model->attributes['delay_animation'];
}

if($atts['style'] == 1) {
	if( !empty( $atts['text_filter_color'] ) ){
		$custom_css .= '.%1$s .section_portfolio.style-1 {color:%2$s;}' ."\n";
	}
	if( !empty( $atts['text_filter_hover_color'] ) ){
		$custom_css .= '.%1$s .section_portfolio.style-1 .tabs-menu-item:hover {color:%3$s}' ."\n";
		$custom_css .= '.%1$s .section_portfolio.style-1 .tabs-menu-item:after {border-color:%3$s}' ."\n";

		$custom_css .= '.%1$s .section_portfolio.style-1 .tabs-menu-item.active {color:%3$s}' ."\n";
		$custom_css .= '.%1$s .section_portfolio.style-1 .tabs-menu-item.active:after {border-color:%3$s}' ."\n";

	}
	if( !empty( $atts['bg_hover_color'] ) ){
		$custom_css .= '.%1$s .section_portfolio.style-1 .tabs-content-item .item__img:after {background-color:%6$s;}' ."\n";
	}
} else {
	if( !empty( $atts['text_filter_color'] ) ){
		$custom_css .= '.%1$s .section_portfolio.style-3 {color:%2$s;}' ."\n";
	}
	if( !empty( $atts['text_filter_hover_color'] ) ){
		$custom_css .= '.%1$s .section_portfolio.style-3 .tabs-menu-item:hover {color:%3$s}' ."\n";
		$custom_css .= '.%1$s .section_portfolio.style-3 .tabs-menu-item.active {color:%3$s}' ."\n";
	}
	if( !empty( $atts['filter_bg_color'] ) ){
		$custom_css .= '.%1$s .section_portfolio.style-3 .tabs-menu-item {background:%4$s;}' ."\n";
	}
	if( !empty( $atts['filter_bg_hover_color'] ) ){
		$custom_css .= '.%1$s .section_portfolio.style-3 .tabs-menu-item:hover {background:%5$s}' ."\n";
		$custom_css .= '.%1$s .section_portfolio.style-3 .tabs-menu-item.active {background:%5$s}' ."\n";
	}
	if( !empty( $atts['bg_hover_color'] ) ){
		$custom_css .= '.%1$s .section_portfolio.style-3 .tabs-content-item .item__img:after {background-color:%6$s;}' ."\n";
	}
	if( !empty( $atts['border_color'] ) ){
		$custom_css .= '.%1$s .section_portfolio.style-3 .tabs-content-item .item__img {border-color:%7$s}' ."\n";
		$custom_css .= '.%1$s .section_portfolio.style-3 .tabs-content-item {border-color:%7$s; background:%7$s}' ."\n";
	}
}


if ( !empty( $custom_css ) ) {
	$custom_css = sprintf($custom_css,
			esc_attr($sc_id),
			esc_attr($atts['text_filter_color']),
			esc_attr($atts['text_filter_hover_color']),
			esc_attr($atts['filter_bg_color']),
			esc_attr($atts['filter_bg_hover_color']),
			esc_attr($atts['bg_hover_color']),
			esc_attr($atts['border_color'])
			);
	do_action( COSMOS_CORE_ADD_INLINE_CSS, $custom_css );
}
$style_portfolio = '';
if($atts['style'] == 1) {
	$style_portfolio = 'style-1';
} else {
	$style_portfolio = 'style-3';
}

?>
<div class="pix-shortcode sc-portfolio <?php  echo esc_attr($block_class) ?> <?php echo esc_attr($css_animation_class); ?>"  data-animate="<?php echo esc_attr($css_animation); ?>" data-delay="<?php echo esc_attr($delay_animation); ?>" data-id="<?php echo esc_attr($sc_id) ?>">
	<div class="row-builder section_portfolio <?php echo esc_attr($style_portfolio) .' '. esc_attr($sc_id)?>" data-type="bg">
		<div class="content">
            <ul class="tabs-menu animate-run" data-animate="<?php echo esc_attr($css_animation); ?>">
            <?php
				/*
				%1$s is active class
				%2$s is slug
				%3$s is title
				*/
				$html_format = ('
					<li class="tabs-menu-item %1$s" data-tab="%2$s">
						<span data-type="title">%3$s</span>
					</li>
				');
				$html_option = array(
					'html_format'=> $html_format,
				);
				$model->get_filter($html_option);
			?>
            </ul>
            <div class="tabs-content">
            	<?php
					/*
					%1$s is image
					*/
					$html_format = ('
						<div class="tabs-content-item %1$s" data-tab="%2$s">
                    		<div class="row margin0 '.esc_attr($css_animation_parent_class).'" data-animate="'.esc_attr($css_animation_parent).'" data-delay="'.esc_attr($delay_animation_parent).'">
								%3$s
							</div>
						</div>
					');
					$html_option = array(
						'html_format'=> $html_format,
					);
					$model->render_portfolio_sc($html_option);
				?>  
            </div>
        </div>
	</div>
</div>