<?php
$uniq_id = 'sc-carousel-'.esc_attr( $id );
$custom_css = '';
$size_img = '';
if($size == 1) {
	$size_img = 'full';
} elseif ($size == 2) {
	$size_img = 'cosmos-thumb-300x550';
} elseif ($size == 3) {
	$size_img = 'cosmos-thumb-400x300';
} elseif ($size == 4) {
	$size_img = 'cosmos-thumb-600x600';
} elseif ($size == 5) {
	$size_img = 'cosmos-thumb-800x600';
}
if( !empty($dot_color) ) {
	$custom_css .= '.%1$s .owl-theme .owl-controls .owl-page span {background-color:%2$s}'."\n";
}
if( !empty($hover_dot_color) ) {
	$custom_css .= '.%1$s .blok-slider-feature5.owl-theme .owl-controls .owl-page:hover span {background-color:%3$s}'."\n";
}
if( !empty($active_dot_color) ) {
	$custom_css .= '.%1$s .blok-slider-feature5.owl-theme .owl-controls .owl-page.active span {background-color:%4$s}'."\n";
}

if ( !empty( $custom_css ) ) {
	$custom_css = sprintf($custom_css,
			esc_attr($uniq_id),
			esc_attr($dot_color),
			esc_attr($hover_dot_color),
			esc_attr($active_dot_color)
			);
	do_action( COSMOS_CORE_ADD_INLINE_CSS, $custom_css );
}
if(is_array($image_arr) || !empty($image_arr)) {
?>
<div data-id="<?php echo esc_attr($uniq_id)?>" class="pix-shortcode sc-carousel <?php echo esc_attr($uniq_id).' '.esc_attr( $extra_class )?> animate-run" data-animate="<?php echo esc_attr($css_animation); ?>" data-delay="<?php echo (int) esc_attr($delay_animation); ?>">
	<div class="row list-feature5">
        <div class="wrapper-gallery carousel">
	        <div class="blok-slider-feature5 carousel-items" data-autoplay="<?php echo esc_attr($autoplay) ?>" data-item="<?php echo esc_attr($item) ?>">
	        <?php for ($i = 0; $i < count($image_arr); $i++) {
	        	if(!empty($image_arr[$i])) {
	        ?>
	        	<figure>
				<?php echo wp_get_attachment_image($image_arr[$i], $size_img ,false, array('class'=>'img-resposive img-full')); ?>
				</figure>
			<?php } } ?>
			</div>
		</div>
	</div>
</div>
<?php } ?>