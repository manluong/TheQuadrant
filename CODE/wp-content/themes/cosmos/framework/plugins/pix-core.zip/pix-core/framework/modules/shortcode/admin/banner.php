<?php
$style =array(
	esc_html__('Style 1','pix-core') => 1,
	esc_html__('Style 2','pix-core') => 2,
	esc_html__('Style 3','pix-core') => 3,
	esc_html__('Style 4','pix-core') => 4,
	esc_html__('Style 5','pix-core') => 5,
	esc_html__('Style 6','pix-core') => 6,
	esc_html__('Style 7','pix-core') => 7,
	esc_html__('Style 8','pix-core') => 8,
);
$true_false = array(
	esc_html('Yes', 'pix-core') => 'true',
	esc_html('No', 'pix-core')  => 'false'
);
$params = array(
	array(
		'type'        => 'dropdown',
		'admin_label' => true,
		'heading'     => esc_html__( 'Choose Banner', 'pix-core' ),
		'param_name'  => 'style',
		'value'		  => $style,
		'std'		  => '1'
	),
	array(
		'type'        => 'textarea',
		'heading'     => esc_html__( 'Header Title', 'pix-core' ),
		'param_name'  => 'header',
	),
	array(
		'type'        => 'textarea',
		'heading'     => esc_html__( 'Description', 'pix-core' ),
		'param_name'  => 'description',
		'dependency'  => array(
            'element' => 'style',
            'value'   => array('1', '2' ,'3', '4', '5','7', '8')
        ),
	),
	array(
        'type' => 'param_group',
        'heading'     => esc_html__( 'The Features', 'pix-core' ),
        'param_name'  => 'features',
        'callbacks'   => array( 'after_add' => 'vcChartParamAfterAddCallback' ),
        'params' => array(
       		array(
                'type' => 'iconpicker',
                'heading' => esc_html__('Icon','pix-core'),
                'param_name' => 'vc_icon',
            	'description'=> esc_html__('Select icon from library','pix-core')
            ),
            array(
                'type' => 'colorpicker',
                'heading' => esc_html__('Icon Color','pix-core'),
                'param_name' => 'icon_color',
            ),
            array(
                'type' => 'textfield',
                'admin_label' => true,
                'heading' => esc_html__('Enter the title','pix-core'),
                'param_name' => 'title',
            ),
            array(
                'type' => 'textarea',
                'heading' => esc_html__('Enter the description','pix-core'),
                'param_name' => 'description',
            )
        ),
        'dependency'  => array(
            'element' => 'style',
            'value'   => array('6')
        ),
    ),
    array(
        'type' => 'param_group',
        'heading'     => esc_html__( 'The Carousel', 'pix-core' ),
        'param_name'  => 'carousel',
        'callbacks'   => array( 'after_add' => 'vcChartParamAfterAddCallback' ),
        'params' => array(
        	array(
                'type' => 'attach_image',
                'heading' => esc_html__('Choose Image','pix-core'),
                'param_name' => 'image',
            ),
            array(
                'type' => 'textfield',
                'admin_label' => true,
                'heading' => esc_html__('Enter the title','pix-core'),
                'param_name' => 'title',
            ),
            array(
                'type' => 'textarea',
                'heading' => esc_html__('Enter the description','pix-core'),
                'param_name' => 'description',
            )
        ),
        'dependency'  => array(
            'element' => 'style',
            'value'   => array('6')
        ),
    ),
    array(
        'type' => 'param_group',
        'heading'     => esc_html__( 'Button Link', 'pix-core' ),
        'param_name'  => 'btn_link',
        'callbacks'   => array( 'after_add' => 'vcChartParamAfterAddCallback' ),
        'params' => array(
        	array(
				'type'        => 'textfield',
				'admin_label' => true,
				'heading'     => esc_html__( 'Enter The Button Text', 'pix-core' ),
				'param_name'  => 'text',
			),
			array(
				'type'        => 'attach_image',
				'heading'     => esc_html__( 'Button Image', 'pix-core' ),
				'param_name'  => 'image',
			),
        	array(
				'type'        => 'vc_link',
				'heading'     => esc_html__( 'Link Setttings', 'pix-core' ),
				'param_name'  => 'link',
			),
			array(
				'type'        => 'colorpicker',
				'heading'     => esc_html__( 'Button Text Color', 'pix-core' ),
				'param_name'  => 'text_color',
			),
			array(
				'type'        => 'colorpicker',
				'heading'     => esc_html__( 'Button Text Color Hover', 'pix-core' ),
				'param_name'  => 'text_color_hover',
			),
			array(
				'type'        => 'colorpicker',
				'heading'     => esc_html__( 'Backround Color', 'pix-core' ),
				'param_name'  => 'bg_color',
			),
			array(
				'type'        => 'colorpicker',
				'heading'     => esc_html__( 'Backround Color Hover', 'pix-core' ),
				'param_name'  => 'bg_color_hover',
			),
			array(
				'type'        => 'attach_image',
                'heading'     => esc_html__( 'Backround Image', 'pix-core' ),
				'param_name'  => 'bg_img',
			)
        ),
        'dependency'  => array(
            'element' => 'style',
            'value'   => array('1','2','6','7','8')
        ),
    ),
	array(
		'type'        => 'attach_image',
		'heading'     => esc_html__( 'Upload Image', 'pix-core' ),
		'param_name'  => 'img_primary',
		'description' => esc_html__('Select image displayed','pix-core'),
		'dependency'  => array(
            'element' => 'style',
            'value'   => array('1','2','3')
        ),
	),
	array(
		'type'        => 'attach_images',
		'heading'     => esc_html__( 'Upload Images', 'pix-core' ),
		'param_name'  => 'images',
		'description' => esc_html__('Select images displayed','pix-core'),
		'dependency'  => array(
            'element' => 'style',
            'value'   => array('4','5','7','8')
        ),
	),
	array(
		'type'        => 'pix_attach_video',
		'heading'     => esc_html__( 'Upload Video', 'pix-core' ),
		'param_name'  => 'video',
		'description' => esc_html__('Upload video for background','pix-core'),
		'dependency'  => array(
            'element' => 'style',
            'value'   => array('4')
        ),
	),
	array(
		'type'        => 'textfield',
		'heading'     => esc_html__( 'Header Title Font Size', 'pix-core' ),
		'param_name'  => 'header_size',
		'description' => esc_html__('Choose font size for header title. Exam: 20px, 20em or 20% ','pix-core'),
		'group'		  => esc_html__('Options', 'pix-core')
	),
	array(
		'type'        => 'colorpicker',
		'heading'     => esc_html__( 'Header Title Color', 'pix-core' ),
		'param_name'  => 'header_color',
		'group'		  => esc_html__('Options', 'pix-core')
	),
	array(
		'type'        => 'colorpicker',
		'heading'     => esc_html__( 'Background Color', 'pix-core' ),
		'param_name'  => 'color_background',
		'group'		  => esc_html__('Options', 'pix-core'),
		'dependency'  => array(
            'element' => 'style',
            'value'   => array('4')
        ),
	),
	array(
		'type'        => 'attach_image',
		'heading'     => esc_html__( 'Background Image On Mobile', 'pix-core' ),
		'param_name'  => 'image_background_mb',
		'description' => esc_html__('Select background image displayed','pix-core'),
		'group'		  => esc_html__('Options', 'pix-core'),
		'dependency'  => array(
            'element' => 'style',
            'value'   => array('4')
        ),
	),
	array(
		'type'        => 'colorpicker',
		'heading'     => esc_html__( 'Slides Content Color', 'pix-core' ),
		'param_name'  => 'slides_color',
		'description' => 'Set color for all slides',
		'group'		  => esc_html__('Css', 'pix-core'),
		'dependency'  => array(
            'element' => 'style',
            'value'   => array('6')
        ),
	),
	array(
		'type'        => 'colorpicker',
		'heading'     => esc_html__( 'Features Content Color', 'pix-core' ),
		'param_name'  => 'features_color',
		'description' => 'Set color for all features',
		'group'		  => esc_html__('Css', 'pix-core'),
		'dependency'  => array(
            'element' => 'style',
            'value'   => array('6')
        ),
	),
	array(
		'type'        => 'dropdown',
		'heading'     => esc_html__( 'Auto Play', 'pix-core' ),
		'param_name'  => 'autoplay',
		'value'		  => $true_false,
		'std'		  => 'true',
		'description' => esc_html__('Turn autoplay yes or no for the slider'),
		'group'		  => esc_html__('Carousel', 'pix-core'),
		'dependency'  => array(
            'element' => 'style',
            'value'   => array('6','7', '8')
        ),
	),
	array(
		'type'        => 'textfield',
		'heading'     => esc_html__( 'Auto Play Time Out', 'pix-core' ),
		'param_name'  => 'timeout',
		'value'  	  => '3000',
		'description' => esc_html__('Set autoplay timing (miliseconds) between slides'),
		'group'		  => esc_html__('Carousel', 'pix-core'),
		'dependency'  => array(
            'element' => 'autoplay',
            'value'   => array('true')
        ),
	),
	array(
		'type'        => 'textfield',
		'heading'     => esc_html__( 'Extra Class', 'pix-core' ),
		'param_name'  => 'extra_class',
		'description' => esc_html__( 'Enter extra class.', 'pix-core' ),
	)
);
vc_map(array(
	'name'               => esc_html__( 'PIX Banner', 'pix-core' ),
	'base'               => 'pixcore_banner_sc',
	'class'              => 'pixcore-sc',
	'icon'               => 'icon-pixcore_banner_sc',
	'category'           => COSMOS_CORE_SC_CATEGORY,
	'description'        => esc_html__( 'Banner of header', 'pix-core' ),
	'params'             => $params
));