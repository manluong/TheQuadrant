<?php
Cosmos_Core::load_class( 'models.Blog_Model' );

class Cosmos_Core_Blog extends Cosmos_Core_Blog_Model {

	private $row_post_counter = 0;
	private $row_counter;
	private $post_counter = 0;
	private $block_atts;
	
	public $large_image_post = true;
	public $start_group = true;
	public $show_full_meta = true;
	public $show_widget_meta = false;
	public $html_format;

	public function init( $atts ) {
		// default
		$this->large_image_post = true;
		$this->start_group = true;
		$this->row_post_counter = 0;
		$this->row_counter = 1;
		$this->post_counter = 0;

		// set attributes
		$atts = $this->get_block_setting($atts);
		$this->block_atts = $atts;
		$this->set_attributes( $atts );
		$this->block_atts['block-class'] = $this->attributes['block-class'];

		$this->get_thumb_size();
		$this->set_responsive_class($atts);
		// add inline css
		$custom_css = $this->add_custom_css($atts);
		if( $custom_css ) {
			do_action( COSMOS_CORE_ADD_INLINE_CSS, $custom_css );
		}
	}
	public function set_post_options_defaults( $atts ) {
		$default = array(
			'large_post_format' => '',
			'small_post_format' => '',
			'open_group'        => '',
			'open_row'          => '',
			'close_row'         => '',
			'close_group'       => '',
			'content_length'    => '',
			'large_post_counter'=> 1,
			'show_related_post' => '',
			'new_row'           => '1',
			'thumb_href_class'  => '',
			'show_full_meta'    => '',
			'show_widget_meta'  => '',
			'meta_more_format'  => '',
			'html_format'       => '',
			'image_format'			=> '<div class="wp-img"><a href="%1$s">%2$s</a></div>',
			'meta_info_format'  => '<div class="wrapper-infomation"><div class="content-text">%1$s</div></div>',
			'author_format'		=> '<div class="meta-item author"><a href="%1$s">%2$s</a></div>',
			'views_format'		=> '<div class="meta-item views">%2$s %1$s</div>',
			'comments_format'	=> '<div class="meta-item comment"><a href="%3$s">%2$s %1$s</a></div>',
			'title_format'		=> '<p class="title"><a href="%2$s" title="%1$s">%1$s</a></p>',
			'category_format'	=> '<a href="%1$s" title="%2$s"><p class="topic">%2$s</p></a>',
			'date_format'		=> '<div class="timeline-date non-hover">
										
											<span data-type="date">%2$s</span>
											<span data-type="month">%3$s</span>
											<span data-type="year">%4$s</span>
										
									</div>',
			'excerpt_format'    => '<div class="text">%1$s</div>',
			'video_format'      => '<div class="video-thumbnail">
										<div class="video-bg">
											%2$s
										</div>
										<div class="video-button-play"><i class="icons fa fa-play"></i></div>
										<div class="video-button-close"><i class="fa fa-times"></i></div>
										%1$s
									</div>',
			'no_thumbnails_image' => '',
			'bg_image' 			=> '',
		);
		foreach($default as $key => $val ) {
			if( isset( $atts[$key] ) ) {
				$default[$key] = $atts[$key];
				unset( $atts[$key] );
			}
		}
		if( $atts ) {
			foreach($atts as $key => $val ) {
				$default[$key] = $atts[$key];
			}
		}
		return $default;
	}
	public function set_responsive_class($atts) {
		$class = '';
		$column = $this->attributes['column'];
		if( isset($atts['res_class']) ) {
			$class = $atts['res_class'];
		}
		$def = array(
			'1' => 'col-xs-12 column-1' . $class,
			'2' => 'col-sm-6 col-xs-12 column-2' . $class,
			'3' => 'col-md-4 col-sm-6 col-xs-12 column-3' . $class,
			'4' => 'col-lg-3 col-md-3 col-sm-6 col-xs-12 column-4' . $class,
		);;
		
		if( $column && isset($def[$column])) {
			$this->attributes['responsive-class'] = $def[$column];
		} else {
			$this->attributes['responsive-class'] = $def['3'];
		}
	}
	public function add_custom_css() {
		$css = '';
		$sc_id = $this->attributes['block-class'];
		if(!empty($this->attributes['category_color'])){
			$css.= sprintf('.%1$s .topic a{color:%2$s;}',
				$sc_id,
				$this->attributes['category_color']
			);
		}
		if(!empty($this->attributes['title_color'])){
			$css.= sprintf('.%1$s .title a{color:%2$s;}',
				$sc_id,
				$this->attributes['title_color']
			);
		}
		if(!empty($this->attributes['meta_color'])){
			$css.= sprintf('.%1$s .meta-item a, .%1$s .meta-item{color:%2$s;}',
				$sc_id,
				$this->attributes['meta_color']
			);
		}
		if(!empty($this->attributes['excerpt_color'])){
			$css.= sprintf('.%1$s .text{color:%2$s;}',
				$sc_id,
				$this->attributes['excerpt_color']
			);
		}
		if(!empty($this->attributes['button_color'])){
			$css.= sprintf('.%1$s .link_posts{background-color:%2$s !important;}',
				$sc_id,
				$this->attributes['button_color']
			);
		}
		if(!empty($this->attributes['button_color_hv'])){
			$css.= sprintf('.%1$s .link_posts:hover{background-color:%2$s !important;}',
				$sc_id,
				$this->attributes['button_color_hv']
			);
		}
		return $css;
	}
	private function get_thumb_size() {
		$params = Cosmos_Core_Params::block_image_size();
		if( !isset($params[$this->attributes['layout']]) ) {
			$this->attributes['thumb-size'] = array(
				'large'          => 'post-thumbnail',
				'no-image-large' => 'thumb-800x600.gif',
			);
		}
		else {
			$this->attributes['thumb-size'] = Cosmos_Core_Util::get_thumb_size( $params[$this->attributes['layout']], $this->attributes );
		}
	}

	private function get_block_setting( $atts ) {
		$displays = array(
			'show_category'        => '',
			'show_tag'             => '',
			'show_comment'         => '',
			'show_views'           => '',
			'show_date'            => '',
			'show_author'          => '',
			'show_excerpt'         => '',
			'show_meta'            => '',
			'content_length'       => '',
			'title_length'         => '',
		);
		$displays['layout'] = $atts['layout'];
		if( function_exists( 'cosmos_get_block_options')){
			cosmos_get_block_options( $displays );
		}
		foreach( $displays as $key => $val ) {
			if( ! isset($atts[$key]) ) {
				$atts[$key] = $displays[$key];
			} else if( ($atts[$key] == 'no' || $atts[$key] == 'hide') ) {
				$atts[$key] = 'hide';
			}
		}
		return $atts;
	}

	/**
	 * Render html to shortcode
	 *
	 * 1: image, 2: title, 3: meta, 4:button, 5: expert, 6: column, 7: post class
	 */
	public function render_grid( $html_options = array() ) {
		$this->html_format = $this->set_post_options_defaults( $html_options );
		$number_post = $this->query->query_vars['posts_per_page'] * ( $this->query->query_vars['paged'] -1 );
		if( $this->query->have_posts() ) {
			while ( $this->query->have_posts() ) {
				$this->query->the_post();
				$this->loop_index();
				$thumb_type = 'small';
				if ( !empty($this->attributes['column']) && $this->attributes['column'] < 3) {
					$thumb_type = 'large';
				}
				$gallery = '';
				if(get_post_format() == 'gallery'){
					$gallery = $this->get_meta_gallery_grid_image();
				}elseif(get_post_format() == 'video'){
					$gallery = $this->get_blog_video();
				}else{
					$gallery = $this->get_featured_image($thumb_type,false, $this->html_format);
				}
				$result = array(
					'IMAGE'=>$gallery,
					'TITLE'=>$this->get_title($this->html_format),
					'CATEGORY'=>$this->get_category_post($this->html_format),
					'META'=>$this->get_meta_info($this->html_format),
					'BUTTON'=>$this->get_button(),
					'EXCERPT'=>$this->get_excerpt_post(),
					'RESPONSIVE'=>$this->attributes['responsive-class'],
					'POST_CLASS'=>$this->get_post_class(),
					'DATE'=>$this->get_date($this->html_format)
				); 
				cosmos_printf( $this->html_format['html_format'], $result);
			}
			wp_reset_postdata();
		}
	}
	
	public function get_category_post($html_options = array()){
	    if(empty($this->attributes['show_category'])){
	        return null;
	    }
        return $this->get_category($html_options);
	}
	public function get_excerpt_post( $html_options = array() ) {
	    if(empty($this->attributes['show_content'])){
	        return null;
        }
		$output = '';
		$format = '%1$s';
		if ( isset($this->html_format['excerpt_format']) ) {
			$format = $this->html_format['excerpt_format'];
		}
		$excerpt = $this->get_excerpt();
		if( $this->attributes['show_content'] == 'content' ){
			$excerpt = apply_filters('the_content', get_the_content());
		}
		$limit   = $this->attributes['excerpt_length'];
		if( !empty( $limit ) ) {
			$excerpt = wp_trim_words($excerpt, $limit, ' […]');
		}
		$output = sprintf( $format, wp_kses_post($excerpt) );
		return $output;
	}

	public function get_meta_info( $html_options = array() ) {
		$meta_array = array(
			'author'	=> $this->get_author( $html_options ),
			'view'		=> $this->get_views( $html_options ),
			'comment'	=> $this->get_comments( $html_options )
		);
		$output = '';
		foreach( $meta_array as $key => $val ) {
			if( !empty( $val ) ) {
				$output .= $val;
			}
		}
		if( !empty( $output ) ) {
			$output = sprintf( $this->html_format['meta_info_format'], $output );
		}
		return $output;
	}
	
	public function get_meta_info_more( $seperate = '' ) {
		$meta_array = array(
			'comment'  => $this->get_comments(),
			'view'     => $this->get_views(),
		);
		foreach( $meta_array as $key => $val ) {
			if( empty( $val ) ) {
				unset($meta_array[$key]);
			}
		}
		if( isset($this->html_format['meta_seperate'])) {
			$seperate = $this->html_format['meta_seperate'];
		}
		$output = implode( $seperate, $meta_array );
		$format = $this->html_format['meta_info_format'];
		if( $output ) {
			$output = sprintf( $format, $output );
		}
		return $output;
	}
	
	public function get_meta( $seperate = '') {
		$output = '';
		if( $this->attributes['show_meta'] == 'hide' ) {
			return '';
		}
		if ( !$this->show_full_meta ){
			$output = $this->get_meta_info().$this->get_meta_info_more();
			return $output;
		}else{
			$meta_array = array(
				'category' => $this->get_category(),
				'date'     => $this->get_date(),
				'author'   => $this->get_author(),
				'view'     => $this->get_views(),
				'comment'  => $this->get_comments(),
				);
				foreach( $meta_array as $key => $val ) {
					if( empty( $val ) ) {
						unset($meta_array[$key]);
					}
				}
				$format = $this->html_format['meta_info_format'];
			if( $this->show_widget_meta ){
				$output = sprintf( $format, $this->get_date(), $this->get_comments(), $this->get_views());
				return $output;
			}else{
				if( isset($this->html_format['meta_seperate'])) {
					$seperate = $this->html_format['meta_seperate'];
				}
				$output= implode( $seperate, $meta_array );
				if( $output ) {
					$output = sprintf( $format, $output );
				}
				return $output;
			}
		}
	}
	
	public function get_button() {
		$format = '<a class="link_posts mg-t20" href="%1$s">%2$s</a>';
		if( isset($this->attributes['button_text']) && !empty( $this->attributes['button_text'] ) ) {
			return sprintf($format, $this->permalink, $this->attributes['button_text'] );
		}
	}
	public function get_meta_gallery_grid_image( $thumb_type = 'large', $thumb_size = '', $echo = false ) {
		$output = $thumb_img = $thumb_img_src = '';
		$gallery = get_post_meta(get_the_ID(), COSMOS_CORE_THEME_PREFIX. '_galleries', true);
        $galleryArr = explode(',', $gallery);
		$galleryArr = array_filter($galleryArr);
		if( $this->has_thumbnail ) {
			$thumb_id_post = get_post_thumbnail_id( $this->post_id );
			array_unshift($galleryArr, $thumb_id_post);
		}
		$get_post = get_post($this->post_id);
		if( !empty($galleryArr) && is_array($galleryArr) ) {
			foreach ($galleryArr as $thumb_id) {
				$get_attached_file = get_attached_file($thumb_id);
				if ( !file_exists($get_attached_file) ) {
					continue;
				}
				if( !empty($thumb_id) ) {
					$thumb_size = $this->attributes['thumb-size']['large'];
					$thumb_size_small = $this->attributes['thumb-size']['small'];
					$helper = new Cosmos_Core_Helper();
					$helper->regenerate_attachment_sizes($thumb_id, $thumb_size);
					$thumb_img = wp_get_attachment_image( $thumb_id, $thumb_size_small );
					$output .= sprintf( '%1$s', wp_kses_post($thumb_img));
				}
			}
		}
		return wp_kses_post($output);
	}
	public function get_blog_video($options = array()) {
		$output = $thumb_img = $img_cate = $iframe_video = '';
		//$options['thumb_href_class'] = 'link';
		
		// 1: thumbnail image
		$out_image = '%2$s';
		// 1: thumbnail image, 2: iframe
		$out_video = '<div class="video-youtube">%1$s<a class="button-play" href="javascript:void(0);" data-video="%2$s"><img src="'.COSMOS_PUBLIC_URI.'/images/button-play.png" alt="button play"></a></div>';
		$post_format = get_post_format( $this->post_id );
		$post_meta_video = get_post_meta( $this->post_id, COSMOS_CORE_THEME_PREFIX.'_feature_video', true );
		$is_video_type = false;
		if (!empty($post_meta_video)) {
			if ( $post_meta_video['video_type'] == 'youtube' && !empty($post_meta_video['youtube_id']) ) {
				$is_video_type = true;
			} elseif ( $post_meta_video['video_type'] == 'vimeo' && !empty($post_meta_video['vimeo_id']) ) {
				$is_video_type = true;
			}
		}
		if ($post_format == 'video' ) {
			if ($is_video_type == true) {
				$video_type = $post_meta_video['video_type'];
				if ($video_type == "youtube") {
					$iframe_video = 'https://www.youtube.com/embed/'.esc_attr( $post_meta_video['youtube_id'] );
				} elseif ($video_type == "vimeo") {
					$iframe_video = 'https://player.vimeo.com/video/'.esc_attr( $post_meta_video['vimeo_id'] );
				}
				$options['no_href_image'] = true;
			}
			$output = sprintf( $out_video, $this->get_featured_image('large', false, array('image_format'=>'%2$s')), $iframe_video );
		}else {
			$options['hide_no_image'] = true;
			$output = sprintf( $out_image, $this->get_featured_image( 'large', false, $options ) );
		}
		return $output;
	}
}