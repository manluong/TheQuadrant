<?php
$sc_controller = new Cosmos_Core_Shortcodes_Controller();
$method = array(
	esc_html__('Testimonials', 'pix-core')     => 'testi' ,
	esc_html__('Category', 'pix-core')=> 'cat',
);
$yes_no = array(
	esc_html__('Yes', 'pix-core')     => 'yes' ,
	esc_html__('No', 'pix-core')	  => 'no'
);
$style = array(
	esc_html__('Style 1', 'pix-core')     => '1' ,
	esc_html__('Style 2', 'pix-core')	  => '2'
);
$item = array(
	esc_html__('3','pix-core')	=> '3',
	esc_html__('4','pix-core')	=> '4',
);
$sort_by    = Cosmos_Core_Params::get('sort-other') ;
// get Testimonial categories
$taxonomy   = 'cosmos_testi_cat';
$params_cat = array('empty'=> esc_html__( '-- All Testimonial Categories --', 'pix-core' ) );
$categories = Cosmos_Core_Com::get_tax_options2slug( $taxonomy, $params_cat );
// get All Testimonial
$args       = array('post_type'=> 'cosmos_testi');
$options = array('empty'=> esc_html__( '-- All --', 'pix-core' ) );
$testi        = Cosmos_Core_Com::get_post_title2id( $args, $options );
$params = array(
	array(
		'type'       => 'dropdown',
		'admin_label'=> true,
		'heading'    => esc_html__( 'Style', 'pix-core' ),
		'param_name' => 'style',
		'value'      => $style,
		'description'=> esc_html__( 'Choose style of testimonials',  'pix-core'  ),
	),
	array(
		'type'       => 'dropdown',
		'heading'    => esc_html__( 'Items', 'pix-core' ),
		'param_name' => 'item',
		'value'      => $item,
		'description'=> esc_html__( 'Choose number item testimonials',  'pix-core'  ),
		'dependency'     => array(
			'element'			=> 'style',
			'value'           	=> array( '2' )
		),
		'group'      => esc_html__( 'Carousel', 'pix-core'),
	),
	array(
		'type'       => 'dropdown',
		'heading'    => esc_html__( 'Display by', 'pix-core' ),
		'param_name' => 'method',
		'value'      => $method,
		'description'=> esc_html__( 'Choose testimonial category or special testimonials to display.',  'pix-core'  ),
	),
	array(
		'type'       => 'param_group',
		'heading'    => esc_html__( 'Category', 'pix-core' ),
		'param_name' => 'category_list',
		'params'          => array(
			array(
				'type'       => 'dropdown',
				'admin_label'=> true,
				'heading'    => esc_html__( 'Add Category', 'pix-core' ),
				'param_name' => 'category_slug',
				'value'      => $categories,
				'description'=> esc_html__( 'Choose special category to filter', 'pix-core'  )
			),
		),
		'value'      => '',
		'dependency'     => array(
			'element'=> 'method',
			'value'           => array('cat' )
		),
		'description'=> esc_html__( 'Default no filter by category.', 'pix-core' ),
	),
	array(
		'type'       => 'param_group',
		'heading'    => esc_html__( 'Featured Testimonial Lists', 'pix-core' ),
		'param_name' => 'testi_list',
		'params'          => array(
			array(
				'type'       => 'dropdown',
				'admin_label'=> true,
				'heading'    => esc_html__( 'Add Featured Testimonial', 'pix-core' ),
				'param_name' => 'post_id',
				'value'      => $testi,
				'description'=> esc_html__( 'Choose featured testimonial to show', 'pix-core'  )
			),
		),
		'value'      => '',
		'dependency'     => array(
			'element'=> 'method',
			'value'           => array('testi' )
		),
		'description'=> esc_html__( 'Default empty.', 'pix-core' ),
	),
	array(
		'type'       => 'textfield',
		'heading'    => esc_html__( 'Limit Posts', 'pix-core' ),
		'param_name' => 'limit_post',
		'value'      => '',
		'dependency'     => array(
			'element'=> 'method',
			'value'           => array('cat' )
		),
		'description'=> esc_html__( 'Add limit posts per page. Set -1 or empty to show all.', 'pix-core' )
	),
	array(
		'type'       => 'textfield',
		'heading'    => esc_html__( 'Offset Posts', 'pix-core' ),
		'param_name' => 'offset_post',
		'value'      => '0',
		'dependency'     => array(
			'element'=> 'method',
			'value'           => array('cat' )
		),
		'description'=> esc_html__( 'Enter offset to pass over posts. If you want to start on record 6, using offset 5', 'pix-core' )
	),
	array(
		'type'       => 'dropdown',
		'heading'    => esc_html__( 'Sort By', 'pix-core' ),
		'param_name' => 'sort_by',
		'value'      => $sort_by,
		'description'=> esc_html__( 'Select order to display list properties.', 'pix-core' ),
	),
	array(
		'type'       => 'dropdown',
		'heading'    => esc_html__( 'Autoplay', 'pix-core' ),
		'param_name' => 'autoplay',
		'value'      =>$yes_no,
		'description'=> esc_html__( 'Choose autoplay mode.', 'pix-core' ),
		'group'      => esc_html__( 'Carousel', 'pix-core'),
	),
	array(
		'type'       => 'dropdown',
		'heading'    => esc_html__( 'Show Navigations', 'pix-core' ),
		'param_name' => 'show_nav',
		'value'      => $yes_no,
		'description'=> esc_html__( 'Choose display for navigations.', 'pix-core' ),
		'group'      => esc_html__( 'Carousel', 'pix-core'),
	),
	array(
		'type'       => 'colorpicker',
		'heading'    => esc_html__( 'Name Color', 'pix-core' ),
		'param_name' => 'name_color',
		'description'=> esc_html__( 'Choose color for name.', 'pix-core' ),
		'group'      => esc_html__('Custom Css', 'pix-core'),
	),
	array(
		'type'       => 'colorpicker',
		'heading'    => esc_html__( 'Position Color', 'pix-core' ),
		'param_name' => 'position_color',
		'description'=> esc_html__( 'Choose color for position.', 'pix-core' ),
		'group'      => esc_html__('Custom Css', 'pix-core'),
	),
	array(
		'type'       => 'colorpicker',
		'heading'    => esc_html__( 'Description Color', 'pix-core' ),
		'param_name' => 'description_color',
		'value'      => '',
		'description'=> esc_html__( 'Choose color for description.', 'pix-core' ),
		'group'      => esc_html__( 'Custom Css', 'pix-core'),
	),
	array(
		'type'       => 'colorpicker',
		'heading'    => esc_html__( 'Border Avatar Color', 'pix-core' ),
		'param_name' => 'bor_color',
		'value'      => '',
		'description'=> esc_html__( 'Choose color for border around avatar.', 'pix-core' ),
		'group'      => esc_html__( 'Custom Css', 'pix-core'),
		'dependency'     => array(
			'element'		=> 'style',
			'value'         => array( '1' )
		),
	),
	array(
		'type'       => 'colorpicker',
		'heading'    => esc_html__( 'Background Color', 'pix-core' ),
		'param_name' => 'bg_color',
		'value'      => '',
		'description'=> esc_html__( 'Choose color for background.', 'pix-core' ),
		'group'      => esc_html__( 'Custom Css', 'pix-core'),
		'dependency'     => array(
			'element'		=> 'style',
			'value'         => array( '2' )
		),
	),
	array(
		'type'       => 'colorpicker',
		'heading'    => esc_html__( 'Navigations Color', 'pix-core' ),
		'param_name' => 'nav_color',
		'value'      => '',
		'description'=> esc_html__( 'Choose color for navigations.', 'pix-core' ),
		'group'      => esc_html__( 'Custom Css', 'pix-core'),
		'dependency'     => array(
			'element'		=> 'show_nav',
			'value'         => array( 'yes' )
		),
	),
	array(
		'type'       => 'colorpicker',
		'heading'    => esc_html__( 'Dots Color', 'pix-core' ),
		'param_name' => 'dot_color',
		'value'      => '',
		'description'=> esc_html__( 'Choose color for dots.', 'pix-core' ),
		'group'      => esc_html__( 'Custom Css', 'pix-core'),
	),
	array(
		'type'       => 'colorpicker',
		'heading'    => esc_html__( 'Dots Color Hover/Active', 'pix-core' ),
		'param_name' => 'dot_color_hover',
		'value'      => '',
		'description'=> esc_html__( 'Choose color for dots when hover or active.', 'pix-core' ),
		'group'      => esc_html__( 'Custom Css', 'pix-core'),
	),

	array(
		'type'       => 'textfield',
		'heading'    => esc_html__( 'Extra Class', 'pix-core' ),
		'param_name' => 'extra_class',
		'description'=> esc_html__( 'Enter extra class name.', 'pix-core' ),
	),
	$sc_controller->cosmos_animation_style(),
	$sc_controller->cosmos_animation_delay()  
);
vc_map(array(
	'name'       => esc_html__( 'PIX Testimonial', 'pix-core' ),
	'base'       => 'pixcore_testimonial_sc',
	'class'      => 'pixcore-sc',
	'icon'       => 'icon-pixcore_testimonial_sc',
	'category'   => COSMOS_CORE_SC_CATEGORY,
	'description'=> esc_html__( 'List of testimonials.', 'pix-core' ),
	'params'     => $params
));