﻿(function($) {
    "use strict";

    $.cosmos_countdown_sc = function() {
    	if($('.sc_count_down').length) {
			$(".sc_count_down").each(function(){
				var id_sc = $(this).attr('id');
    			var deadline = $('#' + id_sc + ' .col-center').attr('data-time');
				jQuery.initializeClock($(this), deadline);
			});
		}
    };

	// Blog galleries
	$.cosmos_core_blog = function(){

        if($('.sc-blog-list').length){
            $('.sc-blog-list').find('.button-play').click(function(){
                if($(this).data('video') != ''){
                    var video = $(this).data('video');
                    $(this).after('<iframe style="display:block;" class="iframe-youtube" src="'+video+'?autoplay=1&rel=0" frameborder="0" allowfullscreen></iframe>');
                    $(this).parents('.posts').find('.timeline-date').slideUp();
                }
            });
            $('.sc-blog-list').each(function(){
                var block_id = '#' + $(this).attr('id') + ' ';
                var slider = block_id+ '.blog-galleries';
                $(slider).each(function(index){
	                if($(this).children('img').length > 1){
                        var opt_timeout = '';
                        var data_autoplay = $(slider).data('autoplay');
                        var data_timeout = $(slider).data('timeout');
                        
                        if(typeof data_autoplay !== 'undefined'){
                            opt_timeout = data_autoplay;
                            if(data_autoplay == true) {
                                if(typeof data_timeout !== 'undefined'){
                                    opt_timeout = data_timeout;
                                    if(data_timeout == '') {
                                        opt_timeout = false;
                                    }
                                }
                            }
                        }
                        var owl = $(this);
                        setTimeout(function(){
                            owl.owlCarousel({
                                loop:true,
                                nav:false,
                                pagination : false,
                                dots: false,
                                smartSpeed:1000,
                                autoPlay: opt_timeout,
                                stopOnHover:true,
                                singleItem:true,
    	                    });
                            owl.append('<div class="pre-next-controls"><div class="carousel-prev"><i class="fa fa-angle-left" aria-hidden="true"></i></div><div class="carousel-next"><i class="fa fa-angle-right" aria-hidden="true"></i></div></div>');
                            owl.find(".carousel-prev").on('click',function(){
    	                    	owl.trigger('owl.prev');
    						});
    						owl.find(".carousel-next").on('click',function(){
    	                    	owl.trigger('owl.next');
    						});
                        }, 1000);

	                }
                });
            });
        }
    }

	//banner
	$.cosmos_banner_sc = function(){
		if($('.sc-banner').length){
            $('.sc-banner').each(function(){
                var block_id = '#' + $(this).attr('id') + ' ';
                var slider = $(block_id).find('.slider-carousel');
                var slider_3d = $(block_id).find('.slider-3d');
                if(slider_3d.children().length > 0){
                    var opt_autoplay = 'true';
                    var data_autoplay = slider_3d.data('autoplay');
                    if(typeof data_autoplay !== 'undefined'){
                        opt_autoplay = data_autoplay;
                    }
                    var opt_timeout = '3000';//milisecond
                    var data_timeout = slider_3d.data('timeout');
                    if(typeof data_timeout !== 'undefined'){
                        opt_timeout = data_timeout;
                    }
                    slider_3d.first().addClass('dg-center');
                    slider_3d.gallery({
                        autoplay:opt_autoplay,
                        interval:opt_timeout
                    });
                }

                if(slider.children().length> 1){
                	var opt_timeout = 'false';
                    var data_autoplay = slider.data('autoplay');
                    if(typeof data_autoplay !== 'undefined'){
                        opt_timeout = data_autoplay;
                        var data_timeout = slider.data('timeout');
                        if(typeof data_timeout !== 'undefined'){
                            opt_timeout = data_timeout;
                        }
                    }
                	setTimeout(function(){
						slider.owlCarousel({
							smartSpeed: 1000,
							loop:true,
                            items: 1,
							singleItem: true,
							autoPlay:opt_timeout,
						});
                    }, 1000);
				}
            });
        }
	}
    //Timeline
	$.cosmos_timeline_sc = function(){
		if($('.sc-timeline').length){
		    $('.sc-timeline').find('.button-play').click(function(){
                $('.sc-timeline iframe').remove();
                $('.sc-timeline .button-close').hide();
                if($(this).data('video') != ''){
                    var video = $(this).data('video');
                    $(this).after('<iframe class="iframe-youtube" src="'+video+'?autoplay=1&rel=0&wmode=transparent" frameborder="0" allowfullscreen></iframe>');
                    $(this).parents('.img-wrap').find('.timeline-date').slideUp();
                    $(this).prev('.button-close').show();
                }
            });
            $('.sc-timeline').find('.button-close').click(function(){
                $(this).hide();
                $(this).parents('.video-youtube').find('iframe').remove();
                $(this).parents('.img-wrap').find('.timeline-date').slideDown();
            });
            $('.sc-timeline').each(function(){
                var block_id = '#' + $(this).attr('id') + ' ';
                var modal = $(block_id).find('.timeline-modal');
                var total_item = $(block_id + 'ul.timeline > li.item').length;
                if(total_item > 0){
                    var show_items =  $(block_id + 'ul.timeline').data("show");
                    var count_show = show_items;
                    $(block_id + 'ul.timeline > li.item').each(function(index){
                        if(index < show_items){
                            $(this).addClass('show').removeClass('hidden');
                        }
                        var unique_id = makeid();
                        $(this).addClass(unique_id).attr('data-class', unique_id);
                        $(this).find('.timeline-button').addClass(unique_id).data('class', unique_id);
                    });
                    if(show_items >= total_item){
                        //remove button show more
                        $(block_id+".timeline-button.show-more").hide();
                    }
                    $(block_id+".timeline-button.show-more").click(function(){
                 		for(var i=0; i < show_items; i++){
                 			$(block_id + 'ul.timeline').children('li.item').eq(count_show).removeClass("hidden").addClass("animated fadeInUp show");
                            count_show++;
                 		}
                        if(count_show >= total_item){
                            $(this).remove();
                        }
                 	});
                    $('a.timeline-button.item').click(function(){
                        var items_show = $(block_id + 'ul.timeline').children('li.item.show').length;
                        var class_current = $(this).data('class');
                        if(modal.not('.in')){
                            modal.modal();
                        }
                        modal.find('.timeline-prev, .timeline-next').addClass('active').data('class', class_current);
                        if($('li.'+class_current).index() == 0){
                            modal.find('.timeline-prev').removeClass('active');
                        }
                        if($('li.item.show.'+class_current).index() >= items_show -1 ){
                            modal.find('.timeline-next').removeClass('active');
                        }
                        var popup = $('li.'+class_current).find('.timeline-popup').html();
                        modal.find('.modal-body').html(popup);
                        var title = modal.find('.timeline-title');
                        modal.find('.modal-title').html(title.html());
                        title.remove();
                        modal.find('.modal-body').find('.timeline-modal').removeClass('hide');
                    });
                    $('.timeline-prev').click(function(){
                        if($(this).hasClass('active')){
                            var class_current =$(this).data('class');
                            var className = $('li.'+class_current).prev('li.item.show').data('class');
                            if(typeof className != 'undefined'){
                                $(this).data('class', className);
                                $('a.'+className).click();
                            }
                        }
                    });
                    $('.timeline-next').click(function(){
                        if($(this).hasClass('active')){
                            var class_current =$(this).data('class');
                            var className = $('li.'+class_current).next('li.item.show').data('class');
                            var removeActive = $('li.item.show'+class_current).index();
                            if(typeof className != 'undefined'){
                                $(this).data('class', className);
                                $('a.'+className).click();
                            }
                            if(removeActive >= total_item - 2){
                                $(this).removeClass('active');
                            }
                        }
                    });
                }
                var slider = block_id+ '.timeline-galleries';
                $(slider).each(function(index){
	                if($(this).children('img').length > 1){
                        var opt_autoplay = 'false';
                        var data_autoplay = $(slider).data('autoplay');
                        if(typeof data_autoplay !== 'undefined'){
                            opt_autoplay = data_autoplay;
                        }
                        var opt_timeout = '3000';//milisecond
                        var data_timeout = $(slider).data('timeout');
                        if(typeof data_timeout !== 'undefined'){
                            opt_timeout = data_timeout;
                        }
                        var owl = $(this);
                        setTimeout(function(){
                            owl.owlCarousel({
	                            loop:true,
	                            nav:false,
                                pagination : false,
	                            dots: false,
	                            smartSpeed:1000,
	                            autoPlay: false,
	                            autoplayTimeout:opt_timeout,
                                stopOnHover:true,
	                            singleItem:true,
                                autoHeight: true,
    	                    });
                            owl.append('<div class="pre-next-controls"><div class="carousel-prev"><i class="fa fa-angle-left" aria-hidden="true"></i></div><div class="carousel-next"><i class="fa fa-angle-right" aria-hidden="true"></i></div></div>');
                            owl.find(".carousel-prev").on('click',function(){
    	                    	owl.trigger('owl.prev');
    						});
    						owl.find(".carousel-next").on('click',function(){
    	                    	owl.trigger('owl.next');
    						});
                        }, 1000);

	                }
                });
            });
        }
	}

    //toggle box
    $.cosmos_toggle_box_sc = function(){
    	if($('.sc-toggle-box').length || $('.sc-faq').length) {
    		$(".section_faq .faq-question").click(function(){
				if($(this).parent(".faq-item").hasClass("active"))
				{
					$(this).next(".faq-answer").slideUp();
					$(this).parent(".faq-item").removeClass("active");
				}
				else
				{
					$(this).next(".faq-answer").slideDown();
					$(this).parent(".faq-item").addClass("active");
				}
			});
    	}
    }

    //carousel
    $.cosmos_carousel = function(){
    	if($('.sc-carousel').length){
    		$('.sc-carousel').each(function(){
    			var block_id = $(this).data('id');
    			var class_block_id = '.'+ block_id +' ';
    			var slider = $(class_block_id+ '.blok-slider-feature5');
	    		var data_items = slider.attr('data-item');
	    		var data_autoplay = slider.attr('data-autoplay');
	    		var opt_loop = '';
	    		var opt_autoplay = '';
	            if(typeof data_autoplay !== 'undefined'){
	                opt_autoplay = data_autoplay;
	                if(data_autoplay !== 'no') {
	                	opt_loop = true;
	                	opt_autoplay = true;
	                } else {
	                	opt_loop = false;
	                	opt_autoplay = false;
	                }
	            }
	            var opt_items = 1;
                var opt_itemsdesktop = 1;
                var opt_itemsdesktopsmall = 1;
                var opt_itemstable = 1;
                var opt_itemsmobile = 1;
	            if(typeof data_items !== 'undefined'){
	                opt_items = data_items;
	                if(opt_items == 4){
                        opt_itemsdesktop = 4;
                        opt_itemsdesktopsmall = 3;
                        opt_itemstable = 2;
                        opt_itemsmobile = 1;
                    }
                    if(opt_items == 3) {
                        opt_itemsdesktop = 3;
                        opt_itemsdesktopsmall = 3;
                        opt_itemstable = 2;
                        opt_itemsmobile = 1;
                    }
                    if(opt_items == 2) {
                        opt_itemsdesktop = 2;
                        opt_itemsdesktopsmall = 2;
                        opt_itemstable = 2;
                        opt_itemsmobile = 1;
                    }
	            }
				slider.owlCarousel({
					loop: opt_loop,
					pagination:true,
					autoplay: opt_autoplay,
					autoplayTimeout: 3000,
					autoplayHoverPause:true,
					items:opt_items,
					itemsCustom : false,
                    itemsDesktop : [1199,opt_itemsdesktop],
                    itemsDesktopSmall : [980,opt_itemsdesktopsmall],
                    itemsTablet: [768,opt_itemstable],
                    itemsTabletSmall: false,
                    itemsMobile : [479,opt_itemsmobile]
				});
			});
		}
    }

    //demo app
    $.cosmos_demo_app = function(){
    	if($('.sc-demo-app').length) {
            var col_right=$(".sc-demo-app .section_demo.style-2 .col-right");
            var col_left =$(".sc-demo-app .section_demo.style-2 .col-left");
	    	if($(window).width() > 1200){
				if(col_right.outerHeight() < 670 && col_left.outerHeight() < 670){
					col_right.css("height","670px");
					col_left.css("height","670px");
				}
				else{
					if(col_right.outerHeight() > col_left.outerHeight()){
						col_left.css("height",col_right.outerHeight());
						col_right.css("height",col_right.outerHeight())
					}
					else{
						col_right.css("height",col_left.outerHeight());
						col_left.css("height",col_left.outerHeight());
					}
				}
			} else {
                col_left.removeAttr('style');
                col_right.removeAttr('style');
            }
			if($(window).width()>=768){
				$(".sc-demo-app .fancybox-video").fancybox({
				  maxWidth : 800,
				  maxHeight : 700,
				  fitToView : false,
				  width  : '70%',
				  height  : '70%',
				  autoSize : false,
				  closeClick : false,
				  openEffect : 'none',
				  closeEffect : 'none',
				  helpers: {
				   overlay: {
				     locked: false
				   }
				    }
				 });
			}
			else{
				$(".sc-demo-app .fancybox-video").fancybox({
				  maxWidth : 800,
				  maxHeight : 700,
				  fitToView : false,
				  width  : '70%',
				  height  : '70%',
				  autoSize : false,
				  closeClick : false,
				  openEffect : 'none',
				  closeEffect : 'none',
				  helpers: {
				   overlay: {
				     locked: false
				   }
				    }
				 });
			}
		}
    }

    //count download
    $.cosmos_count_download_sc = function(){
    	$(window).on("load",function(){
		    $(".sc-count-download .download-number").removeClass("finish_count_up");
		})

		$(window).on("scroll",function(){
		    var window_offset_top = $(window).scrollTop();
		    var window_offset_bottom =$(window).scrollTop() + $(window).height();

		    $('.sc-count-download .download-number').each(function () {
		        var element_offset_top = $(this).offset().top;
		        var element_offset_bottom= $(this).offset().top + $(this).height();
		        if(element_offset_top >= window_offset_top && element_offset_bottom <= window_offset_bottom && !$(this).hasClass("finish_count_up"))
		        {
		            $(this).prop('Counter',0).animate({
		                Counter: $(this).text()
		            }, {
		                duration: 1500,
		                easing: 'swing',
		                step: function (now) {
		                    $(this).children().text(Math.ceil(now));
		                }
		            });
		            $(this).addClass("finish_count_up");
		        }
		    });
		})
    }
    
    $.cosmos_play_video = function(){
        if($('.sc-banner .play-vides').length > 0){
            var h_video = $('.sc-banner .h-option-4 video').height();
            var h_video_o = $('.sc-banner .h-option-4 video').outerHeight();
            var parent = $('.h-option-4');
            if($(window).width() >= 768){
                parent.css({
                    'height': h_video_o +'px'
                });
            }else{
                parent.css({
                    'height': 'auto'
                });
            }
			$('.sc-banner .play-vides').click(function(){
                $.video = $(this).next('video');
                // $.video.toggle();
				if($(this).hasClass('play--vide')){
					$(this).removeClass('play--vide');
					$.video.trigger('pause');
					$('.bg-h-4-des').animate({
						'opacity': 1
					},300);
					$('.page-custom-4 > img').animate({
						'opacity': 1
					},400);
				}else{
					$.video.trigger('play');
					$(this).addClass('play--vide');
					$('.bg-h-4-des').animate({
						'opacity': 0
					},400);
					$('.page-custom-4 > img').animate({
						'opacity': 0
					},400);
				}
			});
		}
	}

    /*BEGIN Google map shortcode */
    $.cosmos_google_map_sc = function() {
        var maps = Array();
        var markers = Array();
        var info_windows = Array();
        var locations = Array();
        var bounds = Array();
        var current_info_window = null;
        var current_map_id = null;
        var style_map_1 = [{"featureType":"administrative","elementType":"labels","stylers":[{"visibility":"on"},{"gamma":"1.82"}]},{"featureType":"administrative","elementType":"labels.text.fill","stylers":[{"visibility":"on"},{"gamma":"1.96"},{"lightness":"-9"}]},{"featureType":"administrative","elementType":"labels.text.stroke","stylers":[{"visibility":"off"}]},{"featureType":"landscape","elementType":"all","stylers":[{"visibility":"on"},{"saturation":"-75"},{"lightness":"7"},{"gamma":"1.69"}]},{"featureType":"poi","elementType":"geometry.fill","stylers":[{"hue":"#00f5ff"},{"saturation":"-47"}]},{"featureType":"poi","elementType":"labels.text","stylers":[{"visibility":"simplified"},{"hue":"#ff8000"},{"lightness":"28"},{"saturation":"19"}]},{"featureType":"poi.business","elementType":"all","stylers":[{"visibility":"off"}]},{"featureType":"poi.park","elementType":"all","stylers":[{"visibility":"off"}]},{"featureType":"road","elementType":"geometry.stroke","stylers":[{"visibility":"off"}]},{"featureType":"road","elementType":"labels.icon","stylers":[{"visibility":"off"}]},{"featureType":"road.highway","elementType":"geometry","stylers":[{"hue":"#ffaa00"},{"saturation":"-43"},{"visibility":"on"}]},{"featureType":"road.highway","elementType":"geometry.stroke","stylers":[{"visibility":"off"}]},{"featureType":"road.highway","elementType":"labels","stylers":[{"visibility":"simplified"},{"hue":"#ffaa00"},{"saturation":"-70"}]},{"featureType":"road.highway.controlled_access","elementType":"labels","stylers":[{"visibility":"on"}]},{"featureType":"road.arterial","elementType":"all","stylers":[{"visibility":"on"},{"saturation":"-100"},{"lightness":"30"}]},{"featureType":"road.local","elementType":"all","stylers":[{"saturation":"-100"},{"lightness":"40"},{"visibility":"off"}]},{"featureType":"transit.station.airport","elementType":"geometry.fill","stylers":[{"visibility":"on"},{"gamma":"0.80"}]},{"featureType":"water","elementType":"all","stylers":[{"visibility":"off"}]}];
        var style_map_2 = [{"featureType":"administrative.locality","elementType":"labels","stylers":[{"visibility":"on"}]},{"featureType":"administrative.locality","elementType":"labels.text.fill","stylers":[{"color":"#000000"},{"visibility":"on"}]},{"featureType":"administrative.locality","elementType":"labels.text.stroke","stylers":[{"visibility":"on"},{"color":"#ffffff"},{"weight":"0.75"}]},{"featureType":"landscape.natural","elementType":"geometry.fill","stylers":[{"visibility":"on"},{"color":"#ded7c6"}]},{"featureType":"poi","elementType":"geometry.fill","stylers":[{"visibility":"on"},{"color":"#ded7c6"}]},{"featureType":"road","elementType":"geometry","stylers":[{"lightness":100},{"visibility":"simplified"}]},{"featureType":"road","elementType":"labels","stylers":[{"visibility":"off"}]},{"featureType":"transit.line","elementType":"geometry","stylers":[{"visibility":"on"},{"lightness":700}]},{"featureType":"water","elementType":"all","stylers":[{"color":"#c3a866"}]},{"featureType":"water","elementType":"labels","stylers":[{"visibility":"off"}]}];
        var style_map_3 = [{"featureType":"administrative","elementType":"labels.text.fill","stylers":[{"color":"#444444"}]},{"featureType":"administrative.country","elementType":"all","stylers":[{"visibility":"off"}]},{"featureType":"administrative.country","elementType":"geometry","stylers":[{"visibility":"off"}]},{"featureType":"administrative.country","elementType":"labels","stylers":[{"visibility":"off"}]},{"featureType":"administrative.province","elementType":"all","stylers":[{"visibility":"off"}]},{"featureType":"administrative.province","elementType":"labels","stylers":[{"visibility":"on"}]},{"featureType":"administrative.province","elementType":"labels.text","stylers":[{"visibility":"off"}]},{"featureType":"administrative.locality","elementType":"all","stylers":[{"visibility":"on"}]},{"featureType":"administrative.locality","elementType":"labels","stylers":[{"visibility":"off"}]},{"featureType":"administrative.neighborhood","elementType":"all","stylers":[{"visibility":"off"}]},{"featureType":"administrative.neighborhood","elementType":"geometry","stylers":[{"visibility":"on"}]},{"featureType":"administrative.neighborhood","elementType":"labels","stylers":[{"visibility":"off"},{"saturation":"-1"}]},{"featureType":"administrative.land_parcel","elementType":"all","stylers":[{"visibility":"on"}]},{"featureType":"administrative.land_parcel","elementType":"labels","stylers":[{"visibility":"off"}]},{"featureType":"landscape","elementType":"all","stylers":[{"color":"#e5e5e5"},{"visibility":"on"}]},{"featureType":"landscape","elementType":"geometry","stylers":[{"visibility":"on"}]},{"featureType":"landscape","elementType":"labels","stylers":[{"visibility":"on"},{"saturation":"0"}]},{"featureType":"poi","elementType":"all","stylers":[{"visibility":"off"}]},{"featureType":"road","elementType":"all","stylers":[{"saturation":-100},{"lightness":45},{"visibility":"on"}]},{"featureType":"road","elementType":"labels","stylers":[{"visibility":"off"}]},{"featureType":"road","elementType":"labels.text","stylers":[{"visibility":"on"}]},{"featureType":"road.highway","elementType":"all","stylers":[{"visibility":"simplified"}]},{"featureType":"road.highway","elementType":"geometry","stylers":[{"visibility":"off"}]},{"featureType":"road.highway","elementType":"labels","stylers":[{"visibility":"off"}]},{"featureType":"road.arterial","elementType":"labels.icon","stylers":[{"visibility":"off"}]},{"featureType":"transit","elementType":"all","stylers":[{"visibility":"off"}]},{"featureType":"water","elementType":"all","stylers":[{"color":"#ffffff"},{"visibility":"on"}]}];

        if($('.sc-google-map').length) {
            var i = 0;
            var location_counter = 0;
            var map_elements = $('.sc-google-map div.g-map');
            var numMap = map_elements.length;

            for(i = 0; i < numMap; i++) {
                var element = map_elements[i];
                var id = $(element).attr("id");
                var zoom = parseFloat($(element).data("zoom"));
                var style_map_id = parseInt($(element).data("style-map"));
                var location_id = $(element).data("location-id");
                var _location = $("#"+location_id);
                var is_hidden_content = _location.hasClass('hidden');
                var location_elements = _location.find('p.location');
                var j = 0;
                var num_location = location_elements.length;
                var bound = new google.maps.LatLngBounds();

                var customMarker = $(element).data("marker");
                var customMarkerHeight = parseFloat($(element).data("marker-height"));
                var customMarkerWidth = parseFloat($(element).data("marker-width"));
                var iconMarker = null;
                var options_map = null;

                var styles = '';
                switch(style_map_id) {
                	case 1: 
                		styles = style_map_1;
                		break;
                	case 2: 
                		styles = style_map_2;
                		break;
                	case 3: 
                		styles = style_map_3;
                		break;
                	default: 
                		styles = style_map_1;
                		break;
                }
                if (isNaN(customMarkerHeight) || isNaN(customMarkerWidth)) {
                    iconMarker = customMarker;
                } else {
                    iconMarker = {
                        url: customMarker,
                        scaledSize: new google.maps.Size(customMarkerHeight, customMarkerWidth)
                    }
                }
                var first_coordinates = {
                        lat: parseFloat($(location_elements[0]).data("latitude")), 
                        lng: parseFloat($(location_elements[0]).data("longitude"))
                    };
                if (isNaN(zoom)) {
                    if (num_location > 1) {
                        options_map = {
                            scrollwheel: false,
                            map_id: i,
                            is_hidden_content: is_hidden_content,
                            styles: styles,
                            center: first_coordinates
                        };
                    } else {
                        options_map = {
                            scrollwheel: false,
                            map_id: i,
                            is_hidden_content: is_hidden_content,
                            styles: styles,
                            zoom: 3,
                            center: first_coordinates
                        };
                    }
                } else {
                    options_map = {
                        scrollwheel: false,
                        map_id: i,
                        is_hidden_content: is_hidden_content,
                        styles: styles,
                        zoom: zoom,
                        center: first_coordinates
                    };
                }

                var map = new google.maps.Map(document.getElementById(id), options_map);
                
                for(j = 0; j < num_location; j++) {
                    var location = location_elements[j];
                    var coordinates = {
                        lat: parseFloat($(location).data("latitude")), 
                        lng: parseFloat($(location).data("longitude"))
                    };
                    var title = $(location).data("title");
                    var description = $(location).data("description");
                    var content_html = jQuery.cosmos_google_map_sc_render_html(title, description);
                    if ( ! customMarker || ! customMarker.length) {
                        var marker = new google.maps.Marker({
                            map_id: i,
                            location_id: location_counter,
                            is_hidden_content: is_hidden_content,
                            position: coordinates,
                            map: map,
                            title: title
                        });

                    } else {
                        var marker = new google.maps.Marker({
                            map_id: i,
                            location_id: location_counter,
                            is_hidden_content: is_hidden_content,
                            position: coordinates,
                            map: map,
                            title: title,
                            icon: iconMarker
                        });
                    }
                    $(location).attr("data-marker-id", location_counter);
                    var info_window = new google.maps.InfoWindow({
                      content: content_html
                    });
                    $(location).click(function(e){
		        		var marker_id = $(this).data('marker-id');
		        		google.maps.event.trigger(markers[marker_id], 'click');
		        	});
                    google.maps.event.addListener(marker, 'click', function(event) {
                        if (current_info_window !== null) {
                            info_windows[current_info_window].close();
                        }
                        //check hidden content
                        if (this.is_hidden_content) {
                        	info_windows[this.location_id].open(maps[this.map_id], markers[this.location_id]);
                        } else {
                        	maps[this.map_id].setCenter(markers[this.location_id].getPosition());
                        	var _loca_id = this.location_id;
                        	//Add animation marker
                        	$.each(markers, function (index, value) {
                        		if (value.location_id == _loca_id) {
						          	markers[value.location_id].setAnimation(google.maps.Animation.BOUNCE);
						        } else {
	                        		markers[value.location_id].setAnimation(null);
						        }
                        	});
                        	jQuery.cosmos_google_map_sc_binding_element(this.location_id);
                        }
                        current_info_window = this.location_id;
                        current_map_id = this.map_id;
                    });
                    google.maps.event.addListener(info_window,'closeclick',function(){
					   jQuery.cosmos_google_map_sc_binding_element(null);
					});
                    location_counter++;
                    markers.push(marker);
                    info_windows.push(info_window);
                    bound.extend(marker.position);
                }
                
                if (typeof zoom === 'undefined' || isNaN(zoom)) {
                    if (num_location > 1) {
                        map.fitBounds(bound);
                    } 
                }
                maps.push(map);
                bounds.push(bound);
            }
        }
    }
    /*render_content_html*/
    $.cosmos_google_map_sc_render_html = function (title, description) {
        if ( ! title || ! title.length) {
            title = '';
        }
        if ( ! description || ! description.length) {
            description = '';
        }
        var html = '<div class="iw-container">';
            html += '<div class="iw-title">' + title + '</div>';
            html += '<div class="iw-content">' + description + '</div>';
            html += '</div>';
        return html;
    }
    //binding click marker and content
    $.cosmos_google_map_sc_binding_element = function(location_id) {
    	$('.sc-google-map p.location').each(function( index ) {
    		var _this = $(this);
    		var _location_id = _this.data('marker-id');
    		var _map_id = _this.data('map-id');
    		if (_this.data('marker-id') == location_id) {
    			_this.addClass('active', function() {
    				$('.sc-google-map .content').animate({
			            'scrollTop':$('.sc-google-map .content').scrollTop() + $(".location.active").position().top
			        }, 250, 'swing');

			        if (window.innerWidth < 767) {
				        $('.sc-google-map .content').animate({
				            'scrollTop': $('body').scrollTop($('#'+_map_id).offset().top)
				        }, 420, 'swing');
				    }
    			});
    		} else {
    			_this.removeClass('active');
    		}
    	});
    }
    /*END Google map shortcode */

    /*
    	process bar
     */
    $.cosmos_process_bar_init1_sc = function(canvasId){
        console.log('cosmos_process_bar_init1_sc');
        console.log(canvasId);
	    //call interval
	    var percCall;

	    //start canvas
	    var canvas = document.getElementById(canvasId);
	    var ctx = canvas.getContext('2d');

	    //get id canvas
	    var idcanvas=$("#"+canvasId);

	    //set width canvas
	    $(idcanvas).attr("width", $(idcanvas).parent().width());

	    //set percent
	    var percent=idcanvas.closest(".content").find(".percent");

	    // declare some variables
	    var cWidth = idcanvas.closest(".content").find(".canvas").width();
	    var cHeight = 8;
	    var progressColor = $('.'+canvasId).attr("data-color");
	    var rectangleColor = $('.'+canvasId).attr("data-color-not-process");
	    var textColor = '#303030';
	    var rawPerc = idcanvas.closest(".content").attr('data-perc');
	    var endperc = parseInt(rawPerc);
	    var startperc = 0;
	    
	    var lineWidth = 3; // The 'brush' size


	    function getPerc() {
	        if(startperc < endperc) {
	            startperc++;
	        }
	        else {
	            clearInterval(percCall);
	        }

	        drawProgressBar();
	    }

	    function drawProgressBar() {
	        //clear the canvas after every instance
	        ctx.clearRect(0,0,cWidth,cHeight);

	        // let's draw the background rectangle
	        ctx.fillStyle = rectangleColor;
	        ctx.lineWidth = lineWidth -3;

	        ctx.fillRect(0, 0, cWidth, 8);

	        ctx.fillStyle = progressColor;
	        ctx.lineWidth = lineWidth;
	        var fillVal = startperc / 100;
	        // ctx.fillRect(0, 20, (fillVal * 380) ,8)
	        ctx.fillRect(0, 0, (fillVal * cWidth) ,8);


	        // let's get the text
	        ctx.fillStyle = textColor;;
	        percent.text(Math.floor(startperc)+'%');
	    }

	    percCall = setInterval(getPerc, 20);

    }
    $.cosmos_process_bar_init2_sc = function(canvasId){
    	var degreesCall;        
    
	    var canvas = document.getElementById(canvasId);
	    var ctx = canvas.getContext('2d');

	    // declare some variables
	    var cWidth = 150;
	    var cHeight = 150;
	    var progressColor = $('.'+canvasId).attr("data-color");
	    var circleColor = $('.'+canvasId).attr("data-color-not-process");
	    var textColor = $('.'+canvasId).attr("data-number-color");
	    var rawPerc = $('.'+canvasId).attr('data-perc');
	    var definition = $('.'+canvasId).attr('data-text');
	    var perc = parseInt(rawPerc);
	    var degrees = 0;
	    var endDegrees = (360*perc)/100;
	    
	    var lineWidth = 3; // The 'brush' size


	    
	    function getDegrees4() {
	        if(degrees < endDegrees) {
	            degrees++;
	        }
	        else {
	            clearInterval(degreesCall);
	        }

	        drawProgressBar4();
	    }
	    var abc=0;
	    function drawProgressBar4() {
	        //clear the canvas after every instance
	        ctx.clearRect(0,0,cWidth,cHeight);

	        // let's draw the background circle
	        ctx.beginPath();
	        ctx.strokeStyle = circleColor;
	        ctx.lineWidth = lineWidth -3;
	        ctx.arc(cHeight/2, cWidth/2, 68, 0, Math.PI*2, false);
	        ctx.stroke();
	        var radians = 0; // We need to convert the degrees to radians

	        radians = degrees * Math.PI/180;
	        // let's draw the actual progressBar
	        ctx.beginPath();
	        ctx.strokeStyle = progressColor;
	        ctx.lineWidth = lineWidth;
	        ctx.arc(cHeight/2, cWidth/2, 68, 0 - 90*Math.PI/180, radians - 90*Math.PI/180, false);
	        ctx.stroke();
	         
	        //let's get the small circle
	        ctx.beginPath();
	        ctx.strokeStyle = progressColor;
	        ctx.lineWidth=6;
	        ctx.arc(getPoint(cHeight/2,cWidth/2,68,radians - 90*Math.PI/180)[0], getPoint(cHeight/2,cWidth/2,68,radians - 90*Math.PI/180)[1], 3, -1.5,  2 * Math.PI,false);
	        ctx.stroke();

	        // let's get the text
	        ctx.fillStyle = textColor;;
	        ctx.font = '30px Source Sans Pro';
	        var outputTextPerc = Math.floor(degrees/360*100)+'%';
	        var outputTextPercWidth = ctx.measureText(outputTextPerc).width;
	        ctx.fillText(outputTextPerc, cWidth/2 - outputTextPercWidth/2, cHeight/2 +10);
	        ctx.font = '16px Source Sans Pro';
	        var outputTextDefinitionWidth = ctx.measureText(definition).width;
	        ctx.fillText(definition, cWidth/2 - outputTextDefinitionWidth/2, cHeight/2 +110);
	    }

	    degreesCall = setInterval(getDegrees4, 20/(degrees - endDegrees));
	    function getPoint(c1,c2,radius,angle){
		    return [c1+Math.cos(angle)*radius,c2+Math.sin(angle)*radius];
		}
    }
    $.cosmos_process_bar_sc = function(){
        if ( $('.sc-process-bar').length ) {           
    		var array_canvas=[];
    		var canvas1 = document.getElementsByClassName('canvas-style-1');
    		for (var i = 0; i < canvas1.length; i++) {
    			array_canvas.push($("#"+canvas1[i].id));
    		}

    		var canvas4 = document.getElementsByClassName('canvas-style-4');
    		for (var i = 0; i < canvas4.length; i++) {
    			array_canvas.push($("#"+canvas4[i].id));
    		}
    		var flag=true;
    		$(window).on("load scroll",function(){
    			if($(window).width()>1200){
    				var window_offset_top = $(window).scrollTop();
    				var window_offset_bottom =$(window).scrollTop() + $(window).height();
    				var elementRemoveArray=[];
    				var timeRunAnimate=0;
    				for(var i=0;i<array_canvas.length;i++){
    					var currentElement = array_canvas[i];
    					//scroll show
    					var element_offset_top = currentElement.offset().top;
    					var element_offset_bottom= currentElement.offset().top + currentElement.height();
    					if(element_offset_top >= window_offset_top && element_offset_bottom <= window_offset_bottom)
    					{
    						if(currentElement.hasClass("canvas-style-1")){
    							jQuery.cosmos_process_bar_init1_sc(array_canvas[i].attr("id"));
    							elementRemoveArray.push(i);
    						}
    						if(currentElement.hasClass("canvas-style-4")){
    							jQuery.cosmos_process_bar_init2_sc(array_canvas[i].attr("id"));
    							elementRemoveArray.push(i);
    						}
    					}
    				}
    				for(var i=elementRemoveArray.length - 1;i >= 0;i--){
    					array_canvas.splice(elementRemoveArray[i], 1);
    				}
    			}
    			else{
    				if(flag){
    					for (var i = 0; i < canvas1.length; i++) {
    						jQuery.cosmos_process_bar_init1_sc(canvas1[i].id);
    					}
    					for (var i = 0; i < canvas4.length; i++) {
    						jQuery.cosmos_process_bar_init2_sc(canvas4[i].id);
    					}
    					flag=false;
    				}
    			} 
    		});
        }
    }

    /*
    	screenshot
     */
    $.cosmos_screenshot_sc = function(){
    	if($('.sc-screenshot').length){
    		$('.sc-screenshot').each(function() {
				var block_id = $(this).data('id');
				var class_id = '.'+block_id;
				var slider = $(class_id+'.style-2');
	    		var data_items = slider.attr('data-item');
	    		var data_autoplay = slider.attr('data-autoplay');
	    		var show_dots = slider.attr('data-showdots');
	    		var show_nav = slider.attr('data-shownav');
	    		var opt_loop = '';
	    		var opt_autoplay = '';
	    		var opt_showdots = '';
	    		var opt_shownav = '';
	            if(typeof data_autoplay !== 'undefined'){
	                opt_autoplay = data_autoplay;
	                if(data_autoplay !== 'no') {
	                	opt_autoplay = 3000;
	                } else {
	                	opt_autoplay = false;
	                }
	            }
	            var opt_items = 1;
	            var opt_itemstable = 3;
	            if(typeof data_items !== 'undefined'){
                    opt_items = data_items;
                    if(opt_items >= 4){
                        opt_itemstable = 3;
                    }
                    else if(opt_items >= 3){
                        opt_itemstable = 2;
                    } else {
                        opt_itemstable = 1;
                    }
                    if(opt_items == 1) {
                        opt_itemstable = 1;
                    }
	            }
	            if(typeof show_dots !== 'undefined'){
	                opt_showdots = show_dots;
	                if(show_dots !== 'no') {
	                	opt_showdots = true;
	                } else {
	                	opt_showdots = false;
	                }
	            }
	            if(typeof show_nav !== 'undefined'){
	                opt_shownav = show_nav;
	                if(show_nav !== 'no') {
	                	opt_shownav = true;
	                } else {
	                	opt_shownav = false;
	                }
	            }
	            if(opt_shownav == true && $(window).width() > 1199) {
                    $(class_id+'.style-2 .carousel-prev').css('display','block');
                    $(class_id+'.style-2 .carousel-next').css('display','block');
	            } else {
	            	$(class_id+'.style-2 .carousel-prev').css('display','none');
	            	$(class_id+'.style-2 .carousel-next').css('display','none');
	            }
				jQuery.cosmos_mycarousel(slider,opt_items,opt_itemstable,1,true,opt_showdots,opt_autoplay,false);
	    		
		    	//fancybox
				$(class_id+" .fancybox-thumb").fancybox({
					maxWidth : "80%",
					maxHeight: "80%",
					prevEffect	: 'none',
					nextEffect	: 'none',
					helpers	: {
						title	: {
							type: 'outside'
						},
						thumbs	: {
							width	: 50,
							height	: 50
						},
						overlay: {
					    	locked: false
						}
					}
				});
				
				$(class_id+".style-3").find(".carousel").each(function(){
		    		var data_auto_play = $(class_id+".style-3").attr('data-autoplay');
		    		var opt_auto_play = '';
		    		if(typeof data_auto_play !== 'undefined'){
		                opt_auto_play = data_auto_play;
		                if(data_auto_play !== 'no') {
		                	opt_auto_play = 3000;
		                } else {
		                	opt_auto_play = false;
		                }
		            }
					var owl=$(this).find(".carousel-items").owlCarousel({
						singleItem:true,
						loop:true,
						pagination:false,
						autoPlay:opt_auto_play,
						slideSpeed:1000,
						afterAction:cosmos_afterAction,
					});
					function cosmos_afterAction(){
						var current = this.currentItem;
						var parent_carousel = $(this.$elem).parents(".carousel");
						var current_item= parent_carousel.find(".owl-item").eq(current).find("img").attr("data-text");
						parent_carousel.parents(".screenshot-content").find(".screenshot-counter.active").removeClass("active");
						parent_carousel.parents(".screenshot-content").find(".screenshot-counter[data-text='"+current_item+"']").addClass("active");
					}
					$(this).find(".carousel-prev").click(function(){
						owl.trigger('owl.prev');
					});
					$(this).find(".carousel-next").click(function(){
						owl.trigger('owl.next');
					});
				});
				
			});
    	}
    }

    $.cosmos_mycarousel = function(id,itemdestop,itemtable,itemmobile,itemloop,dots,autoplay,itemmargin){
		try{
			$(id).find(".carousel").each(function(){
				if(itemdestop == 1 && itemtable == 1 && itemmobile == 1){
					var owl=$(this).find(".carousel-items").owlCarousel({
					 	singleItem:true,
						loop:itemloop,
						pagination:dots,
						autoPlay:autoplay,
						slideSpeed:1000,
						stopOnHover:true,
					});
					$(this).find(".carousel-prev").click(function(){
						owl.trigger('owl.prev');
					});
					$(this).find(".carousel-next").click(function(){
						owl.trigger('owl.next');
					});
				}
				else{
					var owl=$(this).find(".carousel-items").owlCarousel({
						items:itemdestop,
						loop:itemloop,
						pagination:dots,
						autoPlay:autoplay,
						slideSpeed:1000,
						margin:itemmargin,
						stopOnHover:true,
						itemsDesktop :[1199,itemtable],
						itemsDesktopSmall:[991,itemtable],
						itemsTablet :[767,itemmobile],
					});
					$(this).find(".carousel-prev").click(function(){
						owl.trigger('owl.prev');
					});
					$(this).find(".carousel-next").click(function(){
						owl.trigger('owl.next');
					});
				}
			});
		}
		catch(err){
			console.log(err);
		}
    }
    /*Comming soon shortcode */
    $.cosmos_comming_soon_sc = function() {
		$(".sc-coming-soon .input__field.input__field--kaede").click(function(e){
			$(this).addClass("active");
			e.stopPropagation();
		});
		$("body").click(function(){
			$(".sc-coming-soon .input__field.input__field--kaede").each(function(){
				if($(this).val()=="") {
					$(this).removeClass("active");
				}
			});
		});
    }
    /*END Comming soon shortcode */    
    
    /*Price shortcode */
    $.cosmos_price_sc = function() {
        if($('.sc-price').length){
            $('.sc-price').each(function() {
                var block_id = $(this).data('id');
                var class_id = '.' + block_id + ' .section_pricing';
                var slider = $(class_id);
                var data_items = slider.data('item');
                var data_autoplay = slider.data('autoplay');
                var data_timeplay = slider.data('timeplay');
                var show_dots = slider.data('showdots');
                var show_nav = slider.data('shownav');
                var opt_items = 1;
                var opt_itemstable = 2;
                var opt_loop = '';
                var opt_autoplay = false;
                var opt_showdots = false;
                if(typeof data_autoplay !== 'undefined'){
                    opt_autoplay = data_autoplay;
                    if(data_autoplay !== 'false') {
                        if(typeof data_timeplay !== 'undefined') {
                            opt_autoplay = parseFloat(data_timeplay);
                        } else {
                            opt_autoplay = 3000;
                        }
                    } else {
                        opt_autoplay = false;
                    }
                }
                if(typeof data_items !== 'undefined'){
                    opt_items = data_items;
                    if(opt_items < 3){
                        opt_itemstable = 1;
                    } else {
                        opt_itemstable = 2;
                    }
                    if(opt_items == 1) {
                        opt_itemstable = 1;
                    }
                }
                if(typeof show_dots !== 'undefined'){
                    opt_showdots = show_dots;
                    if(show_dots !== 'no') {
                        opt_showdots = true;
                    } else {
                        opt_showdots = false;
                    }
                }
                jQuery.cosmos_mycarousel(class_id, opt_items, opt_itemstable, 1, true, opt_showdots, opt_autoplay, false);
            });
        }
    }
    /*END Price shortcode */

    //create Id
    function makeid()
    {
        var text = "";
        var possible = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
        for( var i=0; i < 5; i++ ){
            text += possible.charAt(Math.floor(Math.random() * possible.length));
        }
        return 'a'+text;
    }

    /*
    	shortcode portfolio
     */
    $.cosmos_portfolio_sc = function() {
    	if($('.sc-portfolio').length) {
    		$('.sc-portfolio').each(function(){
    			var data_id = $(this).data('id');
		    	var class_id = '.'+data_id;
		    	jQuery.cosmos_tabsmenu(class_id);
				//fancybox
				$(class_id+" .fancybox-thumb").fancybox({
					maxWidth : "95%",
					maxHeight: "95%",
					prevEffect	: 'none',
					nextEffect	: 'none',
					helpers	: {
						title	: {
							type: 'outside'
						},
						thumbs	: {
							width	: 50,
							height	: 50
						},
						overlay: {
					    	locked: false
						}
					}
				});
    		});
		}
    }
    $.cosmos_animateTabContent = function (currentElement,timeRunAnimate){
		setTimeout(function(){
			currentElement.removeAttr("style").addClass('animated zoomIn');
		},timeRunAnimate);
		setTimeout(function(){
			currentElement.removeClass('animated zoomIn');
		},timeRunAnimate + 1000);
	}
	$.cosmos_tabsmenu = function (id){

		var tabContent=$(id+" .tabs-content .tabs-content-item");
		var tabMenu=$(id+" .tabs-menu .tabs-menu-item");

		tabMenu.on("click touchstart",function(){

			var dataTab = $(this).attr("data-tab");

			//remove all class active
			tabMenu.removeClass("active");
			tabContent.removeClass("active");

			//active current tabs-menu
			$(this).addClass("active");

			//active current tabs-content
			var tabCurrentActive = $(id+" .tabs-content .tabs-content-item[data-tab='"+dataTab+"']");
			tabCurrentActive.addClass("active");

			//show item animate
			tabCurrentActive.find(".item__img").css("opacity","0");
			var timeRunAnimate=0;
			for(var i=0;i<tabCurrentActive.find(".item__img").length;i++){
				jQuery.cosmos_animateTabContent(tabCurrentActive.find(".item__img").eq(i),timeRunAnimate);
				timeRunAnimate +=100;
			}
		}) 
	}
    /*
    	end shortcode portfolio
     */
    
    /* shortcode testimonial */
    $.cosmos_testimonial_sc = function() {
    	if($('.sc-testimonial').length) {
    		$('.sc-testimonial').each(function(){
    			var data_id = $(this).data('id');
    			var class_id = '.'+data_id;
    			var data_style = $(class_id+' .section_testimonial').attr('data-style');
    			var class_style = '.'+data_style;
    			var slider = class_id+class_style;
    			var data_autoplay = $(slider).attr('data-autoplay');
	    		var show_nav = $(slider).attr('data-nav');
	    		var opt_autoplay = '';
	    		var opt_shownav = '';
	            if(typeof data_autoplay !== 'undefined'){
	                opt_autoplay = data_autoplay;
	                if(data_autoplay !== 'no') {
	                	opt_autoplay = 3000;
	                } else {
	                	opt_autoplay = false;
	                }
	            }
	            if(typeof show_nav !== 'undefined'){
	                opt_shownav = show_nav;
	                if(show_nav !== 'no') {
	                	opt_shownav = true;
	                } else {
	                	opt_shownav = false;
	                }
	            }
                if(opt_shownav == true && $(window).width() > 1199) {
	            	$(slider+' .carousel-prev').css('display','block');
	            	$(slider+' .carousel-next').css('display','block');
	            } else {
	            	$(slider+' .carousel-prev').css('display','none');
	            	$(slider+' .carousel-next').css('display','none');
	            }
	            if(data_style == 'style-1') {
	            	jQuery.cosmos_mycarousel(slider,1,1,1,true,true,opt_autoplay,false);
	            } else {
                    var data_item = $(slider).attr('data-item');
	            	jQuery.cosmos_mycarousel(slider,data_item,2,1,true,true,opt_autoplay,30);
	            }
    		});
    	}
    }

    /*Team Carousel shortcode */
    $.cosmos_team_carousel_sc = function() {
        if($('.sc-team-carousel').length){
            $('.sc-team-carousel').each(function() {
                var block_id = $(this).data('id');
                var class_id = '.' + block_id + ' .section_team';
                var slider = $(class_id);
                var data_items = slider.data('item');
                var data_autoplay = slider.data('autoplay');
                var data_timeplay = slider.data('timeplay');
                var show_dots = slider.data('showdots');
                var show_nav = slider.data('shownav');
                var opt_items = 1;
                var opt_itemstable = 2;
                var opt_loop = '';
                var opt_autoplay = false;
                var opt_showdots = false;
                if(typeof data_autoplay !== 'undefined'){
                    opt_autoplay = data_autoplay;
                    if(data_autoplay != false) {
                        if(typeof data_timeplay !== 'undefined') {
                            opt_autoplay = parseFloat(data_timeplay);
                        } else {
                            opt_autoplay = 3000;
                        }
                    } else {
                        opt_autoplay = false;
                    }
                }
                if(typeof data_items !== 'undefined'){
                    opt_items = data_items;
                    if(opt_items == 1) {
                        opt_itemstable = 1;
                    }
                }
                if(typeof show_dots !== 'undefined'){
                    opt_showdots = show_dots;
                    if(show_dots != false) {
                        opt_showdots = true;
                    } else {
                        opt_showdots = false;
                    }
                }
                jQuery.cosmos_mycarousel(class_id, opt_items, opt_itemstable, 1, true, opt_showdots, opt_autoplay, false);
            });
        }
    }
    /*END Team Carousel shortcode */
})(jQuery);

jQuery( document ).ready( function() {
    new WOW().init();
    jQuery.cosmos_countdown_sc();
    jQuery.cosmos_core_blog();
    jQuery.cosmos_toggle_box_sc();
    jQuery.cosmos_carousel();
    jQuery.cosmos_demo_app();
    jQuery.cosmos_count_download_sc();
    jQuery.cosmos_banner_sc();
    jQuery.cosmos_google_map_sc();
    jQuery.cosmos_process_bar_sc();
    jQuery.cosmos_screenshot_sc();
    jQuery.cosmos_comming_soon_sc();
    jQuery.cosmos_timeline_sc();
    jQuery.cosmos_price_sc();
    jQuery.cosmos_portfolio_sc();
    jQuery.cosmos_testimonial_sc();
    jQuery.cosmos_team_carousel_sc();
});
jQuery( window ).load( function() {
    jQuery.cosmos_play_video();
});
jQuery( window ).resize( function() {
    jQuery.cosmos_screenshot_sc();
    jQuery.cosmos_testimonial_sc();
    jQuery.cosmos_carousel();
    jQuery.cosmos_demo_app();
    jQuery.cosmos_play_video();
});
