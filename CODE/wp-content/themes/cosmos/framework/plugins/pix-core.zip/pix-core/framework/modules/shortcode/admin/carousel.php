<?php
$sc_controller = new Cosmos_Core_Shortcodes_Controller();
$size = array(
	esc_html__( 'Full Size', 'pix-core' )	=> '1',
	esc_html__( '300 x 550', 'pix-core' ) 	=> '2',
	esc_html__( '400 x 300', 'pix-core' ) 	=> '3',
	esc_html__( '600 x 600', 'pix-core' ) 	=> '4',
	esc_html__( '800 x 600', 'pix-core' ) 	=> '5',
);
$item = array(
	esc_html__( '1', 'pix-core' )	=> '1',
	esc_html__( '2', 'pix-core' ) 	=> '2',
	esc_html__( '3', 'pix-core' ) 	=> '3',
	esc_html__( '4', 'pix-core' ) 	=> '4',
);
$true_false = array(
	esc_html__( 'No', 'pix-core' )		=> 'no',
	esc_html__( 'Yes', 'pix-core' ) 	=> 'yes',
);
$params = array(
	array(
		"type"        => 'dropdown',
		"class"       => "",
		"heading"     => esc_html__( 'Image Size', 'pix-core' ),
		"value"		  => $size,
		"param_name"  => 'size',
		"description" => esc_html__( 'Choose image size', 'pix-core' )
	),
	array(
		"type"        => 'attach_images',
		"class"       => "",
		"heading"     => esc_html__( 'Image', 'pix-core' ),
		"param_name"  => 'image',
		"description" => esc_html__( 'Choose image for slider', 'pix-core' )
	),
	array(
		"type"        => 'dropdown',
		"class"       => "",
		"heading"     => esc_html__( 'Number Of Item', 'pix-core' ),
		"value"		  => $item,
		"param_name"  => 'item',
		"description" => esc_html__( 'Choose number item to show. Default is 1 item', 'pix-core' )
	),
	array(
		"type"        => 'dropdown',
		"class"       => "",
		"heading"     => esc_html__( 'Auto Play', 'pix-core' ),
		"value"		  => $true_false,
		"param_name"  => 'autoplay',
		"description" => esc_html__( 'Set auto play for slider. Default is No', 'pix-core' )
	),
	array(
		"type"        => "colorpicker",
		"class"       => "",
		"heading"     => esc_html__( "Dots Color", 'pix-core' ),
		"param_name"  => "dot_color",
		"description" => esc_html__( "Choose color for dots", 'pix-core' ),
		'group'       => esc_html__('Options', 'pix-core'),
	),
	array(
		"type"        => "colorpicker",
		"class"       => "",
		"heading"     => esc_html__( "Hover Dots Color", 'pix-core' ),
		"param_name"  => "hover_dot_color",
		"description" => esc_html__( "Choose color for dots when hover or hover", 'pix-core' ),
		'group'       => esc_html__('Options', 'pix-core'),
	),
	array(
		"type"        => "colorpicker",
		"class"       => "",
		"heading"     => esc_html__( "Active Dots Color", 'pix-core' ),
		"param_name"  => "active_dot_color",
		"description" => esc_html__( "Choose color for dots when active or hover", 'pix-core' ),
		'group'       => esc_html__('Options', 'pix-core'),
	),
	
	array(
		'type'            => 'textfield',
		'heading'         => esc_html__( 'Extra Class', 'pix-core' ),
		'param_name'      => 'extra_class',
		'description'     => esc_html__( 'Style particular content element differently - add a class name and refer to it in custom CSS.', 'pix-core' )
	),
	$sc_controller->cosmos_animation_style(),
	$sc_controller->cosmos_animation_delay(),

);

vc_map(
	array(
		"name"			=> esc_html__( 'PIX Carousel', 'pix-core' ),
		"base"			=> "pixcore_carousel_sc",
		"class"			=> "pixcore-sc",
		"category"		=> COSMOS_CORE_SC_CATEGORY,
		'icon'			=> 'icon-pixcore_carousel_sc',
		"description"	=> esc_html__( 'Carousel', 'pix-core' ),
		"params"		=> $params
	)
);