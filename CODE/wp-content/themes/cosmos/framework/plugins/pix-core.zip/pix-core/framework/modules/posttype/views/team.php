<?php $prefix='cosmos_team_'; ?>
<?php
$sh_icons      = Cosmos_Core_Params::get('font_flaticon');
$awesome_icons = Cosmos_Core_Params::get('font_awesome');
$icons         = array_merge( $sh_icons, $awesome_icons );
?>
<div class="tab-panel">
	<ul class="tab-list">
		<li class="active">
			<a href="pix-tab-team-general"><?php esc_html_e( 'General', 'pix-core' );?></a>
		</li>
		<li class="">
			<a href="pix-tab-team-social"><?php esc_html_e( 'Social', 'pix-core' );?></a>
		</li>
	</ul>
	<div class="tab-container">
		<div class="tab-wrapper pix-page-meta">
			<!-- General -->
			<div id="pix-tab-team-general" class="tab-content active">
				<table class="form-table">
					<tr>
						<th scope="row">
							<label><?php esc_html_e( 'Information', 'pix-core' );?></label>
							<span class="f-right"><?php $this->tooltip_html( esc_html__( 'Enter information of Him (or Her).', 'pix-core' ) );?></span>
						</th>
						<td>
							<?php echo ( $this->text_area( $prefix .'meta['.$prefix.'information]',
														$this->get_field( $data_meta, 'information' ),
														array('class'=>'pix-block','rows' => '6') ) );?>
						</td>
					</tr>
					<tr>
						<th scope="row">
							<label><?php esc_html_e( 'Quote', 'pix-core' );?></label>
							<span class="f-right"><?php $this->tooltip_html( esc_html__( 'Enter quote of Him (or Her).', 'pix-core' ) );?></span>
						</th>
						<td>
							<?php echo ( $this->text_area( $prefix .'meta['.$prefix.'quote]',
														$this->get_field( $data_meta, 'quote' ),
														array('class'=>'pix-block','rows' => '6') ) );?>
						</td>
					</tr>
					<tr>
						<th scope="row">
							<label><?php esc_html_e( 'Position', 'pix-core' );?></label>
							<span class="f-right"><?php $this->tooltip_html( esc_html__( 'Enter Position of Him (or Her).', 'pix-core' ) );?></span>
						</th>
						<td>
							<?php echo ( $this->text_field( $prefix .'meta['.$prefix.'position]',
														$this->get_field( $data_meta, 'position' ),
														array('class'=>'pix-block') ) );?>
						</td>
					</tr>
					<tr>
						<th scope="row">
							<label><?php esc_html_e( 'Icon', 'pix-core' );?></label>
							<span class="f-right"><?php $this->tooltip_html( esc_html__( 'Select icon of Him (or Her).', 'pix-core' ) );?></span>
						</th>
						<td>
							<?php echo ( $this->drop_down_list( $prefix .'meta['.$prefix.'icon]',
											$this->get_field( $data_meta, 'icon' ),
											$icons,
											array('class'=>'pix-select2-icon pix-block') ) );?>	
						</td>
					</tr>
					<tr>
						<th scope="row">
							<label><?php esc_html_e( 'Phone', 'pix-core' );?></label>
							<span class="f-right"><?php $this->tooltip_html( esc_html__( 'Enter Phone Number to Contact.', 'pix-core' ) );?></span>
						</th>
						<td>
							<?php echo ( $this->text_field( $prefix .'meta['.$prefix.'phone]',
														$this->get_field( $data_meta, 'phone' ),
														array('class'=>'pix-block') ) );?>
						</td>
					</tr>
					<tr>
						<th scope="row">
							<label><?php esc_html_e( 'Email', 'pix-core' );?></label>
							<span class="f-right"><?php $this->tooltip_html( esc_html__( 'Enter Email to Contact.', 'pix-core' ) );?></span>
						</th>
						<td>
							<?php echo ( $this->text_field( $prefix .'meta['.$prefix.'email]',
														$this->get_field( $data_meta, 'email' ),
														array('class'=>'pix-block') ) );?>
						</td>
					</tr>
				</table>
			</div>

			<!-- Social-->
			<div id="pix-tab-team-social" class="tab-content">
				<table class="form-table">
					<?php $social_group = Cosmos_Core_Params::get( 'teammbox_social');
						foreach( $social_group as $social => $social_text ):
							$fieldname = $prefix .'meta['.$prefix.$social.']';
						?>
						<tr>
							<th scope="row">
								<label><?php echo esc_attr( $social_text );?></label>
							</th>
							<td>
								<?php echo ( $this->text_field( $fieldname,
																$this->get_field( $data_meta, $social ),
																array( 'class' => 'pix-block' ) ) );?>
							</td>
						</tr>
					<?php endforeach;?>
				</table>
			</div>
		</div>
	</div>
</div>