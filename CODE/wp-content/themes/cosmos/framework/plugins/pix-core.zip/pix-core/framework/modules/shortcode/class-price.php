<?php
class Cosmos_Core_Price extends Cosmos_Core_Custom_Post_Model
{

    private $post_type = 'cosmos_price';
    private $post_taxonomy = 'cosmos_price_cat';
    public $html_format;

    public function __construct()
    {
        $this->meta_attributes();
        $this->set_meta_attributes();
        $this->post_meta_prefix = $this->post_type . '_';
        $this->taxonomy_cat = $this->post_taxonomy;
    }
    public function meta_attributes()
    {
        $meta_atts = array(
            'is_featured'       => esc_html__( 'Is Featured', 'pix-core' ),
            'featured_text'     => esc_html__( 'Featured Text', 'pix-core' ),
            'price'             => esc_html__( 'Price', 'pix-core' ),
            'attr'              => esc_html__( 'Attributes', 'pix-core' ),
            'unit'              => esc_html__( 'Unit', 'pix-core' ),
            'url'               => esc_html__( 'URL', 'pix-core' ),
            'description'       => esc_html__( 'Description', 'pix-core' ),
        );
        $this->post_meta_atts = $meta_atts;
    }
    public function set_meta_attributes()
    {
        $meta_arr = array();
        $meta_label_arr = array();
        foreach ( $this->post_meta_atts as $att => $name ) {
            $key = $att;
            $meta_arr[$key] = '';
            $meta_label_arr[$key] = $name;
        }
        $this->post_meta_def = $meta_arr;
        $this->post_meta = $meta_arr;
        $this->post_meta_label = $meta_label_arr;
    }
    public function init( $atts = array(), $query_args = array() )
    {
        // set attributes
        $default_atts = array(
            'layout'        => 'price',
            'style'         => '',
            'limit_post'    => '',
            'offset_post'   => '',
            'sort_by'       => '',
            'post_id'       => '',
            'method'        => '',
            'column'        => '',
        );
        $atts = array_merge( $default_atts, $atts );
        if ( $atts['method'] == 'cat' ) {
            $atts['post_id'] = $this->parse_cat_slug_to_post_id(
                $this->taxonomy_cat,
                $atts['category_list'],
                $this->post_type
            );
        }
        elseif ($atts['method'] == 'price') {
            $atts['post_id'] = $this->parse_list_to_array( 'post_id', $atts['post_list'] );
        }
        if ( !empty($atts['is_featured']) && $atts['is_featured'] == 'yes' ) {
            $atts['meta_key'] = array(
                $this->post_meta_prefix. 'is_featured'=> 1
            );
        }
        $this->attributes = $atts;
        // query
        $default_args = array(
            'post_type'=> $this->post_type,
        );
        $query_args = array_merge( $default_args, $query_args );
        // setting
        $this->setting( $query_args);
    }
    public function setting( $query_args )
    {
        if ( !isset( $this->attributes['uniq_id'] ) ) {
            $this->attributes['uniq_id'] = $this->post_type . '-' .Cosmos_Core::make_id();
        }
        // query
        $this->query = $this->get_query( $query_args, $this->attributes );
        $this->post_count = 0;
        if ( $this->query->have_posts() ) {
            $this->post_count = $this->query->post_count;
        }
        $this->get_thumb_size();
        $this->set_responsive_class();
        // image size
        $custom_css = $this->add_custom_css();
        if ( $custom_css ) {
            do_action( COSMOS_CORE_ADD_INLINE_CSS, $custom_css );
        }
    }
    public function reset()
    {
        wp_reset_postdata();
    }
    public function set_responsive_class( $atts = array() )
    {
        $class = '';
        $column= $this->attributes['column'];
        $def   = array(
           	'1'=> 'column-1 col-xs-12',
			'2'=> 'column-2 col-xs-12 col-sm-6',
			'3'=> 'column-3 col-xs-12 col-sm-12 col-md-4',
			'4'=> 'column-4 col-xs-12 col-sm-6 col-md-3',
        );

        if ( $column && isset($def[$column])) {
            return $this->attributes['responsive-class'] = $def[$column];
        } else {
            return $this->attributes['responsive-class'] = $def['2'];
        }
    }
    public function add_custom_css()
    {
        $sc_id      = $this->attributes['uniq_id'];
        $custom_css = '';
        
        return $custom_css;
    }
    public function set_default_options( & $html_options = array() )
    {
        $defaults = array(
            'title_format'=> '<div class="row-edit name" data-type="title">%1$s</div>',
            'price_format' => '<div class="icon-item-hom4">$%1$s</div>',
            'attr_format'  => '%1$s',
        );
        $html_options = array_merge( $defaults, $html_options );
        return $html_options;
    }
    public function get_thumb_size()
    {
    	
        $params = Cosmos_Core_Params::get( 'block_image_size', $this->attributes['layout'] );
        $this->attributes['thumb-size'] = Cosmos_Core_Util::get_thumb_size( $params, $this->attributes );
    }

    /* Render */
    public function render_sc( $html_options = array() )
    {
        /*
            %1$s is title
            %2$s is price
            %3$s is atts
            %4$s is button
            %5$s is description
            %6$s is featured
        */
    	$html_options['thumb_class'] = 'img-responsive img-full';
    	// $html_options['price_format'] = '%1$s';
  //   	if($this->attributes['style']==3){
  //           $html_options['price_format'] = '<div class="icon-item-hom4">%1$s</div>';
		// }
        $this->html_format = $this->set_default_options( $html_options );
        if ( $this->query->have_posts() ) {
            while ( $this->query->have_posts() ) {
                $this->query->the_post();
                $this->loop_index();
                printf( $html_options['html_format'],
                    $this->get_title( $html_options ),
                    $this->get_price($html_options),
                    $this->get_price_unit(),
                    $this->get_meta_attribute(),
                    $this->get_button_more_info(),
                    $this->get_meta_description(),
                    $this->get_meta_featured()
                );
            }
            $this->reset();
            // if ( $this->attributes['pagination'] == 'yes' ) {
            //     echo Cosmos_Core_Pagination::paging_nav( $this->query->max_num_pages, 2, $this->query);
            // }
        }
    }


    public function render_slide_widget( $html_options = array() ) {
        $this->html_format = $this->set_default_options( $html_options );
        $custom_css = '';
        if( $this->query->have_posts() ) {
            while ( $this->query->have_posts() ) {
                $this->query->the_post();
                $this->loop_index();
                $html_options = $this->html_format;

                $image_url = '';
                $classItem = 'item-'.$this->post_id;
                if ( $this->has_thumbnail ) {
                    $image_url = $this->get_feature_image_url();
                    if ( !empty($image_url) ) {
                        $custom_css .= sprintf( '.%1$s .%2$s { background-image: url(%3$s); }',
                                                esc_attr( $this->attributes['uniq_id'] ),
                                                esc_attr( $classItem ),
                                                esc_attr( $image_url )
                        );
                    }
                } else {
                    continue;
                }
                printf( $html_options['html_format'],
                    $this->get_title($html_options),
                    $this->get_price(),
                    $this->get_button_more_info(),
                    $classItem
                );
            }
            $this->reset();
            if ( $custom_css ) {
                do_action( COSMOS_CORE_ADD_INLINE_CSS, $custom_css );
            }
        }
    }

    /*custom function*/
    public function get_meta_attribute()
    {
        $format = '%1$s';
        if ( isset($this->html_format['attr_format']) ) {
            $format = $this->html_format['attr_format'];
        }
        $out = '';
        if ( !empty($this->post_meta['attr']) ) {
            $attr_str = '';
            foreach ($this->post_meta['attr'] as $key => $value) {
                $attr_str .= '<li class="row-edit list-group-item" data-type="title">' . $value['name'] . '</li>';
            }
            $out = sprintf( $format, wp_kses_post($attr_str ) );
        }
        return $out;
    }

    public function get_button_more_info()
    {
        $format = ('<li><a href="%2$s" class="row-edit button btn btn-default btn-lg btn-block" data-type="button">%1$s</a></li>');
        if ( isset($this->html_format['button_format']) ) {
            $format = $this->html_format['button_format'];
        }
        $out = $href_url = '';
        if ( !empty($this->attributes['button_text']) ) {
            if(!empty($this->post_meta['url'])) {
                $href_url = $this->post_meta['url'];
            } else {
                $href_url = $this->permalink;
            }
            $out = sprintf( $format, esc_html($this->attributes['button_text']), esc_url($href_url) );
        }
        return $out;
    }
    public function get_price_unit()
    {
        $out = '';
        $format = '%1$s';
        if ( isset($this->html_format['unit_format']) ) {
            $format = $this->html_format['unit_format'];
        }
        $unit = $this->post_meta['unit'];
        if ( !empty($unit) ) {
            $out = sprintf( $format, esc_html($unit) );
        }
        return $out;
    }
    public function get_meta_description()
    {
        $format = '%1$s';
        if ( isset($this->html_format['description_format']) ) {
            $format = $this->html_format['description_format'];
        }
        $out = '';
        if ( !empty($this->post_meta['description']) ) {
            $attr_str = '<span class="row-edit" data-type="title">' . $this->post_meta['description'] . '</span>';
            $out = sprintf( $format, wp_kses_post($attr_str ) );
        }
        return $out;
    }
    public function get_meta_featured()
    {
        $format = '%1$s';
        if ( isset($this->html_format['featured_format']) ) {
            $format = $this->html_format['featured_format'];
        }
        $out = '';
        if ( !empty($this->post_meta['is_featured']) && !empty($this->post_meta['featured_text'])) {
            $attr_str = '<div class="row-edit choice active"><div class="choice-text">' . $this->post_meta['featured_text'] . '</div></div>';
            $out = sprintf( $format, wp_kses_post($attr_str ) );
        }
        return $out;
    }

    public function get_feature_image_url( $thumb_size = '', $thumb_type = 'large', $idThumb = '', $echo = false ) {
        $output = $thumb_img = '';
        if (empty($idThumb)) {
            $idThumb = get_post_thumbnail_id( $this->post_id );
        }
        if ( empty($thumb_size) ) {
            $thumb_size = $this->attributes['thumb-size'][$thumb_type];
        }
        if( !empty($idThumb) ) {
            $helper = new Cosmos_Core_Helper();
            $helper->regenerate_attachment_sizes($idThumb, $thumb_size);
            $thumb_img = wp_get_attachment_image_src( $idThumb, $thumb_size );
            $output = $thumb_img[0];
        }

        if( $echo ) {
            echo wp_kses_post( $output );
        } else {
            return $output;
        }
    }

}