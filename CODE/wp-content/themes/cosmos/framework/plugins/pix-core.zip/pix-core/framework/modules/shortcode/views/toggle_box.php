<?php
$uniq_id = 'sc-toggle-box-'.esc_attr( $id );

$css_animation_class = '';
$css_animation_parent = '';
$css_animation_parent_class = '';
$delay_animation_parent = 0;

if ( !empty($css_animation) && !empty($is_parent_animation) && $is_parent_animation != 'yes') {
	$css_animation = $css_animation;
	$css_animation_class = 'animate-run';
	$delay_animation = (int) $delay_animation;
}

if ( !empty($css_animation) && !empty($is_parent_animation) && $is_parent_animation == 'yes') {
	$css_animation_parent = $css_animation.'-children';
	$css_animation_parent_class = 'animate-run';
	$delay_animation_parent = (int) $delay_animation;
}

$custom_css = '';
if( !empty($block_title_color) ) {
	$custom_css .= '.%1$s .section_faq.style-1 p.title {color:%2$s}'."\n";
}
if( !empty($block_title_bg) ) {
	$custom_css .= '.%1$s .section_faq.style-1 p.title {background:%3$s}'."\n";
}
if( !empty( $active_color ) ){
	$custom_css .= '.%1$s .section_faq.style-1 .faq-item.active .faq-question {color:%4$s}'."\n";
	$custom_css .= '.%1$s .section_faq.style-1 .faq-item.active .faq-question:after {background:%4$s}'."\n";
}
if( !empty( $title_color ) ){
	$custom_css .= '.%1$s .section_faq.style-1 .faq-item .faq-question {color:%5$s;}' ."\n";
	$custom_css .= '.%1$s .section_faq.style-1 .faq-item .faq-question:after {background:%5$s;}' ."\n";
}
if( !empty( $content_color ) ){
	$custom_css .= '.%1$s .section_faq.style-1 .faq-item .faq-answer {color:%6$s;}' ."\n";
}
if( !empty( $content_bg_color ) ){
	$custom_css .= '.%1$s .section_faq.style-1 .faq-item .faq-answer {background:%7$s;}' ."\n";
}

if ( !empty( $custom_css ) ) {
	$custom_css = sprintf($custom_css,
			esc_attr($uniq_id),
			esc_attr($block_title_color),
			esc_attr($block_title_bg),
			esc_attr($active_color),
			esc_attr($title_color),
			esc_attr($content_color),
			esc_attr($content_bg_color)
			);
	do_action( COSMOS_CORE_ADD_INLINE_CSS, $custom_css );
}
if( !empty( $values ) && is_array( $values ) ){
?>
	<div class="pix-shortcode sc-toggle-box <?php echo esc_attr($uniq_id).' '.esc_attr( $extra_class )?> <?php echo esc_attr($css_animation_class); ?>"  data-animate="<?php echo esc_attr($css_animation); ?>" data-delay="<?php echo esc_attr($delay_animation); ?>" data-animate="<?php echo (int) esc_attr($css_animation); ?>" data-delay="<?php echo esc_attr($delay_animation); ?>">
		<div class="section_faq style-1">
			<p class="title"><?php echo esc_attr($block_title) ?></p>
			<?php foreach($values as $value) { ?>
	        <div class="faq-item <?php echo esc_attr($css_animation_parent_class);?>" data-animate="<?php echo esc_attr($css_animation_parent); ?>" data-delay="<?php echo esc_attr($delay_animation_parent); ?>">
	        	<?php if( !empty($value['title']) ) { ?>
	            <div class="faq-question">
	                <?php echo esc_attr($value['title']) ?>
	            </div>
	            <?php } if( !empty($value['content']) ) { ?>
	            <div class="faq-answer">
	                <?php echo esc_attr($value['content']) ?>
	            </div>
	            <?php } ?>
	        </div>
	        <?php } ?>
        </div>
	</div>
<?php } ?>