<?php
$sc_controller = new Cosmos_Core_Shortcodes_Controller();
$style = array(
	esc_html__( 'Style 1', 'pix-core' )	=> '1',
	esc_html__( 'Style 2', 'pix-core' ) => '2',
);

$params = array(
	array(
		'type'        => 'dropdown',
		"class"       => "",
		'heading'     => esc_html__( 'Style', 'pix-core' ),
		'param_name'  => 'style',
		'value'       => $style,
		'description' => esc_html__( 'Select style to show.',  'pix-core'  )
	),
	array(
		'type'          => 'textfield',
		'heading'       => esc_html__( 'Youtube ID', 'pix-core' ),
		'param_name'    => 'youtube_id',
		'description' => sprintf( esc_html__( 'For example: http://www.youtube.com/v/8OBfr46Y0cQ, the ID is %s.', 'pix-core' ), '<b>8OBfr46Y0cQ</b>' ),
	),
	array(
		'type'           => 'attach_image',
		'heading'        => esc_html__( 'Background Image Video', 'pix-core' ),
		'param_name'     => 'image_background',
		'description'    => esc_html__( 'Choose background image.', 'pix-core' ),
	),
	array(
		'type'        => 'textfield',
		'holder'	  => 'div',
		'heading'     => esc_html__( 'Title', 'pix-core' ),
		'param_name'  => 'title',
		'description' => esc_html__( 'Enter title', 'pix-core' ),
		'dependency'    => array(
			'element'		=> 'style',
			'value'         => array( '2' )
		),
	),
	array(
		'type'        => 'textfield',
		'holder'	  => 'span',
		'heading'     => esc_html__( 'Frist Title', 'pix-core' ),
		'param_name'  => 'first_title',
		'description' => esc_html__( 'Enter first title', 'pix-core' ),
		'dependency'    => array(
			'element'		=> 'style',
			'value'         => array( '1' )
		),
	),
	array(
		'type'        => 'textfield',
		'holder'	  => 'span',
		'heading'     => esc_html__( 'Last Title', 'pix-core' ),
		'param_name'  => 'last_title',
		'description' => esc_html__( 'Enter last title', 'pix-core' ),
		'dependency'    => array(
			'element'		=> 'style',
			'value'         => array( '1' )
		),
	),
	array(
		"type"        => "textarea",
		"class"       => "",
		"heading"     => esc_html__( "Description", 'pix-core' ),
		"param_name"  => "description",
		"description" => esc_html__( "Enter description here", 'pix-core' )
	),
	array(
		'type'       => 'param_group',
		'heading'    => esc_html__( 'Button App', 'pix-core' ),
		'param_name' => 'app_content',
		'callbacks'   => array(
		   'after_add' => 'vcChartParamAfterAddCallback'
		),
		'params'     => array(
			array(
				'type'           => 'attach_image',
				'admin_label' => true,
				'heading'        => esc_html__( 'Image Button App', 'pix-core' ),
				'param_name'     => 'image',
				'description'    => esc_html__( 'Choose image for button app.', 'pix-core' ),
			),
			array(
				'type'        => 'vc_link',
				'heading'     => esc_html__( 'Url', 'pix-core' ),
				'param_name'  => 'url',
				'value'       => '',
				'description' => esc_html__( 'Please input to url redirect.', 'pix-core' )
			),
		),
		'dependency'    => array(
			'element'		=> 'style',
			'value'         => array( '1' )
		),
	),
	array(
		"type"        => "colorpicker",
		"class"       => "",
		"heading"     => esc_html__( "Title Color", 'pix-core' ),
		"param_name"  => "title_color",
		"description" => esc_html__( "Choose title color.", 'pix-core' ),
		'group'       => esc_html__('Options', 'pix-core'),
		'dependency'    => array(
			'element'		=> 'style',
			'value'         => array( '2' )
		),
	),
	array(
		"type"        => "colorpicker",
		"class"       => "",
		"heading"     => esc_html__( "First Title Color", 'pix-core' ),
		"param_name"  => "first_title_color",
		"description" => esc_html__( "Choose first title color.", 'pix-core' ),
		'group'       => esc_html__('Options', 'pix-core'),
		'dependency'    => array(
			'element'		=> 'style',
			'value'         => array( '1' )
		),
	),
	array(
		"type"        => "colorpicker",
		"class"       => "",
		"heading"     => esc_html__( "Last Title Color", 'pix-core' ),
		"param_name"  => "last_title_color",
		"description" => esc_html__( "Choose last title color.", 'pix-core' ),
		'group'       => esc_html__('Options', 'pix-core'),
		'dependency'    => array(
			'element'		=> 'style',
			'value'         => array( '1' )
		),
	),
	array(
		"type"        => "colorpicker",
		"class"       => "",
		"heading"     => esc_html__( "Description Color", 'pix-core' ),
		"param_name"  => "description_color",
		"description" => esc_html__( "Choose the color for text in description.", 'pix-core' ),
		'group'       => esc_html__('Options', 'pix-core'),
	),
	array(
		"type"        => "colorpicker",
		"class"       => "",
		"heading"     => esc_html__( "Background Color", 'pix-core' ),
		"param_name"  => "bg_color",
		"description" => esc_html__( "Choose background color.", 'pix-core' ),
		'group'       => esc_html__('Options', 'pix-core'),
	),
	array(
		'type'            => 'textfield',
		'heading'         => esc_html__( 'Extra Class', 'pix-core' ),
		'param_name'      => 'extra_class',
		'description'     => esc_html__( 'Style particular content element differently - add a class name and refer to it in custom CSS.', 'pix-core' )
	),
	$sc_controller->cosmos_animation_style(),
	$sc_controller->cosmos_animation_delay(),

);

vc_map(
	array(
		"name"			=> esc_html__( 'PIX Demo App', 'pix-core' ),
		"base"			=> "pixcore_demo_app_sc",
		"class"			=> "pixcore-sc",
		"category"		=> COSMOS_CORE_SC_CATEGORY,
		'icon'			=> 'icon-pixcore_demo_app_sc',
		"description"	=> esc_html__( 'Demo App', 'pix-core' ),
		"params"		=> $params
	)
);