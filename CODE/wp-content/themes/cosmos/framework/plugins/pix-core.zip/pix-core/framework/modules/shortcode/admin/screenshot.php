<?php
$sc_controller = new Cosmos_Core_Shortcodes_Controller();
$style = array(
	esc_html__( 'Style 1', 'pix-core' )		=> '1',
	esc_html__( 'Style 2', 'pix-core' )		=> '2',
);
$size = array(
	esc_html__( 'Full Size', 'pix-core' )	=> '1',
	esc_html__( '300 x 550', 'pix-core' ) 	=> '2',
	esc_html__( '600 x 600', 'pix-core' ) 	=> '3',
);
$item = array(
	esc_html__( '1', 'pix-core' )	=> '1',
	esc_html__( '2', 'pix-core' ) 	=> '2',
	esc_html__( '3', 'pix-core' ) 	=> '3',
	esc_html__( '4', 'pix-core' ) 	=> '4',
	esc_html__( '5', 'pix-core' ) 	=> '5',
);
$true_false = array(
	esc_html__( 'No', 'pix-core' )		=> 'no',
	esc_html__( 'Yes', 'pix-core' ) 	=> 'yes',
);
$params = array(
	array(
		'type'        		=> 'dropdown',
		'heading'     		=> esc_html__( 'Style', 'pix-core' ),
		'param_name'  		=> 'style',
		'admin_label' 		=> true,
		'value'       		=> $style,
		'std'         		=> '1',
		'description' 		=> esc_html__( 'Choose style to show.', 'pix-core' ),
	),
	array(
		"type"        => 'dropdown',
		"class"       => "",
		"heading"     => esc_html__( 'Image Size', 'pix-core' ),
		"value"		  => $size,
		"param_name"  => 'image_size',
		"description" => esc_html__( 'Choose image size', 'pix-core' )
	),
	array(
		"type"        => 'attach_images',
		"class"       => "",
		"heading"     => esc_html__( 'Image', 'pix-core' ),
		"param_name"  => 'image',
		"description" => esc_html__( 'Choose image for slider', 'pix-core' ),
		'dependency'    => array(
			'element'		=> 'style',
			'value'         => array( '1' )
		),
	),
	array(
		'type'       => 'param_group',
		'heading'    => esc_html__( 'Screenshot Content', 'pix-core' ),
		'param_name' => 'screenshot_content',
		'callbacks'   => array(
		   'after_add' => 'vcChartParamAfterAddCallback'
		),
		'params'     => array(
			array(
				"type"        => 'attach_image',
				"class"       => "",
				"heading"     => esc_html__( 'Image', 'pix-core' ),
				"param_name"  => 'image',
				"description" => esc_html__( 'Choose image for slider', 'pix-core' ),
			),
			array(
				'type'				=> 'textfield',
				'heading'     		=> esc_html__( 'Title', 'pix-core' ),
				'param_name'  		=> 'title',
				'admin_label' 		=> true,
				'description' 		=> esc_html__( 'Please input title to show.', 'pix-core' ),
			),
			array(
				'type'				=> 'textfield',
				'heading'     		=> esc_html__( 'Title Of Description', 'pix-core' ),
				'param_name'  		=> 'title_des',
				'admin_label' 		=> true,
				'description' 		=> esc_html__( 'Please input title for description.', 'pix-core' ),
			),
			array(
				'type'        		=> 'textarea',
				'heading'     		=> esc_html__( 'Description', 'pix-core' ),
				'param_name'  		=> 'description',
				'description' 		=> esc_html__( 'Please input description to show.', 'pix-core' ),
			),
		),
		'dependency'    => array(
			'element'		=> 'style',
			'value'         => array( '2' )
		),
	),
	array(
		"type"        => 'dropdown',
		"class"       => "",
		"heading"     => esc_html__( 'Number Of Item', 'pix-core' ),
		"value"		  => $item,
		"param_name"  => 'item',
		"std"		  => '4',
		"description" => esc_html__( 'Choose number item to show. Default is 1 item', 'pix-core' ),
		'group'       => esc_html__('Options', 'pix-core'),
		'dependency'    => array(
			'element'		=> 'style',
			'value'         => array( '1' )
		),
	),
	array(
		"type"        => 'dropdown',
		"class"       => "",
		"heading"     => esc_html__( 'Auto Play', 'pix-core' ),
		"value"		  => $true_false,
		"param_name"  => 'autoplay',
		"std"		  => 'no',
		"description" => esc_html__( 'Set auto play for slider. Default is No', 'pix-core' ),
		'group'       => esc_html__('Options', 'pix-core'),
	),
	array(
		"type"        => 'dropdown',
		"class"       => "",
		"heading"     => esc_html__( 'Show Navigation', 'pix-core' ),
		"value"		  => $true_false,
		"param_name"  => 'show_nav',
		"std"		  => 'yes',
		"description" => esc_html__( 'Show navigation. Default is Yes', 'pix-core' ),
		'group'       => esc_html__('Options', 'pix-core'),
		'dependency'    => array(
			'element'		=> 'style',
			'value'         => array( '1' )
		),
	),
	array(
		"type"        => 'dropdown',
		"class"       => "",
		"heading"     => esc_html__( 'Show Dots', 'pix-core' ),
		"value"		  => $true_false,
		"param_name"  => 'show_dot',
		"std"		  => 'yes',
		"description" => esc_html__( 'Show dots. Default is Yes', 'pix-core' ),
		'group'       => esc_html__('Options', 'pix-core'),
		'dependency'    => array(
			'element'		=> 'style',
			'value'         => array( '1' )
		),
	),
	array(
		"type"        => "colorpicker",
		"class"       => "",
		"heading"     => esc_html__( "Dots Color", 'pix-core' ),
		"param_name"  => "dot_color",
		"description" => esc_html__( "Choose color for dots", 'pix-core' ),
		'group'       => esc_html__('Custom Color', 'pix-core'),
		'dependency'    => array(
			'element'		=> 'style',
			'value'         => array( '1' )
		),
	),
	array(
		"type"        => "colorpicker",
		"class"       => "",
		"heading"     => esc_html__( "Hover Dots Color", 'pix-core' ),
		"param_name"  => "dot_hover_color",
		"description" => esc_html__( "Choose color for dots when hover or hover", 'pix-core' ),
		'group'       => esc_html__('Custom Color', 'pix-core'),
		'dependency'    => array(
			'element'		=> 'style',
			'value'         => array( '1' )
		),
	),
	array(
		"type"        => "colorpicker",
		"class"       => "",
		"heading"     => esc_html__( "Active Dots Color", 'pix-core' ),
		"param_name"  => "active_dot_color",
		"description" => esc_html__( "Choose color for dots when active or hover", 'pix-core' ),
		'group'       => esc_html__('Custom Color', 'pix-core'),
		'dependency'    => array(
			'element'		=> 'style',
			'value'         => array( '1' )
		),
	),
	array(
		"type"        => "colorpicker",
		"class"       => "",
		"heading"     => esc_html__( "Title Color", 'pix-core' ),
		"param_name"  => "title_color",
		"description" => esc_html__( "Choose color for title", 'pix-core' ),
		'group'       => esc_html__('Custom Color', 'pix-core'),
		'dependency'    => array(
			'element'		=> 'style',
			'value'         => array( '2' )
		),
	),
	array(
		"type"        => "colorpicker",
		"class"       => "",
		"heading"     => esc_html__( "Title Of Description Color", 'pix-core' ),
		"param_name"  => "title_des_color",
		"description" => esc_html__( "Choose color for title of description", 'pix-core' ),
		'group'       => esc_html__('Custom Color', 'pix-core'),
		'dependency'    => array(
			'element'		=> 'style',
			'value'         => array( '2' )
		),
	),
	array(
		"type"        => "colorpicker",
		"class"       => "",
		"heading"     => esc_html__( "Description Color", 'pix-core' ),
		"param_name"  => "description_color",
		"description" => esc_html__( "Choose color for description", 'pix-core' ),
		'group'       => esc_html__('Custom Color', 'pix-core'),
		'dependency'    => array(
			'element'		=> 'style',
			'value'         => array( '2' )
		),
	),
	array(
		"type"        => "colorpicker",
		"class"       => "",
		"heading"     => esc_html__( "Border Color", 'pix-core' ),
		"param_name"  => "border_color",
		"description" => esc_html__( "Choose color for boder", 'pix-core' ),
		'group'       => esc_html__('Custom Color', 'pix-core'),
		'dependency'    => array(
			'element'		=> 'style',
			'value'         => array( '2' )
		),
	),
	
	array(
		'type'            => 'textfield',
		'heading'         => esc_html__( 'Extra Class', 'pix-core' ),
		'param_name'      => 'extra_class',
		'description'     => esc_html__( 'Style particular content element differently - add a class name and refer to it in custom CSS.', 'pix-core' )
	),
	$sc_controller->cosmos_animation_style(),
	$sc_controller->cosmos_animation_delay(),

);

vc_map(
	array(
		"name"			=> esc_html__( 'PIX Screenshot', 'pix-core' ),
		"base"			=> "pixcore_screenshot_sc",
		"class"			=> "pixcore-sc",
		"category"		=> COSMOS_CORE_SC_CATEGORY,
		'icon'			=> 'icon-pixcore_screenshot_sc',
		"description"	=> esc_html__( 'Screenshot', 'pix-core' ),
		"params"		=> $params
	)
);