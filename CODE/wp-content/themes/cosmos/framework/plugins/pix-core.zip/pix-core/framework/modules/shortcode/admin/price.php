<?php
$sc_controller = new Cosmos_Core_Shortcodes_Controller();
$style = array(
	esc_html__( 'Style 1', 'pix-core' ) => 1,
	esc_html__( 'Style 2', 'pix-core' ) => 2,
	esc_html__( 'Style 3', 'pix-core' ) => 3
);

$method = array(
    esc_html__('Price', 'pix-core') => 'price' ,
    esc_html__('Category', 'pix-core') => 'cat'
);

$sort_by    = Cosmos_Core_Params::get('sort-other') ;

$item = array(
	esc_html__( '1', 'pix-core' )	=> '1',
	esc_html__( '2', 'pix-core' ) 	=> '2',
	esc_html__( '3', 'pix-core' ) 	=> '3',
	esc_html__( '4', 'pix-core' ) 	=> '4',
);
$true_false = array(
	esc_html__( 'No', 'pix-core' )		=> 'no',
	esc_html__( 'Yes', 'pix-core' ) 	=> 'yes',
);
// get Price categories
$taxonomy   = 'Cosmos_Price_cat';
$params_cat = array('empty'=> esc_html__( '-- All Price Categories --', 'pix-core' ) );
$categories = Cosmos_Core_Com::get_tax_options2slug( $taxonomy, $params_cat );
// get all price
$args       = array('post_type'=> 'cosmos_price');
$options = array('empty'=> esc_html__( '-- None --', 'pix-core' ) );
$post_list  = Cosmos_Core_Com::get_post_title2id( $args, $options );
$params = array(
	array(
		'type'        => 'dropdown',
		'admin_label' => true,
		"class"       => "",
		'heading'     => esc_html__( 'Style', 'pix-core' ),
		'param_name'  => 'style',
		'value'       => $style,
        'std'         => '1',
		'description' => esc_html__( 'Select style.',  'pix-core'  )
	),
    array(
        'type'       => 'textfield',
        'heading'    => esc_html__( 'Limit Posts', 'pix-core' ),
        'param_name' => 'limit_post',
        'value'      => '-1',
        'description'=> esc_html__( 'Add limit posts per page. Set -1 or empty to show all.', 'pix-core' )
    ),
    array(
        'type'       => 'textfield',
        'heading'    => esc_html__( 'Offset Posts', 'pix-core' ),
        'param_name' => 'offset_post',
        'value'      => '0',
        'description'=> esc_html__( 'Enter offset to pass over posts. If you want to start on record 6, using offset 5', 'pix-core' )
    ),
    array(
        'type'       => 'dropdown',
        'heading'    => esc_html__( 'Sort By', 'pix-core' ),
        'param_name' => 'sort_by',
        'value'      => $sort_by,
        'description'=> esc_html__( 'Select order to display list properties.', 'pix-core' ),
    ),
	array(
		'type'        => 'textfield',
		'heading'     => esc_html__( 'Price font size', 'pix-core' ),
		'param_name'  => 'price_font_size',
		'description' => esc_html__( 'Enter price font size. Ex 60', 'pix-core' ),
	),
	array(
		'type'        => 'textfield',
		'heading'     => esc_html__( 'Currency font size', 'pix-core' ),
		'param_name'  => 'currency_font_size',
		'description' => esc_html__( 'Enter currency font size. Ex: 13', 'pix-core' ),
	),
	array(
		'type'        => 'textfield',
		'heading'     => esc_html__( 'Button text', 'pix-core' ),
		'param_name'  => 'button_text',
		'description' => esc_html__( 'Enter button text', 'pix-core' ),
		'value'       => esc_html__('BUY NOW', 'pix-core')
	),
	// Filter
    array(
        'type'       => 'dropdown',
        'heading'    => esc_html__( 'Display by', 'pix-core' ),
        'param_name' => 'method',
        'value'      => $method,
        'std'        => 'cat',
        'description'=> esc_html__( 'Choose Price category or special Prices to display.',  'pix-core'  ),
        'group'      => esc_html__('Filter', 'pix-core')
    ),
    array(
        'type'       => 'param_group',
        'heading'    => esc_html__( 'Category', 'pix-core' ),
        'param_name' => 'category_list',
        'callbacks'   => array(
           'after_add' => 'vcChartParamAfterAddCallback'
        ),
        'params'    => array(
            array(
                'type'       => 'dropdown',
                'admin_label'=> true,
                'heading'    => esc_html__( 'Add Category', 'pix-core' ),
                'param_name' => 'category_slug',
                'value'      => $categories,
                'description'=> esc_html__( 'Choose special category to filter', 'pix-core'  )
            ),
        ),
        'value'      => '',
        'dependency' => array(
            'element'   => 'method',
            'value'     => array('cat' )
        ),
        'description'=> esc_html__( 'Default no filter by category.', 'pix-core' ),
        'group'      => esc_html__('Filter', 'pix-core')
    ),
    array(
        'type'       => 'param_group',
        'heading'    => esc_html__( 'Price List', 'pix-core' ),
        'param_name' => 'post_list',
        'callbacks'   => array(
           'after_add' => 'vcChartParamAfterAddCallback'
        ),
        'params'     => array(
            array(
                'type'       => 'dropdown',
                'admin_label'=> true,
                'heading'    => esc_html__( 'Add Price', 'pix-core' ),
                'param_name' => 'post_id',
                'value'      => $post_list,
                'description'=> esc_html__( 'Choose Price to show', 'pix-core'  )
            ),
        ),
        'value'      => '',
        'dependency' => array(
            'element'=> 'method',
            'value'  => array('price')
        ),
        'description'=> esc_html__( 'Default empty.', 'pix-core' ),
        'group'      => esc_html__('Filter', 'pix-core')
    ),
	// Options
	array(
		"type"        => 'dropdown',
		"class"       => "",
		"heading"     => esc_html__( 'Number Of Item', 'pix-core' ),
		"value"		  => $item,
		"param_name"  => 'item',
		"std"		  => '4',
		"description" => esc_html__( 'Choose number item to show. Default is 1 item', 'pix-core' ),
		'group'       => esc_html__('Options', 'pix-core'),
	),
	array(
		"type"        => 'dropdown',
		"class"       => "",
		"heading"     => esc_html__( 'Auto Play', 'pix-core' ),
		"value"		  => $true_false,
		"param_name"  => 'autoplay',
		"std"		  => 'no',
		"description" => esc_html__( 'Set auto play for slider. Default is No', 'pix-core' ),
		'group'       => esc_html__('Options', 'pix-core'),
	),
	array(
		"type"        => 'dropdown',
		"class"       => "",
		"heading"     => esc_html__( 'Show Navigation', 'pix-core' ),
		"value"		  => $true_false,
		"param_name"  => 'show_nav',
		"std"		  => 'yes',
		"description" => esc_html__( 'Show navigation. Default is Yes', 'pix-core' ),
		'group'       => esc_html__('Options', 'pix-core'),
	),
	// Custom color
	array(
		"type"        => "colorpicker",
		"class"       => "",
		"heading"     => esc_html__( "Hover Color", 'pix-core' ),
		"param_name"  => "color_text_hover",
		"description" => esc_html__( "Choose hover color.", 'pix-core' ),
		'group'       => esc_html__('Custom Color', 'pix-core'),
	),
	array(
		"type"        => "colorpicker",
		"class"       => "",
		"heading"     => esc_html__( "Hover background Color", 'pix-core' ),
		"param_name"  => "color_bg_hover",
		"description" => esc_html__( "Choose hover background color.", 'pix-core' ),
		'group'       => esc_html__('Custom Color', 'pix-core'),
	),
	array(
		"type"        => "colorpicker",
		"class"       => "",
		"heading"     => esc_html__( "Title Color", 'pix-core' ),
		"param_name"  => "title_color",
		"description" => esc_html__( "Choose title color.", 'pix-core' ),
		'group'       => esc_html__('Custom Color', 'pix-core'),
	),
	array(
		"type"        => "colorpicker",
		"class"       => "",
		"heading"     => esc_html__( "Description Color", 'pix-core' ),
		"param_name"  => "description_color",
		"description" => esc_html__( "Choose description color.", 'pix-core' ),
		'group'       => esc_html__('Custom Color', 'pix-core'),
	),
	array(
		"type"        => "colorpicker",
		"class"       => "",
		"heading"     => esc_html__( "Price Color", 'pix-core' ),
		"param_name"  => "price_color",
		"description" => esc_html__( "Choose price color.", 'pix-core' ),
		'group'       => esc_html__('Custom Color', 'pix-core'),
	),
	array(
		"type"        => "colorpicker",
		"class"       => "",
		"heading"     => esc_html__( "Attributes Color", 'pix-core' ),
		"param_name"  => "attributes_color",
		"description" => esc_html__( "Choose attributes color.", 'pix-core' ),
		'group'       => esc_html__('Custom Color', 'pix-core'),
	),
	array(
		"type"        => "colorpicker",
		"class"       => "",
		"heading"     => esc_html__( "Attributes Border Color", 'pix-core' ),
		"param_name"  => "attributes_color_border",
		"description" => esc_html__( "Choose attributes border color.", 'pix-core' ),
		'group'       => esc_html__('Custom Color', 'pix-core'),
	),
	array(
		"type"        => "colorpicker",
		"class"       => "",
		"heading"     => esc_html__( "Unit Color", 'pix-core' ),
		"param_name"  => "unit_color",
		"description" => esc_html__( "Choose unit color.", 'pix-core' ),
		'group'       => esc_html__('Custom Color', 'pix-core'),
	),
	array(
		"type"        => "colorpicker",
		"class"       => "",
		"heading"     => esc_html__( "Item background Color", 'pix-core' ),
		"param_name"  => "item_bg_color",
		"description" => esc_html__( "Choose item background color.", 'pix-core' ),
		'group'       => esc_html__('Custom Color', 'pix-core'),
	),
	array(
		"type"        => "colorpicker",
		"class"       => "",
		"heading"     => esc_html__( "Text featured Color", 'pix-core' ),
		"param_name"  => "color_text_featured",
		"description" => esc_html__( "Choose text featured color.", 'pix-core' ),
		'group'       => esc_html__('Custom Color', 'pix-core'),
		'dependency'  => array(
			'element' => 'style',
			'value'   => array('2')
		)
	),
	array(
		"type"        => "colorpicker",
		"class"       => "",
		"heading"     => esc_html__( "Featured background Color", 'pix-core' ),
		"param_name"  => "color_bg_featured",
		"description" => esc_html__( "Choose featured background color.", 'pix-core' ),
		'group'       => esc_html__('Custom Color', 'pix-core'),
		'dependency'  => array(
			'element' => 'style',
			'value'   => array('2')
		)
	),
	array(
		"type"        => "colorpicker",
		"class"       => "",
		"heading"     => esc_html__( "Box background Color", 'pix-core' ),
		"param_name"  => "color_border_box",
		"description" => esc_html__( "Choose box background color.", 'pix-core' ),
		'group'       => esc_html__('Custom Color', 'pix-core'),
	),
	array(
		"type"        => "colorpicker",
		"class"       => "",
		"heading"     => esc_html__( "Button Color", 'pix-core' ),
		"param_name"  => "color_button",
		"description" => esc_html__( "Choose button color.", 'pix-core' ),
		'group'       => esc_html__('Custom Color', 'pix-core'),
	),
	array(
		"type"        => "colorpicker",
		"class"       => "",
		"heading"     => esc_html__( "Button Color Hover", 'pix-core' ),
		"param_name"  => "color_button_hv",
		"description" => esc_html__( "Choose button color when hover.", 'pix-core' ),
		'group'       => esc_html__('Custom Color', 'pix-core'),
	),
	array(
		"type"        => "colorpicker",
		"class"       => "",
		"heading"     => esc_html__( "Button Border Color", 'pix-core' ),
		"param_name"  => "color_button_border",
		"description" => esc_html__( "Choose button border color.", 'pix-core' ),
		'group'       => esc_html__('Custom Color', 'pix-core'),
	),
	array(
		"type"        => "colorpicker",
		"class"       => "",
		"heading"     => esc_html__( "Button Border Color Hover", 'pix-core' ),
		"param_name"  => "color_button_border_hv",
		"description" => esc_html__( "Choose button border color when hover.", 'pix-core' ),
		'group'       => esc_html__('Custom Color', 'pix-core'),
	),
	array(
		"type"        => "colorpicker",
		"class"       => "",
		"heading"     => esc_html__( "Button Background Color", 'pix-core' ),
		"param_name"  => "color_button_bg",
		"description" => esc_html__( "Choose button background color.", 'pix-core' ),
		'group'       => esc_html__('Custom Color', 'pix-core'),
	),
	array(
		"type"        => "colorpicker",
		"class"       => "",
		"heading"     => esc_html__( "Button Background Color Hover", 'pix-core' ),
		"param_name"  => "color_button_bg_hv",
		"description" => esc_html__( "Choose button background color when hover.", 'pix-core' ),
		'group'       => esc_html__('Custom Color', 'pix-core'),
	),
	array(
		'type'            => 'textfield',
		'heading'         => esc_html__( 'Extra Class', 'pix-core' ),
		'param_name'      => 'extra_class',
		'description'     => esc_html__( 'Style particular content element differently - add a class name and refer to it in custom CSS.', 'pix-core' )
	),
	$sc_controller->cosmos_animation_style(),
	$sc_controller->cosmos_animation_delay(),
);

vc_map(
	array(
		"name"			=> esc_html__( 'PIX Price Table', 'pix-core' ),
		"base"			=> "pixcore_price_sc",
		"class"			=> "pixcore-sc",
		"category"		=> COSMOS_CORE_SC_CATEGORY,
		'icon'			=> 'icon-pixcore_price_sc',
		"description"	=> esc_html__( 'Price table', 'pix-core' ),
		"params"		=> $params
	)
);