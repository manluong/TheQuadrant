<?php
$custom_css = '';
$block_class = 'block-title-'. $id;
$block_cls = $extra_class . ' ' . $block_class;

if( $style == 1 ) {
    if( !empty( $title_color ) ) {
        $custom_css .= '.%1$s .title { color:%2$s; }' ."\n";
    }
    if( !empty( $description_color ) ) {
        $custom_css .= '.%1$s .content { color:%3$s; }' ."\n";
    }
    if( !empty( $align ) ) {
        $custom_css .= '.%1$s .col-center { text-align:%4$s; }' ."\n";
    }
    if( !empty( (int) $title_size ) ) {
        $custom_css .= '.%1$s .title { font-size:%5$s; }' ."\n";
    }
    if( !empty( (int) $description_size ) ) {
        $custom_css .= '.%1$s .content { font-size:%6$s; }' ."\n";
    }
}
if( $style == 2 ) {
    if( !empty( $title_color ) ) {
        $custom_css .= '.%1$s .template-header-style { color:%2$s; }' ."\n";
    }
    if( !empty( $description_color ) ) {
        $custom_css .= '.%1$s .template-header-title { color:%3$s; }' ."\n";
    }
    if( !empty( $align ) ) {
        $custom_css .= '.%1$s .template-header { text-align:%4$s; }' ."\n";
    }
    if( !empty( (int) $title_size ) ) {
        $custom_css .= '.%1$s .template-header-style { font-size:%5$s; }' ."\n";
    }
    if( !empty( (int) $description_size ) ) {
        $custom_css .= '.%1$s .template-header-title { font-size:%6$s; }' ."\n";
    }
}
if( $style == 3 ) {
    if( !empty( $title_color ) ) {
        $custom_css .= '.%1$s .subscribe-header .subscribe-title-1 { color:%2$s; }' ."\n";
    }
    if( !empty( $description_color ) ) {
        $custom_css .= '.%1$s .subscribe-header .subscribe-title-2 { color:%3$s; }' ."\n";
    }
    if( !empty( $align ) ) {
        $custom_css .= '.%1$s .subscribe-header { text-align:%4$s; }' ."\n";
    }
    if( !empty( (int) $title_size ) ) {
        $custom_css .= '.%1$s .subscribe-header .subscribe-title-1 { font-size:%5$s; }' ."\n";
    }
    if( !empty( (int) $description_size ) ) {
        $custom_css .= '.%1$s .subscribe-header .subscribe-title-2 { font-size:%6$s; }' ."\n";
    }
}


if( !empty( $custom_css ) ) {
    $custom_css = sprintf($custom_css,
        esc_attr($block_class),
        esc_attr($title_color),
        esc_attr($description_color),
        esc_attr($align),
        esc_attr($title_size),
        esc_attr($description_size)
    );
	do_action( COSMOS_CORE_ADD_INLINE_CSS, $custom_css );
}
?>
<div class="pix-shortcode sc-block-title <?php echo esc_attr( $block_cls ); ?> animate-run" data-animate="<?php echo esc_attr($css_animation); ?>" data-delay="<?php echo (int) esc_attr($delay_animation); ?>">
    <div class="section_comming_soon style-2">
	<?php if( $style == '1' ) { ?>
        <div class="col-center">
            <?php if(!empty($title)) { ?>
    		<p class="title"><?php echo esc_attr($title) ?></p>
            <?php
                }
                if(!empty($description)) {
            ?>
    		<p class="content"><?php echo esc_attr($description) ?></p>
            <?php } ?>
        </div>
    </div>
	<?php } elseif ( $style == '2' ) { ?>
	<div class="template-header">
        <?php if(!empty($logo)) { ?>
        <div class="template-header-logo">
            <?php echo wp_get_attachment_image($logo, '',false, array('class'=>'img-resposive')); ?>
        </div>
        <?php } ?>
        <?php if(!empty($description)) { ?>
        <p class="template-header-title" >
            <span data-type="title"><?php echo esc_attr($description) ?></span>
        </p>
        <?php
            }
            if(!empty($title)) {
        ?>
        <p class="template-header-style" >
            <span data-type="title"><?php echo esc_attr($title) ?></span>
        </p>
        <?php } ?>
    </div>
	<?php } elseif ( $style == '3' ) { ?>
    <div class="row-builder section_subscribe style-3" data-type="bg">
    	<div class="subscribe-header">
            <?php if(!empty($title)) { ?>
            <p class="subscribe-title-1">
                <span data-type="title"><?php echo esc_attr($title) ?></span>
            </p>
            <?php
                }
                if(!empty($description)) {
            ?>
            <p class="subscribe-title-2">
                <span data-type="title"><?php echo esc_attr($description) ?></span>
            </p>
            <?php } ?>
        </div>
    	<?php } ?>
    </div>
</div>