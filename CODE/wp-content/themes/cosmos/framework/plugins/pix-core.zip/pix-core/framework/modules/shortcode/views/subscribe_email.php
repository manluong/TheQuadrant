<?php 
$uniq_id = 'sc-subscribe-email-'.esc_attr( $id );
$custom_css = '';

if( empty ($button_text) ) {
    $button_text = esc_html__( 'Subscribe now 222', 'pix-core' );
}

if ( ! empty( $title_color ) ) {
    $custom_css .= '.%1$s.sc-subscribe-email .section_subscribe .subscribe-header .subscribe-title-1 {color:%2$s;}' ."\n";
}
if ( ! empty( $sub_title_color) ) {
    $custom_css .= '.%1$s.sc-subscribe-email .section_subscribe .subscribe-header .subscribe-title-2  {color:%3$s;}' ."\n";
}
if ( ! empty( $input_color) ) {
    $custom_css .= '.%1$s.sc-subscribe-email .section_subscribe .subscribe-content .input-subscribe {color:%4$s;}' ."\n";
}
if ( ! empty( $input_border_color) ) {
    $custom_css .= '.%1$s.sc-subscribe-email .section_subscribe .subscribe-content .input-subscribe {border:solid 1px %5$s;}' ."\n";
}
if ( ! empty( $input_placeholder_color) ) {
    $custom_css .= '.%1$s.sc-subscribe-email .section_subscribe .subscribe-content .input-subscribe::-webkit-input-placeholder {color:%6$s;}, .%1$s.sc-subscribe-email .section_subscribe .subscribe-content .input-subscribe:-moz-placeholder {color:%6$s;}, .%1$s.sc-subscribe-email .section_subscribe .subscribe-content .input-subscribe::-moz-placeholder {color:%6$s;}, .%1$s.sc-subscribe-email .section_subscribe .subscribe-content .input-subscribe:-ms-input-placeholder {color:%6$s;}' ."\n";
}
if ( ! empty( $button_color) ) {
    $custom_css .= '.%1$s.sc-subscribe-email .section_subscribe .subscribe-content .button-subscribe {color:%7$s;}' ."\n";
}
if ( ! empty( $button_bg_color) ) {
    $custom_css .= '.%1$s.sc-subscribe-email .section_subscribe .subscribe-content .button-subscribe {background-color:%8$s; border:solid 1px %8$s;}' ."\n";
}
if ( ! empty( $button_hover_color) ) {
    $custom_css .= '.%1$s.sc-subscribe-email .subscribe-content .button-subscribe:hover {color:%9$s;}' ."\n";
}
if ( ! empty( $button_hover_bg_color) ) {
    $custom_css .= '.%1$s.sc-subscribe-email .subscribe-content .button-subscribe:hover {background-color:%10$s; border:solid 1px %10$s;}' ."\n";
}
if ( ! empty( $input_bg_color) ) {
    $custom_css .= '.%1$s.sc-subscribe-email .section_subscribe .subscribe-content .input-subscribe {background-color:%11$s;}' ."\n";
}
if ( !empty( $custom_css ) ) {
    $custom_css = sprintf($custom_css,
            esc_attr($uniq_id),
            esc_attr($title_color),
            esc_attr($sub_title_color),
            esc_attr($input_color),
            esc_attr($input_border_color),
            esc_attr($input_placeholder_color),
            esc_attr($button_color),
            esc_attr($button_bg_color),
            esc_attr($button_hover_color),
            esc_attr($button_hover_bg_color),
            esc_attr($input_bg_color)
            );
    do_action( COSMOS_CORE_ADD_INLINE_CSS, $custom_css );
}
?>

<?php if (COSMOS_NEWSLETTER_ACTIVE) { 
    $form = '';
    global $newsletter;
    $form = NewsletterSubscription::instance()->get_form_javascript();
    if ($style == 2) {
        $form .= '<div class="section_subscribe style-2" data-type="bg">';
            if ( ! empty($title) || ! empty($sub_title) ) {
                $form .= '<div class="subscribe-header">';
                if ( ! empty($title) ) {
                    $form .= '<p class="subscribe-title-1">';
                        $form .= '<span data-type="title">'.esc_html($title).'</span>';
                    $form .= '</p>';
                }
                if ( ! empty($sub_title) ) {
                    $form .= '<p class="subscribe-title-2">';
                        $form .= '<span data-type="title">'.esc_html($sub_title).'</span>';
                    $form .= '</p>';
                }
                $form .= '</div>';
            }
                $form .= '<div class="subscribe-content">';
                    $form .= '<form action="' . home_url('/') . '?na=s" onsubmit="return newsletter_check(this)" method="post">';
                        $form .= '<div class="row">';
                            $form .= '<div class="col-md-4 col-xs-12">';
                                $form .= '<input class="input-subscribe input-type-1" type="text" name="fullname" placeholder="'.esc_attr($input_fullname_placeholder).'" required>';
                            $form .= '</div>';
                            $form .= '<div class="col-md-4 col-xs-12">';
                                $form .= '<input class="input-subscribe input-type-1" type="text" required name="ne" placeholder="'.esc_attr($input_email_placeholder).'" onclick="if (this.defaultValue==this.value) this.value=\'\'" onblur="if (this.value==\'\') this.value=this.defaultValue"/>';
                            $form .= '</div>';
                            $form .= '<div class="col-md-4 col-xs-12">';
                                $form .= '<button type="submit" class="button-subscribe button-type-2" data-type="button">';
                                    $form .= '<i class="fa fa-envelope-o" aria-hidden="true"></i>'.esc_html($button_text);
                                $form .= '</button>';
                            $form .= '</div>';
                        $form .= '</div>';
                    $form .= '</form>';
                $form .= '</div>';
        $form .= '</div>';
    }
    if ($style == 3) {
        $form .= '<div class="section_subscribe style-3" data-type="bg">';
            if ( ! empty($title) || ! empty($sub_title) ) {
                $form .= '<div class="mg-b60">';
                    $form .= '<div class="subscribe-header">';
                    if ( ! empty($title) ) {
                        $form .= '<p class="subscribe-title-1">';
                            $form .= '<span data-type="title">'.esc_html($title).'</span>';
                        $form .= '</p>';
                    }
                    if ( ! empty($sub_title) ) {
                        $form .= '<p class="subscribe-title-2">';
                            $form .= '<span data-type="title">'.esc_html($sub_title).'</span>';
                        $form .= '</p>';
                    }
                    $form .= '</div>';
                $form .= '</div>';
            }
                $form .= '<div class="subscribe-content">';
                    $form .= '<form action="' . home_url('/') . '?na=s" onsubmit="return newsletter_check(this)" method="post">';
                        $form .= '<div class="subscribe-form">';
                            $form .= '<div class="subscribe-input">';
                                $form .= '<input class="input-subscribe input-type-2" type="text" required name="ne" placeholder="'.esc_attr($input_email_placeholder).'" onclick="if (this.defaultValue==this.value) this.value=\'\'" onblur="if (this.value==\'\') this.value=this.defaultValue"/>';
                            $form .= '</div>';
                            $form .= '<div class="subscribe-button">';
                                $form .= '<button type="submit" class="button-subscribe button-type-1" data-type="button">'.esc_html($button_text).'</button>';
                            $form .= '</div>';
                        $form .= '</div>';
                    $form .= '</form>';
                $form .= '</div>';
        $form .= '</div>';
    }

    $form = $newsletter->replace($form);
?>

<div class="pix-shortcode sc-subscribe-email <?php echo esc_attr($uniq_id).' '.esc_attr( $extra_class )?> animate-run" data-animate="<?php echo esc_attr($css_animation); ?>" data-delay="<?php echo (int) esc_attr($delay_animation); ?>">
    <?php printf( '%s', $form ); ?>
</div>
<?php } ?>