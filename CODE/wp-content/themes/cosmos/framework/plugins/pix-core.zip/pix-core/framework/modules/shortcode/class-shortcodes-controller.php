<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly
}

class Cosmos_Core_Shortcodes_Controller extends Cosmos_Core_Abstract
{

    /**
    * Init shortcodes.
    */
    public function init() {
        // Add custom type
        if ( function_exists("vc_add_shortcode_param") ) {
            // date time picker
            vc_add_shortcode_param( 'pix_datetime_picker' , array(& $this,'cosmos_core_datetime_picker_field' ) , COSMOS_CORE_ASSET_URI . '/js/cosmos-core-datetimepicker.js');
            vc_add_shortcode_param( 'pix_date_picker' , array(& $this,'cosmos_core_date_picker_field' ) , COSMOS_CORE_ASSET_URI . '/js/cosmos-core-datetimepicker.js');
            vc_add_shortcode_param( 'pix_attach_video' , array(& $this,'cosmos_core_attach_video_field' ) , COSMOS_CORE_ASSET_URI . '/js/cosmos-core-attachvideo.js');
        }

        $list_shortcodes = Cosmos_Core_Config::get( 'shortcode' );
        foreach ( $list_shortcodes as $shortcode => $func ) {
            add_shortcode( $shortcode, array(& $this,$func ) );
        }
    }
    public function cosmos_core_datetime_picker_field( $settings, $value ) {
        $dependency = vc_generate_dependencies_attributes( $settings );
        $output     = '<input name="' . $settings['param_name'] . '" ';
        $output .= 'class="wpb_vc_param_value wpb-textinput vc_pix_datetimepicker ' . $settings['param_name'] . ' ' . $settings['type'].'_field" ';
        $output .= 'type="text" value="' . $value . '" ' . $dependency . '/>';
        return $output;
    }
    public function cosmos_core_date_picker_field( $settings, $value ) {
        $dependency = vc_generate_dependencies_attributes( $settings );
        $output     = '<input name="' . $settings['param_name'] . '" ';
        $output .= 'class="wpb_vc_param_value wpb-textinput vc_pix_datepicker ' . $settings['param_name'] . ' ' . $settings['type'].'_field" ';
        $output .= 'type="text" value="' . $value . '" ' . $dependency . '/>';
        return $output;
    }
    public function cosmos_core_attach_video_field( $settings, $value ) {
        $dependency = vc_generate_dependencies_attributes( $settings );
        $name = $settings['param_name'];

        $video_src = '';
        $div_show = 'hide';
        if( ! empty( $value )) {
            $video_src = wp_get_attachment_url($value);
            $div_show = '';
        }
        $output = '<div class="screenshot '.$div_show.'" >
                    <video id="pix_attach_video_' . $settings['param_name'] . '_name" width="100%" controls>
                        <source src="'.esc_url( $video_src ).'" type="video/mp4">
                        '. esc_html__( 'Your browser does not support HTML5 video.', 'pix-core' ) .'  
                    </video>
                </div>
                <input type="button" data-rel="pix_attach_video_' . $name . '" class="button pix-btn-upload-video" value="'. esc_html__( 'Upload Image', 'pix-core' ) .'" style="width: auto;"/>
                <input type="button" data-rel="pix_attach_video_' . $name . '" class="button pix-btn-remove '.$div_show.'" value="'. esc_html__( 'Remove', 'pix-core' ) .'" style="width: auto;"/>
                <input id="pix_attach_video_' . $settings['param_name'] . '_id" class="wpb_vc_param_value vc_pix_attach_video ' . $name . ' ' . $settings['type'].'_field" type="hidden" name="' . $name . '" value="' . $value . '">';
        return $output;
    }
    
    /**
    * Map shortcodes to VC
    */
    public function vc_map_shortcodes() {
        $list_shortcodes = Cosmos_Core_Config::get( 'shortcode' );
        foreach ( $list_shortcodes as $shortcode => $func ) {
            $sc_file = COSMOS_CORE_SHORTCODE_DIR . $func . '.php';
            if ( file_exists( $sc_file ) ) {
                require_once( $sc_file );
            }
        }
    }
    //[pix_module cl = "shortcode.Shortcodes" mt = "shortcode_test" atr1 = "test" atr2 = "tesatres"]content[ / pix_module]
    public function module( $atts, $content = null ) {
        if ( ! empty( $atts['cl'] ) && ! empty( $atts['mt'] ) ) {
            if ( Cosmos_Core::load_class( $atts['cl'] ) ) {
                return Cosmos_Core::new_object( $atts['cl'] )->
                {
                    $atts['mt']
                }( $atts, $content );
            }
        }
    }
    public function cosmos_animation_style( $label = true ) {
        return array(
            'type'          => 'animation_style',
            'heading'       => esc_html__( 'CSS Animation', 'pix-core' ),
            'param_name'    => 'css_animation',
            'admin_label'   => $label,
            'value'         => '',
            'settings'      => array(
                'type'          => 'in',
                'custom'        => array(
                    array(
                        'label'         => esc_html__( 'Default', 'pix-core' ),
                        'values'        => array(
                            esc_html__( 'Appear from center', 'pix-core' ) => 'appear',
                        ),
                    ),
                ),
            ),
            'description' => esc_html__( 'Select type of animation for element to be animated when it enters the browsers viewport (Note: works only in modern browsers).', 'pix-core' ),
            'group'         => esc_html__( 'Animation', 'pix-core' ),
        );
    }
    public function cosmos_animation_delay( $label = true ) {
        $array = array(
            'type'          => 'textfield',
            'heading'       => esc_html__( 'Delay Animation', 'pix-core' ),
            'param_name'    => 'delay_animation',
            'admin_label'   => $label,
            'value'         => '0',
            'description'   => esc_html__( 'Unit use is miliseconds. You only enter number. Ex: 300 (~ 0.3s) or 2000 (~ 2s)', 'pix-core' ),
            'group'         => esc_html__( 'Animation', 'pix-core' ),
        );
        return $array;
    }
    // =======================Shortcode Functions==============================//
    /**
    * Blog List
    */
    public function blog_list( $atts, $content = null )
    {
        $default = array(
            'layout'            => 'blog',
            'style'             => '1',
            'column'            => '1',
            'limit_post'        => '-1',
            'offset_post'       => '0',
            'title_length'      => '',
            'excerpt_length'    => '',
            'sort_by'           => '',
            'pagination'        => 'yes',
            'button_text'       => esc_html__( 'Read More', 'pix-core' ),
            'extra_class'       => '',
            'category_list'     => '',
            'tag_list'          => '',
            'author_list'       => '',
            'format_list'       => '',
            'show_sticky'       => '',
            'show_category'     => 'yes',
            'show_content'      => 'excerpt',
            'category_color'    => '',
            'title_color'       => '',
            'meta_color'        => '',
            'excerpt_color'     => '',
            'button_color'      => '',
            'button_color_hv'   => '',
            'autoplay'          => 'false',
            'timeout'           => '3000',
            'css_animation'     => '',
            'delay_animation'   => '0',
            'is_parent_animation'=> 'no',
        );
        $data = Cosmos_Core::set_shortcode_defaults( $default, $atts);
        $data['id'] = Cosmos_Core::make_id();
        if ( function_exists( 'wpb_js_remove_wpautop' ) ) {
            $data['content'] = wpb_js_remove_wpautop( $content, true );
        } else {
            $data['content'] = $content;
        }
        return $this->render( 'blog_list', array('atts'=> $data ), true );
    }
    /**
    * Blog List
    */
    public function timeline( $atts, $content = null )
    {
        $default = array(
            'layout'            => 'timeline',
            'limit_post'        => '-1',
            'show_item'         => '4',
            'title_length'      => '',
            'content_length'    => '',
            'sort_by'           => 'timeline_newest',
            'button_text'       => esc_html__( 'Read More', 'pix-core' ),
            'extra_class'       => '',
            'method'            => 'cat',
            'post_list'         => '',
            'category_list'     => '',
            'category_slug'     => '',
            'show_content'      => 'yes',
            'title_color'       => '',
            'excerpt_color'     => '',
            'button_text_color' => '',
            'button_color'      => '',
            'button_color_hv'   => '',
            'display_showmore'  => 'yes', //default display button show more
            'button_showmore'   => esc_html__('Show more', 'pix-core'),
            'css_animation'     => '',
            'delay_animation'   => '0',
            'is_parent_animation'=> 'no',

        );
        $data = Cosmos_Core::set_shortcode_defaults( $default, $atts);
        if (isset($atts['post_list'])) {
            $data['post_list'] = (array) vc_param_group_parse_atts( $atts['post_list'] );
        }
        if ( empty( $data['category_slug'] ) ) {
            list( $data['category_list_parse'], $data['category_slug'] ) = Cosmos_Core_Util::get_list_vc_param_group( $data, 'category_list', 'category_slug' );
        }
        return $this->render( 'timeline', array('atts'   => $data,'content'=> $content ), true );
    }

    /**
    * Contact
    */
    public function contact( $atts, $content = null )
    {
        $default = array(
            'style'          => '1',
            'title'          => '',
            'description'    => '',
            'array_info'     => '',
            'contact_form'   => '',
            'extra_class'    => '',
            'icon_type'      => '',
            'icon_fw'        => '',
            'icon_ex'        => '',
            'padding_top'    => '',
            'padding_bottom' => '',
            'ctf_description'=> '',
            'bg_color'       => '',
            'text_color'     => '',
            'btn_text'       => '',
            'btn_url'        => '',
            'btn_color'      => '',
            'full_width'     => '',
            'btn_bghv_color' => '',
            'btn_bg_color'   => '',
            'btn_hv_color'   => '',
            'css_animation'     => '',
            'delay_animation'   => '0',
        );
        $data = Cosmos_Core::set_shortcode_defaults( $default, $atts);
        $data['id'] = Cosmos_Core::make_id();
        if (isset($atts['array_info'])) {
            $array_info = (array) vc_param_group_parse_atts( $atts['array_info'] );
            $data['array_info'] = $array_info;
        }
        if ( function_exists( 'wpb_js_remove_wpautop' ) ) {
            $data['content'] = wpb_js_remove_wpautop( $content, true );
        }
        else {
            $data['content'] = $content;
        }
        if ( !empty($data['btn_url']) ) {
            $data['btn_url'] = Cosmos_Core_Util::get_link($data['btn_url']);
        }
        return $this->render( 'contact', array('atts'=> $data), true );
    }

    /**
    * Toggle Box
    */
    public function toggle_box( $atts, $content = null )
    {
        $default = array(
            'block_title'       => '',
            'title'             => '',
            'extra_class'       => '',
            'active_color'      => '',
            'title_color'       => '',
            'content_color'     => '',
            'content_bg_color'  => '',
            'content'           => '',
            'toggle_content'    => '',
            'block_title_color' => '',
            'block_title_bg'    => '',
            'css_animation'     => '',
            'delay_animation'   => '0',
            'is_parent_animation' => 'no',
        );
        $data = Cosmos_Core::set_shortcode_defaults( $default, $atts);
        if ( !empty( $data['toggle_content'] ) ) {
            $toggle_content = vc_param_group_parse_atts( $data['toggle_content'] );
            $data['values'] = $toggle_content;
        }
        $data['id'] = Cosmos_Core::make_id();
        return $this->render( 'toggle_box', $data, true );
    }

    /**
    * Count down
    */
    public function count_down( $atts, $content = null ) {
        $default = array(
            'extra_class'       => '',
            'style'             => '1',
            'end_date'          => '',
            'title_color'       => '',
            'number_color'      => '',
            'border_color'      => '',
            'css_animation'     => '',
            'delay_animation'   => '0',
        );
        $data = Cosmos_Core::set_shortcode_defaults( $default, $atts);
        $data['id'] = Cosmos_Core::make_id();
        return $this->render( 'count_down', $data, true );
    }

    /**
    * Coming soon
    */
	public function coming_soon( $atts, $content = null ) {
		$default = array(
            'style'                     => '2',
            'has_logo'                  => 'yes',
            'title'                     => '',
            'description'               => '',
            'input_email_placeholder'   => esc_html__('Enter your email', 'pix-core'),
            'button_text'               => esc_html__('Sign Up', 'pix-core'),
            'image_background'          => '',
            'title_color'               => '',
            'description_color'         => '',
            'input_color'               => '',
            'input_border_color'        => '',
            'input_placeholder_color'   => '',
            'input_bg_color'            => '',
            'button_color'              => '',
            'button_bg_color'           => '',
            'countdown_style'           => '1',
            'countdown_end_date'        => '',
            'countdown_title_color'     => '',
            'countdown_number_color'    => '',
            'countdown_border_color'    => '',
            'social_style'              => '2',
            'social_align'              => 'center',
            'social_data'               => '',
            'social_icon_color'         => '',
            'social_icon_color_hover'   => '',
            'social_border_icon_color'  => '',
            'social_bg_color'           => '',
            'social_bg_color_hover'     => '',
            'extra_class'               => '',
            'css_animation'             => '',
            'delay_animation'           => '0',
		);
		$data = Cosmos_Core::set_shortcode_defaults( $default, $atts);
		$data['id'] = Cosmos_Core::make_id();
		return $this->render( 'coming_soon', $data, true );
	}

    /**
    * Testimonial
    */
    public function testimonial( $atts, $content = null )
    {
        $default = array(
            'style'                 => '1',
            'method'                => 'testi',//display by testimonial or category
            'offset_post'           => '',
            'limit_post'            => '-1',
            'sort_by'               => '',
            'category_list'         => '',
            'testi_list'            => '',
            'name_color'            => '',
            'autoplay'              => 'yes',
            'show_nav'              => 'yes',
            'position_color'        => '',
            'description_color'     => '',
            'bg_color'              => '',
            'bor_color'             => '',
            'nav_color'             => '',
            'extra_class'           => '',
            'item'                  => '3',
            'dot_color'             => '',
            'dot_color_hover'       => '',
            'css_animation'         => '',
            'delay_animation'       => '0',
            'is_parent_animation'   => 'no',
        );
        $data = Cosmos_Core::set_shortcode_defaults( $default, $atts);
        $data['id'] = Cosmos_Core::make_id();
        if (isset($atts['testi_list'])) {
            $data['testi_list'] = (array) vc_param_group_parse_atts( $atts['testi_list'] );
        }
        if ( empty( $data['category_slug'] ) ) {
            list( $data['category_list_parse'], $data['category_slug'] ) = Cosmos_Core_Util::get_list_vc_param_group( $data, 'category_list', 'category_slug' );
        }
        return $this->render( 'testimonial', array('atts'=> $data ), true );
    }

    /**
    * Team Carousel
    */
    public function team_carousel( $atts, $content = null )
    {
        $default = array(
            'style'               => '1',
            'layout'              => 'team',
            'offset_post'         => '0',
            'sort_by'             => '',
            'limit_post'          => '-1',
            'method'              => 'cat',
            'category_list'       => '',
            'category_slug'       => '',
            'team_list'           => '',
            'title_length'        => '',
            'description_length'  => '',
            'quote_length'        => '',
            'title_quote_text'    => esc_html__('INFORMATION', 'pix-core'),
            'position_color'      => '',
            'title_color'         => '',
            'description_color'   => '',
            'icon_color'          => '',
            'icon_bg_color'       => '',
            'side_color'          => '',
            'title_quote_color'   => '',
            'quote_color'         => '',
            'item'                => '1',
            'run_double'          => 'no',
            'position_dot'        => 'center',
            'dot_color'           => '',
            'dot_hover_color'     => '',
            'show_dot'            => 'true',
            'show_nav'            => 'true',
            'autoplay'            => 'true',
            'autoplay_time'       => '3000',
            'extra_class'         => '',
            'bg_icon_color'       => '',
            'bg_icon_hover_color' => '',
            'css_animation'         => '',
            'delay_animation'       => '0',
            'is_parent_animation'   => 'no',
        );
        $data = Cosmos_Core::set_shortcode_defaults( $default, $atts);
        if (isset($atts['team_list'])) {
            $team_list = (array) vc_param_group_parse_atts( $atts['team_list'] );
            $data['team_list'] = $team_list;
        }
        if ( empty( $data['category_slug'] ) ) {
            list( $data['category_list_parse'], $data['category_slug'] ) = Cosmos_Core_Util::get_list_vc_param_group( $data, 'category_list', 'category_slug' );
        }
        return $this->render( 'team_carousel', array('atts'   => $data,'content'=> $content ), true );
    }

    /**
    * Team List
    */
    public function team_list( $atts, $content = null )
    {
        $default = array(
            'layout'              => 'team',
            'column'              => '3',
            'offset_post'         => '0',
            'sort_by'             => '',
            'pagination'          => 'yes',
            'limit_post'          => '-1',
            'method'              => 'cat',
            'category_list'       => '',
            'category_slug'       => '',
            'team_list'           => '',
            'description_length'  =>'',
            'position_color'      => '',
            'title_color'         => '',
            'description_color'   => '',
            'icon_color'          => '',
            'icon_bg_color'       => '',
            'side_color'          => '',
            'extra_class'         => '',
            'bg_icon_color'       => '',
            'bg_icon_hover_color' => '',
            'css_animation'       => '',
            'delay_animation'       => '0',
            'is_parent_animation'   => 'no',
        );
        $data = Cosmos_Core::set_shortcode_defaults( $default, $atts);
        $data['id'] = Cosmos_Core::make_id();
        if ( isset( $atts['team_list'] ) ) {
            $data['team_list'] = (array) vc_param_group_parse_atts( $atts['team_list'] );
        }
        if ( !empty( $data['category_list'] ) ) {
            list( $data['category_list_parse'], $data['category_list'] ) = Cosmos_Core_Util::get_list_vc_param_group( $data, 'category_list', 'category_slug' );
        }
        return $this->render( 'team_list', array('atts'   => $data,'content'=> $content ), true );
    }
	
	/**
	* Shortcode Button
	*/
	public function button( $atts, $content = null ){
		$default = array(
			'title'             => esc_html__( 'Text on button', 'pix-core' ),
			'url'               => '',
            'icon'              => '',
			'button_color'      => '',
			'button_color_hover'=> '',
			'text_color'        => '',
			'text_color_hover'  => '',
			'border_color'      => '',
			'border_color_hover'=> '',
			'extra_class'       => '',
			'align'             => 'left',
			'style'				=> '1',
            'width'             => '',
            'shadow'            => 'no',
            'style_icon'        => '1',
            'border'            => 'no',
            'show_icon'         => 'no',
            'css_animation'     => '',
            'delay_animation'   => '0',
		);
		$data = Cosmos_Core::set_shortcode_defaults( $default, $atts);
		$data['id'] = Cosmos_Core::make_id();
		if ( !empty($data['url']) ) {
            $data['url'] = Cosmos_Core_Util::get_link_to_attr($data['url']);
        }
		return $this->render( 'button', $data, true );
	}

    /**
    * Block Title
    */
    public function block_title( $atts, $content = null )
    {
        $default = array(
            'style'             => '1',
            'heading'           => 'h3',
            'logo'              => '',
            'align'             => '',
            'title'             => '',
            'description'       => '',
            'title_size'        => '',
            'description_size'  => '',
            'font_weight'       => '',
            'extra_class'       => '',
            'title_color'       => '',
            'description_color' => '',
            'css_animation'     => '',
            'delay_animation'   => '0',
        );
        $data = Cosmos_Core::set_shortcode_defaults( $default, $atts);
        $data['id'] = Cosmos_Core::make_id();
        return $this->render( 'block_title', $data, true );
    }

    /**
    * Icon Box
    */
    public function icon_box( $atts, $content = null )
    {
        $default = array(
            'style'                     => '1',
            'title'                     => '',
            'description'               => '',
            'icon'                      => '',
            'height'                    => '',
            'bg_icon_color'             => '',
            'bg_hover_color'            => '',
            'border_color'              => '',
            'border_hover_color'        => '',
            'title_color'               => '',
            'title_hover_color'         => '',
            'description_color'         => '',
            'description_hover_color'   => '',
            'icon_color'                => '',
            'icon_hover_color'          => '',
            'bg_color'                  => '',
            'line_color'                => '',
            'extra_class'               => '',
            'css_animation'             => '',
            'delay_animation'           => '0',
        );
        $data = Cosmos_Core::set_shortcode_defaults( $default, $atts);
        $data['id'] = Cosmos_Core::make_id();
        return $this->render( 'icon_box', $data, true );
    }

    /**
    * Contact form
    */
    public function contact_form( $atts, $content = null )
    {
        $default = array(
            'style'                   =>'1',
            'title'                   =>'',
            'title_color'             =>'',
            'description'             =>'',
            'description_color'       =>'',
            'error_color'             =>'',
            'contact_form'            =>'',
            'input_color'             =>'',
            'placeholder_color'       =>'',
            'input_bg_color'          =>'',
            'input_border_color'      =>'',
            'button_color'            =>'',
            'button_hover_color'      =>'',
            'button_text_color'       =>'',
            'button_text_hover_color' =>'',
            'form_bg_color'           =>'',
            'icon_data'               =>'',
            'icon_color'              =>'',
            'icon_bg_color'           =>'',
            'icon_title_color'        =>'',
            'icon_description_color'  =>'',
            'side_icon_bg_color'      =>'',
            'extra_class'             =>'',
            'css_animation'           => '',
            'delay_animation'         => '0',
        );
        $data = Cosmos_Core::set_shortcode_defaults( $default, $atts);
        $data['id'] = Cosmos_Core::make_id();
        if ( !empty( $data['icon_data'] ) ) {
            $icon_data = vc_param_group_parse_atts( $data['icon_data'] );
            $data['icon_data'] = $icon_data;
        }
        return $this->render( 'contact_form', $data, true );
    }

    /**
    * Google Map
    */
    public function google_map( $atts, $content = null )
    {
        $default = array(
            'style'                    => '1',
            'content_type'             => '1',
            'locations'                => '',
            'image_marker'             => '',
            'image_marker_url'         => '',
            'height_map'               => '200',
            'zoom_map'                 => '',
            'title_color'              => '',
            'description_color'        => '',
            'content_hover_color'      => '',
            'title_active_color'       => '',
            'description_active_color' => '',
            'location_bg_active_color' => '',
            'extra_class'              => '',
        );
        $data = Cosmos_Core::set_shortcode_defaults( $default, $atts);
        $data['id'] = Cosmos_Core::make_id();
        if ( !empty( $data['locations'] ) ) {
            $locations = vc_param_group_parse_atts( $data['locations'] );
            $data['locations'] = $locations;
        }
        return $this->render( 'google_map', $data, true );
    }
    
    /**
    * Social shortcode
    */
    public function social( $atts, $content = null )
    {
        $default = array(
            'style'                 => '1',
            'align'                 => 'left',
            'url'                   => '',
            'icon'                  => '',
            'social'                => '',
            'icon_color'            => '',
            'icon_color_hover'      => '',
            'border_icon_color'     => '',
            'bg_color'              => '',
            'bg_color_hover'        => '',
            'extra_class'           => '',
            'css_animation'         => '',
            'delay_animation'       => '0',
        );
        $data = Cosmos_Core::set_shortcode_defaults( $default, $atts);
        if ( !empty( $data['social'] ) ) {
            $social = vc_param_group_parse_atts( $data['social'] );
            $data['values'] = $social;
        }
        $data['id'] = Cosmos_Core::make_id();
        return $this->render( 'social', $data, true );
    }

    /**
    * Subscribe email
    */
    public function subscribe_email( $atts, $content = null )
    {
        $default = array(
            'style'                      => '2',
            'title'                      => esc_html__('Subscribe For Our Monthly News Updates', 'pix-core'),
            'sub_title'                  => esc_html__('Join our mailing list and stay informed about our news and updates.', 'pix-core'),
            'input_fullname_placeholder' => esc_html__('Enter fullname', 'pix-core'),
            'input_email_placeholder'    => esc_html__('Enter your email', 'pix-core'),
            'button_text'                => esc_html__('Subscribe now', 'pix-core'),
            'title_color'                => '',
            'sub_title_color'            => '',
            'input_color'                => '',
            'input_border_color'         => '',
            'input_placeholder_color'    => '',
            'input_bg_color'             => '',
            'button_color'               => '',
            'button_hover_color'         => '',
            'button_bg_color'            => '',
            'button_hover_bg_color'      => '',
            'extra_class'                => '',
            'css_animation'              => '',
            'delay_animation'            => '0',
        );
        $data = Cosmos_Core::set_shortcode_defaults( $default, $atts);
        $data['id'] = Cosmos_Core::make_id();
        return $this->render( 'subscribe_email', $data, true );
    }


    public function tour_search( $atts, $content = null )
    {
        $default = array(
            'style'                      => '1',
            'title_search'               => esc_html( 'Filter Destination', 'pix-core' ),
            'holder_search'              => esc_html( 'Enter tour name', 'pix-core' ),
            'title_price'                => esc_html( 'Filter Price', 'pix-core' ),
            'button_text'                => esc_html( 'Filter', 'pix-core' ),
            'extra_class'                => '',
            'color_bg'                   => '',
            'color_text'                 => '',
            'color_search'               => '',
            'color_price'                => '',
            'color_price_2'              => '',
            'color_button'               => '',
            'color_button_hv'            => '',
            'color_button_bg'            => '',
            'color_button_bg_hv'         => '',
            'color_line'                 => '',
            'css_animation'              => '',
            'delay_animation'            => '0',
            'is_parent_animation'        => 'no',
        );
        $data = Cosmos_Core::set_shortcode_defaults( $default, $atts);
        $data['id'] = Cosmos_Core::make_id();
        return $this->render( 'tour_search', $data, true );
    }
    /**
    * Video
    */
    public function demo_app( $atts, $content = null )
    {
        $default = array(
            'style'                     => '1',
            'title'                     => '',
            'first_title'               => '',
            'last_title'                => '',
            'description'               => '',
            'image'                     => '',
            'url'                       => '',
            'app_content'               => '',
            'image_background'          => '',
            'youtube_id'                => '',
            'title_color'               => '',
            'first_title_color'         => '',
            'last_title_color'          => '',
            'description_color'         => '',
            'bg_color'                  => '',
            'extra_class'               => '',
            'css_animation'             => '',
            'delay_animation'           => '0',
        );
        $data = Cosmos_Core::set_shortcode_defaults( $default, $atts);
        $data['id'] = Cosmos_Core::make_id();
        if ( !empty( $data['app_content'] ) ) {
            $app_content = vc_param_group_parse_atts( $data['app_content'] );
            $data['values'] = $app_content;
        }
        return $this->render( 'demo_app', $data, true );
    }
    /**
    * banner
    */
    public function banner( $atts, $content = null ){
		$default = array(
			'style'				=>'1',
			'header'			=>'',
			'description'		=>'',
            'header_size'       =>'',
			'features'			=>'',//style 6
			'carousel'			=>'',//style 6
			'btn_link'			=>'',
			'img_primary'		=>'',
			'images'			=>'',//style 4
			'video'				=>'',//style 4
			'header_color'		=>'',
			'slides_color'		=>'',//style 6
			'features_color'	=>'',//style 6
			'autoplay'			=> 'true',//carousel
			'timeout'			=> '3000',//carousel
            'color_background'  => '',
            'image_background_mb'  => '',
			'extra_class'       => '',
            'css_animation'     => '',
		);
		$data = Cosmos_Core::set_shortcode_defaults( $default, $atts);
		$data['id'] = Cosmos_Core::make_id();
		if ( !empty($data['btn1_link']) ) {
            $data['btn1_link'] = Cosmos_Core_Util::get_link($data['btn1_link']);
        }
        if ( !empty($data['btn2_link']) ) {
            $data['btn2_link'] = Cosmos_Core_Util::get_link($data['btn2_link']);
        }
        if (isset($atts['features'])) {
            $data['features'] = (array) vc_param_group_parse_atts( $atts['features'] );
        }
        if (isset($atts['carousel'])) {
            $data['carousel'] = (array) vc_param_group_parse_atts( $atts['carousel'] );
        }
        if (isset($atts['btn_link'])) {
            $data['btn_link'] = (array) vc_param_group_parse_atts( $atts['btn_link'] );
        }
		return $this->render( 'banner', $data, true );
	}

    /**
     * carousel
     */
    public function carousel( $atts, $content = null )
    {
        $default = array(
            'image'                 => '',
            'size'                  => '1',
            'sort_by'               => '',
            'extra_class'           => '',
            'dot_color'             => '',
            'active_dot_color'      => '',
            'hover_dot_color'       => '',
            'item'                  => '1',
            'autoplay'              => 'no',
            'css_animation'         => '',
            'delay_animation'       => '0',
        );
        $data = Cosmos_Core::set_shortcode_defaults( $default, $atts);
        $data['id'] = Cosmos_Core::make_id();
        $del_space = str_replace(" ","", trim($data['image']));
        $output = str_replace(',,',',',$del_space);
        $data['image_arr'] = explode(',', $output);
        return $this->render( 'carousel', $data, true );
    }

    /**
    * Count download
    */
    public function count_download( $atts, $content = null ) {
        $default = array(
            'extra_class'           => '',
            'style'                 => '3',
            'icon_download'         => '',
            'title_download'        => '',
            'number_download'       => '',
            'title_color'           => '',
            'number_color'          => '',
            'background_icon_color' => '',
            'border_color'          => '',
            'css_animation'         => '',
            'delay_animation'       => '0',
        );
        $data = Cosmos_Core::set_shortcode_defaults( $default, $atts);
        $data['id'] = Cosmos_Core::make_id();
        return $this->render( 'count_download', $data, true );
    }

    /**
    * Proccess Bar
    */
    public function process_bar( $atts, $content = null ) {
        $default = array(
            'extra_class'           => '',
            'style'                 => '1',
            'column'                => '1',
            'process_content'       => '',
            'title'                 => '',
            'number'                => '',
            'process_color'         => '',
            'not_process_color'     => '',
            'title_color'           => '',
            'number_color'          => '',
            'border_color'          => '',
            'css_animation'         => '',
            'delay_animation'       => '0',
        );
        $data = Cosmos_Core::set_shortcode_defaults( $default, $atts);
        $data['id'] = Cosmos_Core::make_id();
        if ( !empty( $data['process_content'] ) ) {
            $process_content = vc_param_group_parse_atts( $data['process_content'] );
            $data['values'] = $process_content;
        }
        return $this->render( 'process_bar', $data, true );
    }

    /*
        screenshot
     */
    public function screenshot( $atts, $content = null ) {
        $default = array(
            'extra_class'           => '',
            'style'                 => '1',
            'screenshot_content'    => '',
            'image'                 => '',
            'title'                 => '',
            'title_des'             => '',
            'description'           => '',
            'title_color'           => '',
            'title_des_color'       => '',
            'description_color'     => '',
            'dot_color'             => '',
            'dot_hover_color'       => '',
            'active_dot_color'      => '',
            'border_color'          => '',
            'autoplay'              => 'no',
            'item'                  => '4',
            'show_nav'              => 'yes',
            'show_dot'              => 'yes',
            'image_size'            => '1',
            'css_animation'         => '',
            'delay_animation'       => '0',
        );
        $data = Cosmos_Core::set_shortcode_defaults( $default, $atts);
        $data['id'] = Cosmos_Core::make_id();
        if ( !empty( $data['screenshot_content'] ) ) {
            $screenshot_content = vc_param_group_parse_atts( $data['screenshot_content'] );
            $data['values'] = $screenshot_content;
        }
        $del_space = str_replace(" ","", trim($data['image']));
        $output = str_replace(',,',',',$del_space);
        $data['image_arr'] = explode(',', $output);
        return $this->render( 'screenshot', $data, true );
    }

    /*
        faq
     */
    public function faq( $atts, $content = null )
    {
        $default = array(
            'block_title'       => '',
            'layout'            => 'faq',
            'offset_post'       => '0',
            'category_list'     => '',
            'category_slug'     => '',
            'post_list'         => '',
            'limit_post'        => '-1',
            'method'            => 'cat',
            'extra_class'       => '',
            'active_color'      => '',
            'title_color'       => '',
            'content_color'     => '',
            'content_bg_color'  => '',
            'block_title_color' => '',
            'block_title_bg'    => '',
            'css_animation'     => '',
            'delay_animation'       => '0',
            'is_parent_animation'   => 'no',
        );
        $data = Cosmos_Core::set_shortcode_defaults( $default, $atts);
        if ( !empty( $data['post_list'] ) ) {
            $data['post_list'] = (array) vc_param_group_parse_atts( $data['post_list'] );
        }
        if ( !empty( $data['category_list'] ) ) {
            list( $data['category_list_parse'], $data['category_list'] ) = Cosmos_Core_Util::get_list_vc_param_group( $data, 'category_list', 'category_slug' );
        }
        $data['id'] = Cosmos_Core::make_id();
        return $this->render( 'faq', array('atts'   => $data,'content'=> $content ), true );
    }

    /**
    * portfolio
    */
    public function portfolio ( $atts, $content = null )
    {
        $default = array(
            'style'                     => '1',
            'layout'                    => 'portfolio',
            'sort_by'                   => '',
            'limit_post'                => '-1',
            'offset_post'               => '0',
            'method'                    => 'cat',
            'category_list'             => '',
            'category_slug'             => '',
            'post_list'                 => '',
            'extra_class'               => '',
            'text_filter_color'         => '',
            'text_filter_hover_color'   => '',
            'filter_bg_color'           => '',
            'filter_bg_hover_color'     => '',
            'bg_hover_color'            => '',
            'border_color'              => '',
            'column'                    => '4',
            'css_animation'             => '',
            'delay_animation'           => '0',
            'is_parent_animation'       => 'no',
        );
        $data = Cosmos_Core::set_shortcode_defaults( $default, $atts);
        $data['id'] = Cosmos_Core::make_id();
        if (isset($atts['post_list'])) {
            $data['post_list'] = (array) vc_param_group_parse_atts( $atts['post_list'] );
        }
        if ( empty( $data['category_slug'] ) ) {
            list( $data['category_list_parse'], $data['category_slug'] ) = Cosmos_Core_Util::get_list_vc_param_group( $data, 'category_list', 'category_slug' );
        }
        return $this->render( 'portfolio', array('atts' => $data, 'content' => $content ), true );
    }

    /**
    * Price
    */
    public function price( $atts, $content = null ) {
        $default = array(
            'extra_class'         => '',
            'style'               => '1',
            'layout'              => 'price',
            'sort_by'             => '',
            'limit_post'          => '-1',
            'offset_post'         => '0',
            'method'              => 'cat',
            'category_list'       => '',
            'category_slug'       => '',
            'button_text'         => esc_html__( 'BUY NOW', 'pix-core' ),
            'post_list'           => '',
            'price_font_size'     => '',
            'currency_font_size'  => '',
            'title_color'         => '',
            'description_color'   => '',
            'price_color'         => '',
            'attributes_color'    => '',
            'attributes_color_border'    => '',
            'unit_color'          => '',
            'item_bg_color'       => '',
            'color_text_hover'    => '',
            'color_bg_hover'      => '',
            'color_text_featured' => '',
            'color_bg_featured'   => '',
            'color_border_box'    => '',
            'color_button'        => '',
            'color_button_hv'     => '',
            'color_button_border' => '',
            'color_button_border_hv' => '',
            'color_button_bg'     => '',
            'color_button_bg_hv'  => '',
            'autoplay'            => 'no',
            'item'                => '4',
            'show_nav'            => 'yes',
            'css_animation'       => '',
            'delay_animation'     => '0',
            'is_parent_animation' => 'no',
        );
        $data = Cosmos_Core::set_shortcode_defaults( $default, $atts);
        $data['id'] = Cosmos_Core::make_id();
        if ( !empty( $data['post_list'] ) ) {
            $post_list = vc_param_group_parse_atts( $data['post_list'] );
            $data['post_list'] = $post_list;
        }
        if ( empty( $data['category_slug'] ) ) {
            list( $data['category_list_parse'], $data['category_slug'] ) = Cosmos_Core_Util::get_list_vc_param_group( $data, 'category_list', 'category_slug' );
        }
        return $this->render( 'price', array('atts'   => $data,'content'=> $content ), true );
    }
}