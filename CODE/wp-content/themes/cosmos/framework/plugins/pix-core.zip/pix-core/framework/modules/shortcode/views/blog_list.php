<?php
$model = new Cosmos_Core_Blog;
$model->init( $atts);
$block_cls   = $model->attributes['extra_class'] . ' ' . $model->attributes['block-class'];

$css_animation = '';
$css_animation_class = '';
$delay_animation = 0;
$css_animation_parent = '';
$css_animation_parent_class = '';
$delay_animation_parent = 0;

if ( !empty($model->attributes['css_animation']) && !empty($model->attributes['is_parent_animation']) && $model->attributes['is_parent_animation'] != 'yes') {
	$css_animation = $model->attributes['css_animation'];
	$css_animation_class = 'animate-run';
	$delay_animation = (int) $model->attributes['delay_animation'];
}

if ( !empty($model->attributes['css_animation']) && !empty($model->attributes['is_parent_animation']) && $model->attributes['is_parent_animation'] == 'yes') {
	$css_animation_parent = $model->attributes['css_animation'].'-children';
	$css_animation_parent_class = 'animate-run';
	$delay_animation_parent = (int) $model->attributes['delay_animation'];
}

$style = $atts['style'];
$_autoplay = !empty($atts['autoplay']) ? esc_attr($atts['autoplay']) : null;
$_timeout = !empty($atts['timeout']) ? esc_attr((int)$atts['timeout']) : null;
$_carousel = 'data-autoplay="'. $_autoplay .'" data-timeout="'. $_timeout .'"';
if($style == 1){
	$html_format = '
		<div class="{RESPONSIVE}">
			<div class="posts {POST_CLASS}">
			    <div class="image_posts">
			    	<div class="blog-galleries" '.$_carousel.'>
			    		{IMAGE}
			    	</div>
			        {DATE}
			    </div>
			    <div class="text_posts" data-type="all">
			        {CATEGORY}
			        {TITLE}
			        {META}
			        {EXCERPT}
			    </div>
			    {BUTTON}
			</div>
		</div>
	';
}else{
	$html_format = '
	<div class="posts {POST_CLASS}">
		<div class="row">
			<div class = "col-md-6 col-sm-5 col-xs-12">
			    <div class="image_posts">
			    	<div class="blog-galleries" '.$_carousel.'>
			    		{IMAGE}
			    	</div>
			        {DATE}
			    </div>
			</div>
			<div class = "col-md-6 col-sm-7 col-xs-12">
			    <div class="text_posts">
			        {CATEGORY}
			        {TITLE}
			        {META}
			        {EXCERPT}
			    </div>
			    {BUTTON}
			</div>
	    </div>
	</div>
	';
}
$html_options = array(
	'html_format'			=> $html_format
);
?>
<div id="<?php echo esc_attr($atts['id']); ?>" class="pix-shortcode sc-blog-list <?php echo esc_attr( $block_cls ); ?> <?php echo esc_attr($css_animation_class); ?>"  data-animate="<?php echo esc_attr($css_animation); ?>" data-delay="<?php echo esc_attr($delay_animation); ?>">
	<div class="section_blog style-<?php echo esc_attr($style);?>">
	    <div class="row row-eq-height <?php echo esc_attr($css_animation_parent_class);?>" data-animate="<?php echo esc_attr($css_animation_parent); ?>" data-delay="<?php echo esc_attr($delay_animation_parent); ?>">
		    <?php $model->render_grid( $html_options ); ?>
        </div>
		<div class="clearfix"></div>
		<?php
		if( $model->attributes['pagination'] == 'yes' ) {
			echo Cosmos_Core_Pagination::paging_nav( $model->query->max_num_pages, 2, $model->query);
		} ?>
	</div>
</div>