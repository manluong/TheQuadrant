<?php
$sc_controller = new Cosmos_Core_Shortcodes_Controller();
$true_false = array(
    esc_html__('Yes', 'pix-core')   => 'true' ,
    esc_html__('No', 'pix-core')    => 'false'
);
$method = array(
    esc_html__('FAQs', 'pix-core')      => 'faq',
    esc_html__('Category', 'pix-core')  => 'cat'
);
$sort_by    = Cosmos_Core_Params::get('sort-other') ;
// get faq categories
$taxonomy   = 'cosmos_faq_cat';
$params_cat = array('empty'=> esc_html__( '-- All Faq Categories --', 'pix-core' ) );
$categories = Cosmos_Core_Com::get_tax_options2slug( $taxonomy, $params_cat );
// get all faq
$args       = array('post_type'=> 'Cosmos_Faq');
$options = array('empty'=> esc_html__( '-- None --', 'pix-core' ) );
$post_list = Cosmos_Core_Com::get_post_title2id( $args, $options );
$params = array(
    array(
        "type"        => "textfield",
        "heading"     => esc_html__( "Block Title", 'pix-core' ),
        "param_name"  => "block_title",
        "description" => esc_html__( "Please enter block title.", 'pix-core' ),
    ),
    array(
        'type'       => 'dropdown',
        'heading'    => esc_html__( 'Display by', 'pix-core' ),
        'param_name' => 'method',
        'value'      => $method,
        'std'        => 'cat',
        'description'=> esc_html__( 'Choose faq category or special faqs to display.',  'pix-core'  ),
        'group'      => esc_html__('Filter', 'pix-core')
    ),
    array(
        'type'       => 'param_group',
        'heading'    => esc_html__( 'Category', 'pix-core' ),
        'param_name' => 'category_list',
        'callbacks'   => array(
           'after_add' => 'vcChartParamAfterAddCallback'
        ),
        'params'     => array(
            array(
                'type'       => 'dropdown',
                'admin_label'=> true,
                'heading'    => esc_html__( 'Add Category', 'pix-core' ),
                'param_name' => 'category_slug',
                'value'      => $categories,
                'description'=> esc_html__( 'Choose special category to filter', 'pix-core'  )
            ),
        ),
        'value'      => '',
        'dependency' => array(
            'element'	=> 'method',
            'value'  	=> array('cat' )
        ),
        'description'=> esc_html__( 'Default no filter by category.', 'pix-core' ),
        'group'      => esc_html__('Filter', 'pix-core')
    ),
    array(
        'type'       => 'param_group',
        'heading'    => esc_html__( 'FAQs List', 'pix-core' ),
        'param_name' => 'post_list',
        'callbacks'   => array(
           'after_add' => 'vcChartParamAfterAddCallback'
        ),
        'params'     => array(
            array(
                'type'       => 'dropdown',
                'admin_label'=> true,
                'heading'    => esc_html__( 'Add faq', 'pix-core' ),
                'param_name' => 'post_id',
                'value'      => $post_list,
                'description'=> esc_html__( 'Choose faq to show', 'pix-core'  )
            ),
        ),
        'value'      => '',
        'dependency' => array(
            'element'=> 'method',
            'value'  => array('faq')
        ),
        'description'=> esc_html__( 'Default empty.', 'pix-core' ),
        'group'      => esc_html__('Filter', 'pix-core')
    ),
    
    array(
        'type'       => 'textfield',
        'heading'    => esc_html__( 'Limit Posts', 'pix-core' ),
        'param_name' => 'limit_post',
        'value'      => '',
        'description'=> esc_html__( 'Add limit posts per page. Set -1 or empty to show all.', 'pix-core' ),
        'group'      => esc_html__('Filter', 'pix-core')
    ),
    array(
        'type'       => 'textfield',
        'heading'    => esc_html__( 'Offset Posts', 'pix-core' ),
        'param_name' => 'offset_post',
        'value'      => '0',
        'description'=> esc_html__( 'Enter offset to pass over posts. If you want to start on record 6, using offset 5', 'pix-core' ),
        'group'      => esc_html__('Filter', 'pix-core')
    ),
    array(
        'type'       => 'dropdown',
        'heading'    => esc_html__( 'Sort By', 'pix-core' ),
        'param_name' => 'sort_by',
        'value'      => $sort_by,
        'description'=> esc_html__( 'Select order to display list properties.', 'pix-core' ),
        'group'      => esc_html__('Filter', 'pix-core')
    ),
    array(
        'type'       => 'textfield',
        'heading'    => esc_html__( 'Extra Class', 'pix-core' ),
        'param_name' => 'extra_class',
        'description'=> esc_html__( 'Enter extra class name.', 'pix-core' ),
    ),
	array(
        "type"        => "colorpicker",
        "class"       => "",
        "heading"     => esc_html__( "Block Title Color", 'pix-core' ),
        "param_name"  => "block_title_color",
        "description" => esc_html__( "Choose text color for block title.", 'pix-core' ),
        'group'       => esc_html__('Options', 'pix-core'),
    ),
    array(
        "type"        => "colorpicker",
        "class"       => "",
        "heading"     => esc_html__( "Block Title Background Color", 'pix-core' ),
        "param_name"  => "block_title_bg",
        "description" => esc_html__( "Choose background color for block title.", 'pix-core' ),
        'group'       => esc_html__('Options', 'pix-core'),
    ),
    array(
        "type"        => "colorpicker",
        "class"       => "",
        "heading"     => esc_html__( "Title Question Color", 'pix-core' ),
        "param_name"  => "title_color",
        "description" => esc_html__( "Choose the title question color.", 'pix-core' ),
        'group'       => esc_html__('Options', 'pix-core'),
    ),
    array(
        "type"        => "colorpicker",
        "class"       => "",
        "heading"     => esc_html__( "Answer Text Color", 'pix-core' ),
        "param_name"  => "content_color",
        "description" => esc_html__( "Choose the color for text in answer.", 'pix-core' ),
        'group'       => esc_html__('Options', 'pix-core'),
    ),
    array(
        "type"        => "colorpicker",
        "class"       => "",
        "heading"     => esc_html__( "Content Background Color", 'pix-core' ),
        "param_name"  => "content_bg_color",
        "description" => esc_html__( "Choose the color for background content.", 'pix-core' ),
        'group'       => esc_html__('Options', 'pix-core'),
    ),
    array(
        "type"        => "colorpicker",
        "class"       => "",
        "heading"     => esc_html__( "Active Color", 'pix-core' ),
        "param_name"  => "active_color",
        "description" => esc_html__( "Choose the active color.", 'pix-core' ),
        'group'       => esc_html__('Options', 'pix-core'),
    ),
    $sc_controller->cosmos_animation_style(),
    $sc_controller->cosmos_animation_delay(),
    array(
        'type'        => 'dropdown',
        'heading'     => esc_html__( 'Animation To Children', 'pix-core' ),
        'param_name'  => 'is_parent_animation',
        'value'       => array(
                            esc_html__('Yes', 'pix-core')=> 'yes',
                            esc_html__('No', 'pix-core') => 'no',
                        ),
        'std'         => 'no',
        'description' => esc_html__('Apply run animation to children element'),
        'group'       => esc_html__('Animation', 'pix-core'),
    )  
);
vc_map(array(
    'name'       => esc_html__( 'PIX FAQs', 'pix-core' ),
    'base'       => 'pixcore_faq_sc',
    'class'      => 'pixcore-sc',
    'icon'       => 'icon-pixcore_faq_sc',
    'category'   => COSMOS_CORE_SC_CATEGORY,
    'description'=> esc_html__( 'List of faqs.', 'pix-core' ),
    'params'     => $params
));