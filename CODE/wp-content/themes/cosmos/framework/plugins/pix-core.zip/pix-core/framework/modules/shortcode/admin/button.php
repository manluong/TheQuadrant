<?php
$sc_controller = new Cosmos_Core_Shortcodes_Controller();
$align = Cosmos_Core_Params::get('align');
$style = array(
	esc_html__('Style 1','pix-core')	=> '1',
	esc_html__('Style 2','pix-core')	=> '2',
	esc_html__('Style 3','pix-core')	=> '3',
);
$style_icon = array(
	esc_html__('Style 1','pix-core')	=> '1',
	esc_html__('Style 2','pix-core')	=> '2',
);
$width = array(
	esc_html__('Small','pix-core')	=> 'small',
	esc_html__('Medium','pix-core')	=> 'medium',
	esc_html__('Large','pix-core')	=> 'large',
	esc_html__('Full','pix-core')	=> 'full',
);
$yes_no = array(
	esc_html__('Yes','pix-core')	=> 'yes',
	esc_html__('No','pix-core')		=> 'no',
);
$params = array(
	array(
		'type'        => 'dropdown',
		'heading'     => esc_html__( 'Style', 'pix-core' ),
		'admin_label' => true,
		'param_name'  => 'style',
		'value'       => $style,
		'description' => esc_html__( 'Choose style of button.', 'pix-core' )
	),
	array(
		'type'        => 'dropdown',
		'heading'     => esc_html__( 'Show Icon', 'pix-core' ),
		'param_name'  => 'show_icon',
		'value'       => $yes_no,
		'std'		  => 'no',
		'description' => esc_html__( 'Show icon on button. Default is No', 'pix-core' )
	),
	array(
		'type'        => 'dropdown',
		'heading'     => esc_html__( 'Style Icon', 'pix-core' ),
		'param_name'  => 'style_icon',
		'value'       => $style_icon,
		'description' => esc_html__( 'Choose style icon to show', 'pix-core' ),
		'dependency'    => array(
			'element'		=> 'show_icon',
			'value'         => array( 'yes' )
		),
	),
	array(
		'type'       => 'iconpicker',
		'heading'    => esc_html__( 'Choose icon', 'pix-core' ),
		'param_name' => 'icon',
		'description'=> esc_html__( 'Please choose icon to show', 'pix-core' ),
		'dependency'    => array(
			'element'		=> 'show_icon',
			'value'         => array( 'yes' )
		),
	),
	array(
		'type'        => 'textfield',
		'heading'     => esc_html__( 'Text On Button', 'pix-core' ),
		'admin_label' => true,
		'param_name'  => 'title',
		'value'       => 'Text On Button',
		'description' => esc_html__( 'Please input text to show.', 'pix-core' )
	),
	
	array(
		'type'        => 'vc_link',
		'heading'     => esc_html__( 'Url', 'pix-core' ),
		'param_name'  => 'url',
		'value'       => '',
		'description' => esc_html__( 'Please input to url redirect.', 'pix-core' )
	),
	array(
		'type'          => 'textfield',
		'heading'       => esc_html__( 'Extra Class', 'pix-core' ),
		'param_name'    => 'extra_class',
		'description'   => esc_html__( 'Enter extra class name.', 'pix-core' )
	),

	array(
		'type'        => 'dropdown',
		'heading'     => esc_html__( 'Align', 'pix-core' ),
		'param_name'  => 'align',
		'value'       => $align,
		'std'		  => 'left',
		'description' => esc_html__( 'Choose align to show.', 'pix-core' ),
		'group'         => esc_html__( 'Properties', 'pix-core' ),
	),
	array(
		'type'        => 'dropdown',
		'heading'     => esc_html__( 'Width', 'pix-core' ),
		'param_name'  => 'width',
		'value'       => $width,
		'std'		  => 'full',
		'description' => esc_html__( 'Please choose width for button.', 'pix-core' ),
		'group'         => esc_html__( 'Properties', 'pix-core' ),
	),
	array(
		'type'        => 'dropdown',
		'heading'     => esc_html__( 'Border Button', 'pix-core' ),
		'param_name'  => 'border',
		'value'       => $yes_no,
		'std'		  => 'no',
		'description' => esc_html__( 'Show border for button', 'pix-core' ),
		'group'         => esc_html__( 'Properties', 'pix-core' ),
	),
	array(
		'type'        => 'dropdown',
		'heading'     => esc_html__( 'Shadow', 'pix-core' ),
		'param_name'  => 'shadow',
		'value'       => $yes_no,
		'std'		  => 'no',
		'description' => esc_html__( 'Shadow of button', 'pix-core' ),
		'group'         => esc_html__( 'Properties', 'pix-core' ),
	),
	
	array(
		'type'          => 'colorpicker',
		'heading'       => esc_html__( 'Title Color', 'pix-core' ),
		'param_name'    => 'text_color',
		'description'   => esc_html__( 'Choose color for title', 'pix-core' ),
		'group'         => esc_html__( 'Custom CSS', 'pix-core' ),
	),
	array(
		'type'          => 'colorpicker',
		'heading'       => esc_html__( 'Title Color Hover', 'pix-core' ),
		'param_name'    => 'text_color_hover',
		'description'   => esc_html__( 'Choose color for title when hover', 'pix-core' ),
		'group'         => esc_html__( 'Custom CSS', 'pix-core' ),
	),
	array(
		'type'          => 'colorpicker',
		'heading'       => esc_html__( 'Button Color', 'pix-core' ),
		'param_name'    => 'button_color',
		'description'   => esc_html__( 'Choose color for button', 'pix-core' ),
		'group'         => esc_html__( 'Custom CSS', 'pix-core' ),
	),
	array(
		'type'          => 'colorpicker',
		'heading'       => esc_html__( 'Button Color Hover', 'pix-core' ),
		'param_name'    => 'button_color_hover',
		'description'   => esc_html__( 'Choose color for button when hover', 'pix-core' ),
		'group'         => esc_html__( 'Custom CSS', 'pix-core' ),
	),
	array(
		'type'          => 'colorpicker',
		'heading'       => esc_html__( 'Border Color', 'pix-core' ),
		'param_name'    => 'border_color',
		'description'   => esc_html__( 'Choose color for border', 'pix-core' ),
		'group'         => esc_html__( 'Custom CSS', 'pix-core' ),
		'dependency'  => array(
			'element'   => 'border',
			'value'     => array( 'yes' )
		),
	),
	array(
		'type'          => 'colorpicker',
		'heading'       => esc_html__( 'Border Color Hover', 'pix-core' ),
		'param_name'    => 'border_color_hover',
		'description'   => esc_html__( 'Choose color for border when hover', 'pix-core' ),
		'group'         => esc_html__( 'Custom CSS', 'pix-core' ),
		'dependency'  => array(
			'element'   => 'border',
			'value'     => array( 'yes' )
		),
	),
	$sc_controller->cosmos_animation_style(),
	$sc_controller->cosmos_animation_delay(),

);
vc_map(array(
	'name'               => esc_html__( 'PIX Button', 'pix-core' ),
	'base'               => 'pixcore_button_sc',
	'class'              => 'pixcore-sc',
	'icon'               => 'icon-pixcore_button_sc',
	'category'           => COSMOS_CORE_SC_CATEGORY,
	'description'        => esc_html__( 'Button Of Link', 'pix-core' ),
	'params'             => $params
));