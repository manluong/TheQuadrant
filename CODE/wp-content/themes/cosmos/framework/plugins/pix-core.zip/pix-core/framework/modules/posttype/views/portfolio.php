<?php $prefix='cosmos_portfolio_'; ?>
<div class="pix-custom-meta" >
	<div class="pix-meta-row active" >
		<div class="pix-desc">
			<span><?php esc_html_e( 'Portfolio Images', 'pix-core' );?></span>
			<p class="description"><?php esc_html_e( 'Images should have minimum size: 800x600. Bigger size images will be cropped automatically.', 'pix-core' );?></p>
		</div>
		<div class="pix-field">
			<?php $this->gallery( $prefix . 'meta['. $prefix .'portfolio_images]', $data_meta['portfolio_images'] ); ?>
		</div>
	</div>
</div>