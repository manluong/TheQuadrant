<?php
$sc_controller = new Cosmos_Core_Shortcodes_Controller();
$style = array(
	esc_html__( 'Style 1', 'pix-core' ) => '1',
	esc_html__( 'Style 2', 'pix-core' ) => '2'
);

$method = array(
	esc_html__( 'Category', 'pix-core' ) => 'cat',
	esc_html__( 'Teams', 'pix-core' )    => 'team'
);

$sort_by    = Cosmos_Core_Params::get('sort-other') ;

$item = array(
	esc_html__( '1', 'pix-core' )	=> '1',
	esc_html__( '2', 'pix-core' ) 	=> '2',
	esc_html__( '3', 'pix-core' ) 	=> '3',
);
$yes_no     = array(
	esc_html__('Yes', 'pix-core') => 'yes',
	esc_html__('No', 'pix-core')  => 'no'
);
$true_false = array(
	esc_html__('Yes', 'pix-core') => 'true',
	esc_html__('No', 'pix-core')  => 'false'
);
// get Team categories
$taxonomy   = 'cosmos_team_cat';
$params_cat = array('empty'=> esc_html__( '-- All Team Categories --', 'pix-core' ) );
$categories = Cosmos_Core_Com::get_tax_options2slug( $taxonomy, $params_cat );
// get all team
$args       = array('post_type' => 'cosmos_team');
$options = array('empty'=> esc_html__( '-- None --', 'pix-core' ) );
$team_list  = Cosmos_Core_Com::get_post_title2id( $args, $options );
// print_r($team_list); die('aaa');
$params = array(
	array(
		'type'        => 'dropdown',
		'admin_label' => true,
		"class"       => "",
		'heading'     => esc_html__( 'Style', 'pix-core' ),
		'param_name'  => 'style',
		'value'       => $style,
        'std'         => '1',
		'description' => esc_html__( 'Select style.',  'pix-core'  )
	),
	array(
        'type'       => 'textfield',
        'heading'    => esc_html__( 'Title Length', 'pix-core' ),
        'param_name' => 'title_length',
        'value'      => '',
        'description'=> esc_html__( 'Set length for title', 'pix-core' ),
    ),
	array(
        'type'       => 'textfield',
        'heading'    => esc_html__( 'Description Length', 'pix-core' ),
        'param_name' => 'description_length',
        'value'      => '',
        'description'=> esc_html__( 'Set length for description', 'pix-core' ),
    ),
	array(
        'type'       => 'textfield',
        'heading'    => esc_html__( 'Quote Length', 'pix-core' ),
        'param_name' => 'quote_length',
        'value'      => '',
        'description'=> esc_html__( 'Set length for quote', 'pix-core' ),
        'dependency' => array(
			'element' => 'style',
			'value'   => array('1')
        ),
    ),
	array(
		'type'        => 'textfield',
		'heading'     => esc_html__( 'Title quote', 'pix-core' ),
		'param_name'  => 'title_quote_text',
		'description' => esc_html__( 'Enter title quote', 'pix-core' ),
		'value'       => esc_html__('INFORMATION', 'pix-core'),
        'dependency' => array(
			'element' => 'style',
			'value'   => array('1')
        ),
	),
    array(
        'type'       => 'textfield',
        'heading'    => esc_html__( 'Limit Posts', 'pix-core' ),
        'param_name' => 'limit_post',
        'value'      => '-1',
        'description'=> esc_html__( 'Add limit posts per page. Set -1 or empty to show all.', 'pix-core' ),
        'dependency' => array(
			'element' => 'style',
			'value'   => array('1')
        ),
    ),
    array(
        'type'       => 'textfield',
        'heading'    => esc_html__( 'Offset Posts', 'pix-core' ),
        'param_name' => 'offset_post',
        'value'      => '0',
        'description'=> esc_html__( 'Enter offset to pass over posts. If you want to start on record 6, using offset 5', 'pix-core' )
    ),
    array(
        'type'       => 'dropdown',
        'heading'    => esc_html__( 'Sort By', 'pix-core' ),
        'param_name' => 'sort_by',
        'value'      => $sort_by,
        'description'=> esc_html__( 'Select order to display list properties.', 'pix-core' ),
    ),
	// Filter
    array(
        'type'       => 'dropdown',
        'heading'    => esc_html__( 'Display by', 'pix-core' ),
        'param_name' => 'method',
        'value'      => $method,
        'std'        => 'cat',
        'description'=> esc_html__( 'Choose Team category or special Team to display.',  'pix-core'  ),
        'group'      => esc_html__('Filter', 'pix-core')
    ),
    array(
        'type'       => 'param_group',
        'heading'    => esc_html__( 'Category', 'pix-core' ),
        'param_name' => 'category_list',
        'callbacks'   => array(
           'after_add' => 'vcChartParamAfterAddCallback'
        ),
        'params'    => array(
            array(
                'type'       => 'dropdown',
                'admin_label'=> true,
                'heading'    => esc_html__( 'Add Category', 'pix-core' ),
                'param_name' => 'category_slug',
                'value'      => $categories,
                'description'=> esc_html__( 'Choose special category to filter', 'pix-core'  )
            ),
        ),
        'value'      => '',
        'dependency' => array(
            'element'   => 'method',
            'value'     => array('cat' )
        ),
        'description'=> esc_html__( 'Default no filter by category.', 'pix-core' ),
        'group'      => esc_html__('Filter', 'pix-core')
    ),
    array(
        'type'       => 'param_group',
        'heading'    => esc_html__( 'Team List', 'pix-core' ),
        'param_name' => 'team_list',
        'callbacks'   => array(
           'after_add' => 'vcChartParamAfterAddCallback'
        ),
        'params'     => array(
            array(
                'type'       => 'dropdown',
                'admin_label'=> true,
                'heading'    => esc_html__( 'Add Team', 'pix-core' ),
                'param_name' => 'team_id',
                'value'      => $team_list,
                'description'=> esc_html__( 'Choose Team to show', 'pix-core'  )
            ),
        ),
        'value'      => '',
        'dependency' => array(
            'element'=> 'method',
            'value'  => array('team')
        ),
        'description'=> esc_html__( 'Default empty.', 'pix-core' ),
        'group'      => esc_html__('Filter', 'pix-core')
    ),
	// Options
	array(
		"type"        => 'dropdown',
		"class"       => "",
		"heading"     => esc_html__( 'Number Of Item', 'pix-core' ),
		"value"		  => $item,
		"param_name"  => 'item',
		"std"		  => '1',
		"description" => esc_html__( 'Choose number item to show. Default is 1 item', 'pix-core' ),
        'dependency' => array(
			'element' => 'style',
			'value'   => array('2')
        ),
		'group'       => esc_html__('Options', 'pix-core'),
	),
	array(
		'type'       => 'dropdown',
		'heading'    => esc_html__( 'Autoplay', 'pix-core' ),
		'param_name' => 'autoplay',
		'value'      => $true_false,
		'std'        => 'true',
		'description'=> esc_html__( 'Choose autoplay mode.', 'pix-core' ),
		'group'      => esc_html__( 'Options', 'pix-core'),
	),
	array(
		'type'       => 'textfield',
		'heading'    => esc_html__( 'Autoplay Time out', 'pix-core' ),
		'param_name' => 'autoplay_time',
		'value'      => '3000',
		'description'=> esc_html__( 'Choose autoplay time out (default 3000ms).', 'pix-core' ),
		'dependency' => array(
			'element'		=> 'autoplay',
			'value'			=> array('true' )
		),
		'group'      => esc_html__( 'Options', 'pix-core'),
	),
	array(
		"type"        => 'dropdown',
		"class"       => "",
		"heading"     => esc_html__( 'Show Dot', 'pix-core' ),
		"value"		  => $true_false,
		"param_name"  => 'show_dot',
		"std"		  => 'true',
		"description" => esc_html__( 'Show dot. Default is Yes', 'pix-core' ),
		'group'       => esc_html__('Options', 'pix-core'),
	),
	array(
		"type"        => 'dropdown',
		"class"       => "",
		"heading"     => esc_html__( 'Show Navigation', 'pix-core' ),
		"value"		  => $true_false,
		"param_name"  => 'show_nav',
		"std"		  => 'true',
		"description" => esc_html__( 'Show navigation. Default is Yes', 'pix-core' ),
        'dependency' => array(
			'element' => 'style',
			'value'   => array('2')
        ),
		'group'       => esc_html__('Options', 'pix-core'),
	),
	// Custom color
	array(
		"type"        => "colorpicker",
		"class"       => "",
		"heading"     => esc_html__( "Title Color", 'pix-core' ),
		"param_name"  => "title_color",
		"description" => esc_html__( "Choose title color.", 'pix-core' ),
		'group'       => esc_html__('Custom Color', 'pix-core'),
	),
	array(
		"type"        => "colorpicker",
		"class"       => "",
		"heading"     => esc_html__( "Description Color", 'pix-core' ),
		"param_name"  => "description_color",
		"description" => esc_html__( "Choose description color.", 'pix-core' ),
		'group'       => esc_html__('Custom Color', 'pix-core'),
	),
	array(
		"type"        => "colorpicker",
		"class"       => "",
		"heading"     => esc_html__( "Position Color", 'pix-core' ),
		"param_name"  => "position_color",
		"description" => esc_html__( "Choose position color.", 'pix-core' ),
		'group'       => esc_html__('Custom Color', 'pix-core'),
	),
	array(
		"type"        => "colorpicker",
		"class"       => "",
		"heading"     => esc_html__( "Icon Color", 'pix-core' ),
		"param_name"  => "icon_color",
		"description" => esc_html__( "Choose icon color.", 'pix-core' ),
		'group'       => esc_html__('Custom Color', 'pix-core'),
	),
	array(
		"type"        => "colorpicker",
		"class"       => "",
		"heading"     => esc_html__( "Icon Background Color", 'pix-core' ),
		"param_name"  => "icon_bg_color",
		"description" => esc_html__( "Choose icon Background color.", 'pix-core' ),
		'group'       => esc_html__('Custom Color', 'pix-core'),
	),
	array(
		"type"        => "colorpicker",
		"class"       => "",
		"heading"     => esc_html__( "Side Color", 'pix-core' ),
		"param_name"  => "side_color",
		"description" => esc_html__( "Choose side color.", 'pix-core' ),
		'group'       => esc_html__('Custom Color', 'pix-core'),
	),
	array(
		"type"        => "colorpicker",
		"class"       => "",
		"heading"     => esc_html__( "Dot Color", 'pix-core' ),
		"param_name"  => "dot_color",
		"description" => esc_html__( "Choose dot color.", 'pix-core' ),
		'group'       => esc_html__('Custom Color', 'pix-core'),
		'dependency' => array(
			'element'		=> 'show_dot',
			'value'			=> array('true' )
		),
	),
	array(
		"type"        => "colorpicker",
		"class"       => "",
		"heading"     => esc_html__( "Dot Hover Color", 'pix-core' ),
		"param_name"  => "dot_hover_color",
		"description" => esc_html__( "Choose dot hover color.", 'pix-core' ),
		'group'       => esc_html__('Custom Color', 'pix-core'),
		'dependency' => array(
			'element'		=> 'show_dot',
			'value'			=> array('true' )
		),
	),
	array(
		"type"        => "colorpicker",
		"class"       => "",
		"heading"     => esc_html__( "Title quote Color", 'pix-core' ),
		"param_name"  => "title_quote_color",
		"description" => esc_html__( "Choose title quote color.", 'pix-core' ),
		'group'       => esc_html__('Custom Color', 'pix-core'),
        'dependency' => array(
			'element' => 'style',
			'value'   => array('1')
        ),
	),
	array(
		"type"        => "colorpicker",
		"class"       => "",
		"heading"     => esc_html__( "Quote Color", 'pix-core' ),
		"param_name"  => "quote_color",
		"description" => esc_html__( "Choose quote color.", 'pix-core' ),
		'group'       => esc_html__('Custom Color', 'pix-core'),
        'dependency' => array(
			'element' => 'style',
			'value'   => array('1')
        ),
	),
	array(
		'type'            => 'textfield',
		'heading'         => esc_html__( 'Extra Class', 'pix-core' ),
		'param_name'      => 'extra_class',
		'description'     => esc_html__( 'Style particular content element differently - add a class name and refer to it in custom CSS.', 'pix-core' )
	),
	$sc_controller->cosmos_animation_style(),
	$sc_controller->cosmos_animation_delay(),
);

vc_map(
	array(
		'name'          => esc_html__( 'PIX Team Carousel', 'pix-core' ),
		"base"			=> "pixcore_team_carousel_sc",
		"class"			=> "pixcore-sc",
		"category"		=> COSMOS_CORE_SC_CATEGORY,
		'icon'			=> 'icon-pixcore_team_carousel_sc',
		'description'=> esc_html__( 'A list of team slider.', 'pix-core' ),
		"params"		=> $params
	)
);