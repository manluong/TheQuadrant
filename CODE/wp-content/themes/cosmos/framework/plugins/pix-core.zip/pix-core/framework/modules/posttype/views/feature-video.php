<?php
	$meta_key = COSMOS_CORE_THEME_PREFIX . '_feature_video';
	$video_type  =  Cosmos_Core_Params::get( 'video-type');
	$class_cate = $this->get_field( $post_meta, 'video_type' );
	$class_upload ="";
	$class_vimeo_id = "";
	$class_youtube_id = "";
	if ( $class_cate == 'video-upload' ){
		$class_upload = "active";
	}else if( $class_cate == 'vimeo' ) {
		$class_vimeo_id = "active";
	}
	else if( $class_cate == 'youtube' ) {
		$class_youtube_id = "active";
	}
	?>
	<div class="pix-custom-meta container-video-option" >
		<div class="pix-video-meta" >
			<div class="pix-meta-row active" >
				<div class="general-desc">
					<span><?php esc_html_e( 'Please, choose "Video Format" to use "Featured Video". It will be embedded in the post and Featured Image will use to thumb of this post.', 'pix-core' );?></span>
				</div>
			</div>
			<div class="pix-meta-row active" >
				<div class="pix-desc">
					<span><?php esc_html_e( 'Video Thumbnail', 'pix-core' );?></span>
				</div>
				<div class="pix-field">
					<?php echo ( $this->check_box( $meta_key .'[generate_thumnail]',
															$this->get_field( $post_meta, 'generate_thumnail'),
														array( 'class'=>'') ) );
							esc_html_e( 'Create thumbnail from video and using it as featured image? (Only for youtube and vimeo).', 'pix-core' );?>
				</div>
			</div>
			<div class="pix-meta-row active" >
				<div class="pix-desc">
					<span><?php esc_html_e( 'Type', 'pix-core' );?></span>
				</div>
				<div class="pix-field">
					<?php echo ( $this->drop_down_list( $meta_key .'[video_type]',
															$this->get_field( $post_meta, 'video_type' ),
															$video_type,
															array('id'=>'pixcore_mbox_video_type') ) );?>
				</div>
			</div>
			<div class="pix-meta-row video_upload <?php echo esc_attr( $class_upload ); ?>" >
				<?php
					$this->upload_video( $meta_key .'[upload_video]',$this->get_field($post_meta,'upload_video'), esc_html__('MP4 Upload', 'pix-core' ), esc_html__('Choose file .mp4 to upload', 'pix-core' ));?>
			</div>
			<div class="pix-meta-row vimeo-id <?php echo esc_attr( $class_vimeo_id ); ?> " >
				<div class="pix-desc">
					<label><?php esc_html_e( 'Vimeo ID', 'pix-core' );?></label>
				</div>
				<div class="pix-field">
					<?php echo ( $this->text_field( $meta_key .'[vimeo_id]',
															$this->get_field( $post_meta, 'vimeo_id' ),
															array() ) );?>
					<p class="description"><?php echo esc_html__('Example the Video ID for ', 'pix-core') . 'http://vimeo.com/86323053 is 86323053';?></p>
				</div>
			</div>
			<div class="pix-meta-row youtube-id <?php echo esc_attr( $class_youtube_id ); ?> " >
				<div class="pix-desc">
					<label><?php esc_html_e( 'Youtube ID', 'pix-core' );?></label>
				</div>
				<div class="pix-field">
					<?php echo ( $this->text_field( $meta_key .'[youtube_id]',
															$this->get_field( $post_meta, 'youtube_id' ),
															array() ) );?>
					<p class="description"><?php echo esc_html__('Example the Video ID for ', 'pix-core') . 'http://www.youtube.com/v/8OBfr46Y0cQ is 8OBfr46Y0cQ';?></p>
				</div>
			</div>
		</div>
	</div>