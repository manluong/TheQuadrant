<?php
/**
 * Setting_Init class.
 * 
 * @since 1.0
 */

class Cosmos_Core_Setting_Init {
	/**
	 * Regist scripts - admin
	 * 
	 */
	public function enqueue(){
		$uri = COSMOS_CORE_ASSET_URI;
		$protocol = is_ssl() ? 'https' : 'http';
		// css
		wp_enqueue_style( 'cosmos-core-admin',        $uri . '/css/cosmos-core-admin.css', false, COSMOS_CORE_VERSION, 'all' );
		wp_enqueue_style( 'cosmos-core-importer',     $uri . '/css/cosmos-core-importer.css', false, COSMOS_CORE_VERSION, 'all' );
		// js
		wp_enqueue_media();

		//-----------------enqueue script to run ajax-------------------------- 
		wp_enqueue_script( 'cosmos-core-form', $uri . '/js/cosmos-core-form.js', array('jquery'), COSMOS_CORE_VERSION, true );
		wp_localize_script(
				'cosmos-core-form',
				'ajaxurl',
				esc_url(admin_url( 'admin-ajax.php' ))
		);
		
		wp_enqueue_script( 'jquery.datetimepicker.min', $uri . '/libs/datetimepicker/jquery.datetimepicker.min.js', array(), COSMOS_CORE_VERSION, true );

		wp_enqueue_script( 'cosmos-core-common',       $uri . '/js/cosmos-core-common.js', array('jquery'), COSMOS_CORE_VERSION, false );
		wp_enqueue_script( 'cosmos-core-admin',        $uri . '/js/cosmos-core-admin.js', array('jquery'), COSMOS_CORE_VERSION, false );
		wp_enqueue_script( 'cosmos-core-importer',     $uri . '/js/cosmos-core-importer.js', array('jquery'), COSMOS_CORE_VERSION, false );

		wp_enqueue_script( 'cosmos-core-metabox',      $uri . '/js/cosmos-core-metabox.js', array('jquery'), COSMOS_CORE_VERSION, false );		
		wp_enqueue_script( 'cosmos-core-datepicker',   $uri . '/js/cosmos-core-datetimepicker.js', array('jquery'), COSMOS_CORE_VERSION, false );
		wp_enqueue_script( 'cosmos-core-image',        $uri . '/js/cosmos-core-image.js', array('jquery'), COSMOS_CORE_VERSION, false );
		
		wp_localize_script( 'cosmos-core-image', 'pix_meta_image',
				array(
					'title' => esc_html__( 'Choose or Upload an Image', 'pix-core' ),
					'button' => esc_html__( 'Use this image', 'pix-core' ),
				)
		);
		wp_enqueue_style( 'wp-color-picker' );
		wp_enqueue_script( 'cosmos-core-metacolor', $uri . '/js/cosmos-core-metacolor.js', array( 'wp-color-picker' ) );
		
		wp_enqueue_script( 'jquery.tooltipster.min', $uri . '/libs/tooltipster/jquery.tooltipster.min.js', array(), COSMOS_CORE_VERSION, true );
		// css for shortcode 
		wp_enqueue_style( 'jquery.datetimepicker',   $uri . '/libs/datetimepicker/jquery.datetimepicker.css', array(), COSMOS_CORE_VERSION );

		// select2
		wp_enqueue_style( 'jquery.select2css', $uri . '/libs/select2/css/select2.min.css', array(), COSMOS_CORE_VERSION );
		wp_enqueue_script( 'jquery.select2js', $uri . '/libs/select2/js/select2.full.min.js', array( 'jquery' ), COSMOS_CORE_VERSION );
		
		
	}

	/**
	 * Scripts & Css - frontend
	 */
	public function dev_enqueue_scripts(){
		$uri = COSMOS_CORE_ASSET_URI;
		$protocol = is_ssl() ? 'https' : 'http';
		
		/*
			css
		*/		
		wp_enqueue_style( 'jquery-jvectormap',        $uri . '/libs/jquery-jvectormap/jquery-jvectormap.css');
		wp_enqueue_style( 'cosmos-core-custom',       $uri . '/css/cosmos-core-custom.css', false, COSMOS_CORE_VERSION, 'all' );
		
		/*
			js
		*/
		wp_enqueue_script( 'jquery.appear',                $uri . '/libs/jquery.appear.js', array(), false, true );
		wp_enqueue_script( 'wow.min',                      $uri . '/libs/wow-js/wow.min.js', array(), false, true );
		wp_enqueue_script( 'jquery.countTo',               $uri . '/libs/jquery.countTo.js', array(), false, true );
		wp_enqueue_script( 'jquery-jvectormap.min',        $uri . '/libs/jquery-jvectormap/jquery-jvectormap.min.js', array(), false, true );
		wp_enqueue_script( 'jquery-jvectormap-us-aea',     $uri . '/libs/jquery-jvectormap/jquery-jvectormap-us-aea.js', array(), false, true );
		wp_enqueue_script( 'jquery.directional-hover.min', $uri . '/libs/directional-hover/jquery.directional-hover.min.js', array(), false, true );
		wp_enqueue_script( 'js.cookie',                    $uri . '/libs/js-cookie/js.cookie.js', array(), false, true );
		
		wp_enqueue_script( 'moment.min',                   $uri . '/libs/moment-js/moment.min.js', array(), false, true );
		wp_enqueue_script( 'moment-timezone-with-data',    $uri . '/libs/moment-js/moment-timezone-with-data.js', array(), false, true );
		wp_enqueue_script( 'jquery.tablesorter.min',       $uri . '/libs/tablesorter-master/js/jquery.tablesorter.min.js', array(), false, true );
		$keyMapAPI = '';
		$keyMapAPIOption = Cosmos_Core::get_theme_option('pix-map-key-api');
		if ( !empty($keyMapAPIOption) ) {
			$keyMapAPI = 'key='.trim($keyMapAPIOption).'&';
		}
		wp_enqueue_script( 'googleapis', $protocol . '://maps.googleapis.com/maps/api/js?'.$keyMapAPI.'&libraries=places', array(), false, true );
		
		//-----------------enqueue script to run ajax-------------------------- 
		wp_enqueue_script( 'cosmos-core-form', $uri . '/js/cosmos-core-form.js', array('jquery'), COSMOS_CORE_VERSION, true );
		wp_localize_script(
				'cosmos-core-form',
				'ajaxurl',
				esc_url( admin_url( 'admin-ajax.php' ) )
		);
		wp_enqueue_script( 'cosmos-core-countdown',   $uri . '/js/cosmos-core-countdown.js', array('jquery'), COSMOS_CORE_VERSION, true );
		wp_enqueue_script( 'cosmos-core-shortcode',   $uri . '/js/cosmos-core-shortcode.js', array('jquery'), COSMOS_CORE_VERSION, true );
		wp_enqueue_script( 'cosmos-core-map',         $uri . '/js/cosmos-core-map.js', array('jquery'), COSMOS_CORE_VERSION, true );
	}
	/**
	 * action using generate inline css
	 * @param string $custom_css
	 */
	public function add_inline_style( $custom_css ) {
		wp_enqueue_style('cosmos-core-custom', COSMOS_CORE_ASSET_URI . '/css/cosmos-core-custom.css', array(), COSMOS_CORE_VERSION);
		wp_add_inline_style( 'cosmos-core-custom', $custom_css );
	}
	//********************* Post << *********************
	/**
	 * Add columns to post type list screen.
	 *
	 * @param array $columns Existing columns.
	 * @return array Amended columns.
	 */
	public function add_cosmos_team_columns( $columns ) {
		$defaults = array(
			'cb'                 => '',
			'pixcore-thumbs'     => esc_html__( 'Thumbnail', 'pix-core' ),
			'title'              => '',
			'pixcore-category'   => esc_html__( 'Categories', 'pix-core' ),
			'date'               => '',
		);
		$columns = array_merge( $defaults, $columns );
		return $columns;
	}
	public function add_custom_columns( $columns ) {
		global $post;

		$defaults = array(
			'cb'               => '',
			'pixcore-thumbs'   => esc_html__( 'Thumbnail', 'pix-core' ),
			'title'            => '',
			'pixcore-category' => esc_html__( 'Categories', 'pix-core' ),
			'date'             => '',
		);
		$columns = array_merge( $defaults, $columns );
		return $columns;
	}
	
	/**
	 * Custom column callback
	 *
	 * @param string $column Column ID.
	 */
	public function display_custom_columns( $column ){
		global $post;
		if ( ! $post ) return '';
		$post_id = $post->ID;
		$post_type = get_post_type();
		$method_name = $post_type . '_columns';
		if ( method_exists( $this, $method_name ) ) {
			$this->$method_name( $column, $post_id, $post_type );
		}
		switch ( $column ) {
			case 'pixcore-thumbs':
				$opts = array(
					'post_id'    => $post_id,
					'size'       => array( 100, 100 ),
					'post_title' => $post->post_title,
				);
				echo Cosmos_Core_Util::get_thumb_image( $opts );
				break;
			case 'pixcore-category':
				$taxonomy_cat = $post_type . '_cat';
				$term = $this->get_taxonomy_column( $taxonomy_cat, $post_id, $post_type );
				echo wp_kses_post($term);
				break;
			case 'pixcore-icons':
				$val = get_post_meta( $post_id, $post_type . '_icon', true);
				if( $val ) {
					echo '<div class="glyph"><span class="pix-icon  '.esc_attr($val).'"></span><span class="mls">'.esc_attr($val).'</span></div>';
				}
				break;
		}
	}
	private function get_taxonomy_column( $taxonomy, $post_id, $post_type ) {
		$term = '';
		if( taxonomy_exists( $taxonomy ) ) {
			// add separator for two or more terms
			$separtor = ', ';
			// get lists of term associated in the current post type
			$terms = get_the_terms( $post_id, $taxonomy );
			$links = array();
			if( $terms ) {
				foreach ( $terms as $term ) {
					// get link
					$term_link = esc_url(home_url('/')).'/wp-admin/edit.php?post_type='.$post_type.'&'.$taxonomy.'='.$term->slug;
					// the function explain its purpose
					if( is_wp_error( $term_link ) )
						continue;
					$links[] = '<a href="'.$term_link.'">'.$term->name.'</a>';
				}
			}
			$term = implode( $separtor, $links );
		}
		return $term;
	}
	/**
	 * Add columns to post type list
	 */
	public function manage_custom_columns(){
		$post_types = Cosmos_Core_Config::get( 'post_type', 'custom_column' );
		if( $post_types ) {
			foreach( $post_types as $pt ) {
				$method_name = 'add_'.$pt.'_columns';
				if( method_exists( $this, $method_name)) {
					add_filter( 'manage_edit-'. $pt .'_columns', array( 'Cosmos_Core', '[setting.Setting_Init, add_'. $pt .'_columns]' ) );
				} else {
					add_filter( 'manage_edit-'. $pt .'_columns', array( 'Cosmos_Core', '[setting.Setting_Init, add_custom_columns]' ) );
				}
				add_action( 'manage_'. $pt .'_posts_custom_column', array( 'Cosmos_Core', '[setting.Setting_Init, display_custom_columns]' ) );
			}
		}
	}
	/**
	 * Add meta box feature video to post type
	 */
	public function add_metabox_feature_video() {
		$post_types = Cosmos_Core_Config::get( 'post_type', 'feature_video' );
		if( $post_types ) {
			foreach( $post_types as $post_type ) {
				add_meta_box( 'cosmos_core_mbox_feature_video', esc_html__( 'Featured Video', 'pix-core' ), array( 'Cosmos_Core', '[posttype.Post_Controller, metabox_feature_video]' ), $post_type, 'normal', 'low' );
			}
		}
	}
	/**
	 * Save feature video to post type
	 */
	public function save_feature_video( $post_id ) {
		$metakey = COSMOS_CORE_THEME_PREFIX . '_feature_video';
		if( isset( $_POST[$metakey] ) ) {
			if( !isset($_POST[$metakey]['generate_thumnail']) ) {
				$_POST[$metakey]['generate_thumnail'] = '';
			}
			update_post_meta( $post_id, $metakey, $_POST[$metakey] );
			if( $_POST[$metakey]['generate_thumnail'] ) {
				$model = new Cosmos_Core_Video_Model();
				$model->get_video_thumb( $post_id, $metakey );
			}
		}
	}
	//********************* Post >> *********************
	
	/**
	 * Change permalinks
	 */
	 public function add_permalink_settings(){
		$screen = get_current_screen();
		if ( !$screen ) {
			return;
		}
		if( $screen->id == 'options-permalink' ){
			$this->add_permalink_options();
			$this->save_permalink_options();
		}
	}
	public function add_permalink_options(){
		$custom_link_obj = array(
			'team'             => esc_html__( 'Team base', 'pix-core' ),
			'team_cat'         => esc_html__( 'Team category base', 'pix-core' ),
		);
		foreach( $custom_link_obj as $key => $value ){
			add_settings_field(
				'cosmos_' . $key . '_slug',
				$value,
				array( COSMOS_CORE_CLASS, '[setting.Setting_Init, render_permalink_input]' ),
				'permalink',
				'optional',
				array( 'key' => $key )
			);
		}
	}
	public function save_permalink_options(){
		if ( ! is_admin() ) {
			return;
		}
		if ( isset( $_POST['permalink_structure'] ) ) {
			$permalinks = get_option( 'cosmos_permalinks' );
			if ( ! $permalinks ) {
				$permalinks = array();
			}
			$custom_link = array(
							'team', 'team_cat',
						);
			foreach( $custom_link as $name ){
				if( isset( $_POST['cosmos_'.$name.'_slug'] ) ){
					$permalinks[$name] = untrailingslashit( trim( $_POST['cosmos_'.$name.'_slug'] ) );
				}
			}
			update_option( 'cosmos_permalinks', $permalinks );
		}
	}
	public function render_permalink_input( $data ) {
		$permalinks = get_option( 'cosmos_permalinks' );
		if( isset( $data['key'] ) && !empty( $data['key'] ) ){
			$value = '';
			$key   = $data['key'];
			if( isset( $permalinks[$key] ) && !empty( $permalinks[$key] ) ){
				$value = $permalinks[$key];
			}
			$placeholder = array(
				'team'             => esc_html__( 'team', 'pix-core' ),
				'team_cat'         => esc_html__( 'team-category', 'pix-core' ),
			);
			printf('<input name="cosmos_%1$s_slug" type="text" class="regular-text code" value="%2$s" placeholder="%3$s" />',
					esc_attr( $key ),
					esc_attr( $value ),
					esc_attr( $placeholder[$key] )
				);
		}
	}
}