<?php
/**
* Core Loader class.
*
* @author Swlabs
* @since 1.0
*/
if( ! class_exists( 'Cosmos_Core_Loader' ) ){
	class Cosmos_Core_Loader{
		public static function run(){
		}

		/**
		* Fires after WordPress has finished loading but before any headers are sent.
		*/
		public static function init(){
			// Archive Front
			add_action('cosmos_core_team_list',			array( COSMOS_CORE_CLASS, '[top.Top_Controller, show_team_list]' ) );

			add_action('cosmos_core_social_share',        array( COSMOS_CORE_CLASS, '[top.Top_Controller, get_share_link]' ) );

			add_action('wp_ajax_cosmos_core',			array( COSMOS_CORE_CLASS, '[Application, ajax]' ) );
			add_action('wp_ajax_nopriv_cosmos_core',		array( COSMOS_CORE_CLASS, '[Application, ajax]' ) );
			self::register_post_taxonomy();
		}
		public static function register_post_taxonomy(){
			// get custom permalinks
			$permalinks   = get_option( 'cosmos_permalinks' );
			$default_slug = array(
				'team'             => 'team',
				'team_cat'         => 'team-category',
			);
			$custom_slug    = Cosmos_Core_Util::merge_array( $default_slug, $permalinks );

			// get custom breadcrumb
			$default_labels = array(
				'team'             => esc_html__( 'Teams', 'pix-core' ),
				'team_cat'         => esc_html__( 'Team Categories', 'pix-core' ),
			);
			$breadcrumb_labels = array(
				'team'             => Cosmos_Core::get_theme_option('pix-breadcrumb-labels-team'),
				'team_cat'         => Cosmos_Core::get_theme_option('pix-breadcrumb-labels-team-cat'),
			);
			$singular_labels = Cosmos_Core_Util::merge_array( $default_labels, $breadcrumb_labels);

			/*******************************************************************/
			// Portfolio post type
			/*******************************************************************/
			register_post_type( 'cosmos_portfolio', array(
					'public'                => true,
					'has_archive'           => false,
					'rewrite'               => array( 'slug' => 'portfolio' ),
					'query_var'             => true,
					'menu_icon'             => 'dashicons-images-alt2',
					'supports'              => array( 'title', 'editor', 'thumbnail' ),
					'labels'                => array(
						'name'                  => esc_html__( 'Portfolio',           'pix-core' ),
						'singular_name'         => esc_html__( 'Portfolio',           'pix-core' ),
						'menu_name'             => esc_html__( 'Portfolio',           'pix-core' ),
						'add_new'               => esc_html__( 'Add New',             'pix-core' ),
						'add_new_item'          => esc_html__( 'Add New Portfolio',   'pix-core' ),
						'edit_item'             => esc_html__( 'Edit Portfolio',      'pix-core' ),
					),
				));
			register_taxonomy( 'cosmos_portfolio_cat', array( 'cosmos_portfolio' ), array(
					'hierarchical'       => true,
					'rewrite'            => array( 'slug' => 'portfolio-category' ),
					'query_var'          => true,
					'labels'             => array(
						'name'                  => esc_html__( 'Portfolio Categories',    'pix-core' ),
						'singular_name'         => esc_html__( 'Portfolio Categories',    'pix-core' ),
						'menu_name'             => esc_html__( 'Portfolio Categories',    'pix-core' ),
						'add_new'               => esc_html__( 'Add New',                 'pix-core' ),
						'add_new_item'          => esc_html__( 'Add New Category',        'pix-core' ),
						'edit_item'             => esc_html__( 'Edit Category',           'pix-core' ),
						'parent_item'           => esc_html__( 'Parent Category',         'pix-core' ),
						'search_items'          => esc_html__( 'Search Categories',       'pix-core' ),
					),
				));

			/*******************************************************************/
			// Team post type
			/*******************************************************************/
			register_post_type( 'cosmos_team', array(
					'public'                => true,
					'has_archive'           => true,
					'rewrite'               => array( 'slug' => $custom_slug['team'] ),
					'query_var'             => true,
					'menu_icon'             => 'dashicons-networking',
					'supports'              => array( 'title', 'editor', 'thumbnail' ),
					'labels'                => array(
						'name'                  => esc_html__( 'Teams',           'pix-core' ),
						'singular_name'         => $singular_labels['team'],
						'menu_name'             => esc_html__( 'Teams',           'pix-core' ),
						'add_new'               => esc_html__( 'Add New',         'pix-core' ),
						'add_new_item'          => esc_html__( 'Add New Team',    'pix-core' ),
						'edit_item'             => esc_html__( 'Edit Team',       'pix-core' ),
					),
				));
			register_taxonomy( 'cosmos_team_cat', array( 'cosmos_team' ), array(
					'hierarchical'       => true,
					'rewrite'            => array( 'slug' => $custom_slug['team_cat'] ),
					'query_var'          => true,
					'labels'             => array(
						'name'                  => esc_html__( 'Team Categories',         'pix-core' ),
						'singular_name'         => $singular_labels['team_cat'],
						'menu_name'             => esc_html__( 'Team Categories',         'pix-core' ),
						'add_new'               => esc_html__( 'Add New',                 'pix-core' ),
						'add_new_item'          => esc_html__( 'Add New Category',        'pix-core' ),
						'edit_item'             => esc_html__( 'Edit Category',           'pix-core' ),
						'parent_item'           => esc_html__( 'Parent Category',         'pix-core' ),
						'search_items'          => esc_html__( 'Search Categories',       'pix-core' ),
					),
				));

			/*******************************************************************/
			// Testimonial post type
			/*******************************************************************/
			register_post_type( 'cosmos_testi', array(
					'public'                => true,
					'has_archive'           => false,
					'rewrite'               => array( 'slug' => 'testimonial' ),
					'query_var'             => true,
					'menu_icon'             => 'dashicons-editor-quote',
					'supports'              => array( 'title', 'editor', 'thumbnail'),
					'labels'                => array(
						'name'                  => esc_html__( 'Testimonials',           'pix-core' ),
						'singular_name'         => esc_html__( 'Testimonials',           'pix-core' ),
						'menu_name'             => esc_html__( 'Testimonials',           'pix-core' ),
						'add_new'               => esc_html__( 'Add New',                'pix-core' ),
						'add_new_item'          => esc_html__( 'Add New Testimonial',    'pix-core' ),
						'edit_item'             => esc_html__( 'Edit Testimonial',       'pix-core' ),
					),
				));
			register_taxonomy( 'cosmos_testi_cat', array( 'cosmos_testi' ), array(
					'hierarchical'       => true,
					'rewrite'            => array( 'slug' => 'testimonial-category' ),
					'query_var'          => true,
					'labels'             => array(
						'name'                  => esc_html__( 'Testimonial Categories',  'pix-core' ),
						'singular_name'         => esc_html__( 'Testimonial Categories',  'pix-core' ),
						'menu_name'             => esc_html__( 'Testimonial Categories',  'pix-core' ),
						'add_new'               => esc_html__( 'Add New',                 'pix-core' ),
						'add_new_item'          => esc_html__( 'Add New Category',        'pix-core' ),
						'edit_item'             => esc_html__( 'Edit Category',           'pix-core' ),
						'parent_item'           => esc_html__( 'Parent Category',         'pix-core' ),
						'search_items'          => esc_html__( 'Search Categories',       'pix-core' ),
					),
				));

			/*******************************************************************/
			// FAQs post type
			/*******************************************************************/
			register_post_type( 'cosmos_faq', array(
					'public'                => true,
					'has_archive'           => false,
					'rewrite'               => array( 'slug' => 'faqs' ),
					'query_var'             => true,
					'menu_icon'             => 'dashicons-editor-help',
					'supports'              => array( 'title', 'editor' ),
					'labels'                => array(
						'name'                  => esc_html__( 'FAQs',			'pix-core' ),
						'singular_name'         => esc_html__( 'FAQs',          'pix-core' ),
						'menu_name'             => esc_html__( 'FAQs',          'pix-core' ),
						'add_new'               => esc_html__( 'Add New',       'pix-core' ),
						'add_new_item'          => esc_html__( 'Add New FAQ',	'pix-core' ),
						'edit_item'             => esc_html__( 'Edit FAQ',      'pix-core' ),
					),
				));
			register_taxonomy( 'cosmos_faq_cat', array( 'cosmos_faq' ), array(
					'hierarchical'       => true,
					'rewrite'            => array( 'slug' => 'faqs-category' ),
					'query_var'          => true,
					'labels'             => array(
						'name'                  => esc_html__( 'FAQs Categories',		'pix-core' ),
						'singular_name'         => esc_html__( 'FAQs Categories',       'pix-core' ),
						'menu_name'             => esc_html__( 'FAQs Categories',       'pix-core' ),
						'add_new'               => esc_html__( 'Add New',                 'pix-core' ),
						'add_new_item'          => esc_html__( 'Add New Category',        'pix-core' ),
						'edit_item'             => esc_html__( 'Edit Category',           'pix-core' ),
						'parent_item'           => esc_html__( 'Parent Category',         'pix-core' ),
						'search_items'          => esc_html__( 'Search Categories',       'pix-core' ),
					),
				));

			/*******************************************************************/
			// Price post type
			/*******************************************************************/
			register_post_type( 'cosmos_price', array(
					'public'                => true,
					'has_archive'           => false,
					'rewrite'               => array( 'slug' => 'price' ),
					'query_var'             => true,
					'menu_icon'             => 'dashicons-tickets-alt',
					'supports'              => array( 'title', 'editor', 'thumbnail' ),
					'labels'                => array(
						'name'                  => esc_html__( 'Price',           	'pix-core' ),
						'singular_name'         => esc_html__( 'Price',           	'pix-core' ),
						'menu_name'             => esc_html__( 'Price',           	'pix-core' ),
						'add_new'               => esc_html__( 'Add New',       	'pix-core' ),
						'add_new_item'          => esc_html__( 'Add New Price',		'pix-core' ),
						'edit_item'             => esc_html__( 'Edit Price',      	'pix-core' ),
					),
				));
			register_taxonomy( 'cosmos_price_cat', array( 'cosmos_price' ), array(
					'hierarchical'       => true,
					'rewrite'            => array( 'slug' => 'price-category' ),
					'query_var'          => true,
					'labels'             => array(
						'name'                  => esc_html__( 'Price Categories',      'pix-core' ),
						'singular_name'         => esc_html__( 'Price Categories',      'pix-core' ),
						'menu_name'             => esc_html__( 'Price Categories',		'pix-core' ),
						'add_new'               => esc_html__( 'Add New',               'pix-core' ),
						'add_new_item'          => esc_html__( 'Add New Category',			'pix-core' ),
						'edit_item'             => esc_html__( 'Edit Category',           	'pix-core' ),
						'parent_item'           => esc_html__( 'Parent Category',         	'pix-core' ),
						'search_items'          => esc_html__( 'Search Categories',       	'pix-core' ),
					),
				));
			
			/*******************************************************************/
			// Timeline post type
			/*******************************************************************/
			register_post_type( 'cosmos_timeline', array(
					'public'                => true,
					'has_archive'           => false,
					'rewrite'               => array( 'slug' => 'timeline' ),
					'query_var'             => true,
					'menu_icon'             => 'dashicons-backup',
					'supports'              => array( 'title', 'editor', 'thumbnail', 'post-formats' ),
					'labels'                => array(
						'name'                  => esc_html__( 'Timeline',                'pix-core' ),
						'singular_name'         => esc_html__( 'Timeline',                'pix-core' ),
						'menu_name'             => esc_html__( 'Timeline',                'pix-core' ),
						'add_new'               => esc_html__( 'Add New',                 'pix-core' ),
						'add_new_item'          => esc_html__( 'Add New Timeline',        'pix-core' ),
						'edit_item'             => esc_html__( 'Edit Timeline',           'pix-core' ),
					),
				));
			register_taxonomy( 'cosmos_timeline_cat', array( 'cosmos_timeline' ), array(
					'hierarchical'       => true,
					'rewrite'            => array( 'slug' => 'timeline-category' ),
					'query_var'          => true,
					'labels'             => array(
						'name'                  => esc_html__( 'Timeline Categories',     'pix-core' ),
						'singular_name'         => esc_html__( 'Timeline Categories',     'pix-core' ),
						'menu_name'             => esc_html__( 'Timeline Categories',     'pix-core' ),
						'add_new'               => esc_html__( 'Add New',                 'pix-core' ),
						'add_new_item'          => esc_html__( 'Add New Category',        'pix-core' ),
						'edit_item'             => esc_html__( 'Edit Category',           'pix-core' ),
						'parent_item'           => esc_html__( 'Parent Category',         'pix-core' ),
						'search_items'          => esc_html__( 'Search Categories',       'pix-core' ),
					),
				));
		}
		/**
		* It is triggered before any other hook when a user accesses the admin area.
		*/
		public static function admin(){
			// add action
			add_action( 'save_post', array( COSMOS_CORE_CLASS, '[Application, save]' ) );
			add_action( 'admin_enqueue_scripts', array( COSMOS_CORE_CLASS, '[setting.Setting_Init, enqueue]' ) );

			add_action( 'cosmos_core_custom_colums', array( COSMOS_CORE_CLASS, '[setting.Setting_Init, manage_custom_columns]' ) );
			add_action( 'cosmos_core_add_feature_video', array( COSMOS_CORE_CLASS, '[setting.Setting_Init, add_metabox_feature_video]' ) );
			// save feature video
			add_action( 'cosmos_core_save_feature_video', array( COSMOS_CORE_CLASS, '[setting.Setting_Init, save_feature_video]' ) );
			// change permalinks
			add_action( 'current_screen', array( COSMOS_CORE_CLASS, '[setting.Setting_Init, add_permalink_settings]' ) );

			do_action( 'cosmos_core_add_feature_video');
			do_action( 'cosmos_core_custom_colums');

			// Gallery - metaboxs
			add_meta_box( 'cosmos_core_mbox_post', esc_html__( 'Galleries', 'pix-core' ), array( COSMOS_CORE_CLASS, '[posttype.Post_Controller, metabox_galleries_options]' ), 'post', 'normal' );
			// Team - metaboxs
			add_meta_box( 'cosmos_core_mbox_team', esc_html__( 'Team Options', 'pix-core' ), array( COSMOS_CORE_CLASS, '[posttype.Team_Controller, metabox_team_options]' ), 'cosmos_team', 'normal' );
			//Testimonial - metaboxs
			add_meta_box( 'cosmos_core_mbox_testimonial', esc_html__( 'Testimonial Options', 'pix-core' ), array( COSMOS_CORE_CLASS, '[posttype.Testimonial_Controller, metabox_testimonial_options]' ), 'cosmos_testi', 'normal' );
			//Portfolio - metaboxs
			add_meta_box( 'cosmos_core_mbox_portfolio', esc_html__( 'Portfolio Options', 'pix-core' ), array( COSMOS_CORE_CLASS, '[posttype.Portfolio_Controller, metabox_portfolio_options]' ), 'cosmos_portfolio', 'normal' );
			// Price - metaboxs
			add_meta_box( 'cosmos_core_mbox_price', esc_html__( 'Price Options', 'pix-core' ), array( COSMOS_CORE_CLASS, '[posttype.Price_Controller, metabox_price_options]' ), 'cosmos_price', 'normal' );
			//Timeline - metaboxs
			add_meta_box( 'cosmos_core_mbox_timeline', esc_html__( 'Timeline Options', 'pix-core' ), array( COSMOS_CORE_CLASS, '[posttype.Timeline_Controller, metabox_timeline_options]' ), 'cosmos_timeline', 'normal' );

		}
	}
}