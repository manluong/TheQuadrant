<?php
class Cosmos_Core_Banner extends Cosmos_Core_Custom_Post_Model{
	private $html_format;

	public function __construct(){
		$this->html_format = $this->set_default_options();
	}
	public function init(){
		$custom_css = $this->add_custom_css();
        if ( $custom_css ) {
            do_action( COSMOS_CORE_ADD_INLINE_CSS, $custom_css );
        }
	}
	public function set_default_options( &$html_options = array() ){
		$defaults = array(
		);
		$html_options = array_merge( $defaults, $html_options );
		return $html_options;
	}
	public function add_custom_css(){
		$sc_id = $this->attributes['uniq_id'];
		$custom_css = '';
		return $custom_css;
	}
	/****************/
	/*  RENDER HTML **********************************************************/
	/****************/
	public function render_banner($html_options = array(), $atts= array()) {
		if($atts['img_primary']){
			
		}
		cosmos_printf( $html_options['html_format'], $args);
	}
}