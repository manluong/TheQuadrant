<?php
$custom_css = "";
$sc_id      = 'icon-box-'. $id;
$block_class= $extra_class . ' ' . $sc_id;
if($style == 1) {
	if( !empty($border_color) ) {
		$custom_css .= '.%1$s .section_feature.style-1 .feature-item1 .icon-item  {border-color:%4$s;}'."\n";
	}
	if( !empty($border_hover_color) ) {
		$custom_css .= '.%1$s .section_feature.style-1 .feature-item1:hover .icon-item {border-color:%5$s;}'."\n";
	}
	if( !empty($title_color) ) {
		$custom_css .= '.%1$s .section_feature.style-1 .feature-item1 .feature-title1 {color:%6$s;}'."\n";
	}
	if( !empty($title_hover_color) ) {
		$custom_css .= '.%1$s .section_feature.style-1 .feature-item1:hover .feature-title1 {color:%7$s;}'."\n";
	}
	if( !empty($description_color) ) {
		$custom_css .= '.%1$s .section_feature.style-1 .feature-item1 .feature-text1 {color:%8$s;}'."\n";
	}
	if( !empty($description_hover_color) ) {
		$custom_css .= '.%1$s .section_feature.style-1 .feature-item1:hover .feature-text1 {color:%9$s;}'."\n";
	}
	if( !empty($icon_color) ) {
		$custom_css .= '.%1$s .section_feature.style-1 .feature-item1 .feature-title1 i {color:%10$s;}'."\n";
	}
	if( !empty($icon_hover_color) ) {
		$custom_css .= '.%1$s .section_feature.style-1 .feature-item1:hover .feature-title1 i {color:%11$s;}'."\n";
	}
	if( !empty($height) ) {
		$custom_css .= '
		@media screen (min-width: 768px) {
			.%1$s .section_feature.style-1 .feature-item1 {min-height:%14$spx;}
		}'."\n";
	}
}
if($style == 2) {
	if( !empty($bg_icon_color) ) {
		$custom_css .= '.%1$s .section_feature.style-2 .feature-item2 .feature-title2 i {background:%2$s;}'."\n";
	}
	if( !empty($bg_hover_color) ) {
		$custom_css .= '.%1$s .section_feature.style-2 .feature-item2:hover .feature-title2 i {background:%3$s;}'."\n";
	}
	if( !empty($border_color) ) {
		$custom_css .= '.%1$s .section_feature.style-2 .feature-item2 .icon-item  {border-color:%4$s;}'."\n";
	}
	if( !empty($border_hover_color) ) {
		$custom_css .= '.%1$s .section_feature.style-2 .feature-item2:hover .icon-item {border-color:%5$s;}'."\n";
	}
	if( !empty($title_color) ) {
		$custom_css .= '.%1$s .section_feature.style-2 .feature-item2 .feature-title2 {color:%6$s;}'."\n";
	}
	if( !empty($title_hover_color) ) {
		$custom_css .= '.%1$s .section_feature.style-2 .feature-item2:hover .feature-title2 {color:%7$s;}'."\n";
	}
	if( !empty($description_color) ) {
		$custom_css .= '.%1$s .section_feature.style-2 .feature-item2 .feature-text2 {color:%8$s;}'."\n";
	}
	if( !empty($description_hover_color) ) {
		$custom_css .= '.%1$s .section_feature.style-2 .feature-item2:hover .feature-text2 {color:%9$s;}'."\n";
	}
	if( !empty($icon_color) ) {
		$custom_css .= '.%1$s .section_feature.style-2 .feature-item2 .feature-title2 i {color:%10$s;}'."\n";
	}
	if( !empty($icon_hover_color) ) {
		$custom_css .= '.%1$s .section_feature.style-2 .feature-item2:hover .feature-title2 i {color:%11$s;}'."\n";
	}
	if( !empty($height) ) {
		$custom_css .= '
		@media screen (min-width: 768px) {
			.%1$s .section_feature.style-2 .feature-item2 {min-height:%14$spx;}
		}'."\n";
	}
}
if($style == 3) {
	if( !empty($bg_icon_color) ) {
		$custom_css .= '.%1$s .section_feature.style-4 .list-feature4 .feature-item2 .feature-icon2 {background:%2$s;}'."\n";
		$custom_css .= '.%1$s .section_feature.style-4 .list-feature4 .feature-item2 .icon-item {border-color:%2$s;}'."\n";
	}
	if( !empty($bg_hover_color) ) {
		$custom_css .= '.%1$s .section_feature.style-4 .list-feature4 .feature-item2:hover .icon-item {background:%3$s; border-color:%3$s}'."\n";
	}
	if( !empty($border_color) ) {
		$custom_css .= '.%1$s .section_feature.style-4 .list-feature4 .feature-item2  {border-color:%4$s;}'."\n";
		$custom_css .= '.%1$s .section_feature.style-4 .list-feature4 .feature-item2 .icon-item  {border-color:%4$s;}'."\n";
	}
	if( !empty($border_hover_color) ) {
		$custom_css .= '.%1$s .section_feature.style-4 .list-feature4 .feature-item2:hover {border-color:%5$s;}'."\n";
	}
	if( !empty($title_color) ) {
		$custom_css .= '.%1$s .section_feature.style-4 .feature-item2 .feature-title2 {color:%6$s;}'."\n";
	}
	if( !empty($title_hover_color) ) {
		$custom_css .= '.%1$s .section_feature.style-4 .feature-item2:hover .feature-title2 {color:%7$s;}'."\n";
	}
	if( !empty($description_color) ) {
		$custom_css .= '.%1$s .section_feature.style-4 .feature-item2 .feature-text2 {color:%8$s;}'."\n";
	}
	if( !empty($description_hover_color) ) {
		$custom_css .= '.%1$s .section_feature.style-4 .feature-item2:hover .feature-text2 {color:%9$s;}'."\n";
	}
	if( !empty($icon_color) ) {
		$custom_css .= '.%1$s .section_feature.style-4 .list-feature4 .feature-item2 .icon-item {color:%10$s;}'."\n";
	}
	if( !empty($icon_hover_color) ) {
		$custom_css .= '.%1$s .section_feature.style-4 .list-feature4 .feature-item2:hover .icon-item {color:%11$s;}'."\n";
	}
	if( !empty($height) ) {
		$custom_css .= '
		@media screen (min-width: 768px) {
			.%1$s .section_feature.style-4 .list-feature4 .feature-item2 {min-height:%14$spx;}
		}'."\n";
	}
}
if($style == 4) {
	if( !empty($title_color) ) {
		$custom_css .= '.%1$s .style-1.contact-infomation .contact__title {color:%6$s;}'."\n";
	}
	if( !empty($description_color) ) {
		$custom_css .= '.%1$s .style-1.contact-infomation .contact__content {color:%8$s;}'."\n";
	}
	if( !empty($icon_color) ) {
		$custom_css .= '.%1$s .style-1.contact-infomation .contact__image i {color:%10$s;}'."\n";
	}
	if( !empty($bg_color) ) {
		$custom_css .= '.%1$s .style-1.contact-infomation {background:%12$s;}'."\n";
	}
	if( !empty($line_color) ) {
		$custom_css .= '.%1$s .style-1.contact-infomation .contact__title {background:%13$s;}'."\n";
	}
	if( !empty($height) ) {
		$custom_css .= '
		@media screen (min-width: 768px) {
			.%1$s .style-1.contact-infomation {min-height:%14$spx;}
		}'."\n";
	}
}
if($style == 5) {
	if( !empty($bg_icon_color) ) {
		$custom_css .= '.%1$s .style-2.contact-infomation .contact__image .fa {background:%2$s;}'."\n";
	}
	if( !empty($title_color) ) {
		$custom_css .= '.%1$s .style-2.contact-infomation .contact__title {color:%6$s;}'."\n";
	}
	if( !empty($description_color) ) {
		$custom_css .= '.%1$s .style-2.contact-infomation .contact__content {color:%8$s;}'."\n";
	}
	if( !empty($icon_color) ) {
		$custom_css .= '.%1$s .style-2.contact-infomation .contact__image .fa {color:%10$s;}'."\n";
	}
	if( !empty($bg_color) ) {
		$custom_css .= '.%1$s .section_contact.style-3 .col-right.bg-img {background:%12$s;}'."\n";
	}
	if( !empty($height) ) {
		$custom_css .= '
		@media screen (min-width: 768px) {
			.%1$s .style-2.contact-infomation {min-height:%14$spx;}
		}'."\n";
	}
}



//display custom css
if ( !empty( $custom_css ) ){
	$custom_css = sprintf($custom_css,
			esc_attr($sc_id),
			esc_attr($bg_icon_color),
			esc_attr($bg_hover_color),
			esc_attr($border_color),
			esc_attr($border_hover_color),
			esc_attr($title_color),
			esc_attr($title_hover_color),
			esc_attr($description_color),
			esc_attr($description_hover_color),
			esc_attr($icon_color),
			esc_attr($icon_hover_color),
			esc_attr($bg_color),
			esc_attr($line_color),
			esc_attr($height)
			);
	do_action( COSMOS_CORE_ADD_INLINE_CSS, $custom_css );
}
?>
<div class="pix-shortcode sc-icon-box style-<?php echo esc_attr($style) ?> <?php  echo esc_attr($block_class) ?> animate-run" data-animate="<?php echo esc_attr($css_animation); ?>" data-delay="<?php echo (int) esc_attr($delay_animation); ?>">
<?php if($style == 1) { ?>
	<div class="group-content row-builder section_feature style-1">
        <div class="animatedParent animateOnce">
            <div class="feature-item1 animated fadeInUpShort">
                <p class="feature-title1">
                <?php if(!empty($icon)) { ?>
                    <span class="feature-icon1">
                        <i class="<?php echo esc_attr($icon) ?> icon-item"></i>
                    </span>
                <?php } if(!empty($title)) { ?>
                   <span><?php echo esc_attr($title) ?></span>
                <?php } ?>
                </p>
                <?php if(!empty($description)) { ?>
                <p class="feature-text1"><?php echo wp_kses_post($description) ?></p>
                <?php } ?>
            </div>
        </div>
	</div>
<?php } if ($style == 2) { ?>
	<div class="group-content row-builder section_feature style-2">
		<div class="row list-feature2 animatedParent animateOnce" data-sequence='200'>
			<div class="feature-item2 animated growIn">
                <p class="feature-title2">
                <?php if(!empty($icon)) { ?>
                    <span class="feature-icon2">
                        <i class="<?php echo esc_attr($icon) ?> icon-item"></i>
                    </span>
                <?php } if(!empty($title)) { ?>
                   	<span><?php echo esc_attr($title) ?></span>
                <?php } ?>
                </p>
                <?php if(!empty($description)) { ?>
                <p class="feature-text2"><?php echo wp_kses_post($description) ?></p>
                <?php } ?>
            </div>
		</div>
	</div>
<?php } if ($style == 3) { ?>
	<div class="group-content row-builder section_feature style-4">
		<div class="row list-feature4">
			<div class="animatedParent animateOnce">
	            <div class="feature-item2 animated fadeInDownShort">
	                <p class="feature-title2">
	                <?php if(!empty($icon)) { ?>
	                    <span class="feature-icon2">
	                        <i class="<?php echo esc_attr($icon) ?> icon-item"></i>
	                    </span>
	                <?php } if(!empty($title)) { ?>
	                    <span><?php echo esc_attr($title) ?></span>
	                <?php } ?>
	                </p>
	                <?php if(!empty($description)) { ?>
	                <p class="feature-text2"><?php echo wp_kses_post($description) ?></p>
	                <?php } ?>
	            </div>
	        </div>
	    </div>
	</div>
<?php } if ($style == 4) { ?>
	<div class="section-contact2">
        <div class="row">
            <div class="contact-infomation style-1">
            	<?php if(!empty($icon)) { ?>
                <div class="contact__image">
                    <i class="<?php echo esc_attr($icon) ?>"></i>
                </div>
                <?php } if(!empty($title)) { ?>
                <div class="contact__title">
                    <span data-type="title"><?php echo esc_attr($title) ?></span>
                </div>
                <?php } if(!empty($description)) { ?>
                <div class="contact__content">
                    <p data-type="content"><?php echo wp_kses_post($description) ?></p>
                </div>
                <?php } ?>
            </div>
        </div>
    </div>
<?php } if ($style == 5) { ?>
	<div class="section_contact style-3">
		<div class="display-table">
	        <div class="col-right display-table-cell vertical-align-middle bg-img" >
	            <div class="contact-infomation style-2">
	                <?php if(!empty($icon)) { ?>
	                <div class="contact__image">
	                    <i class="<?php echo esc_attr($icon) ?>"></i>
	                </div>
	                <?php } if(!empty($title)) { ?>
	                <div class="contact__title">
	                    <span data-type="title"><?php echo esc_attr($title) ?></span>
	                </div>
	                <?php } if(!empty($description)) { ?>
	                <div class="contact__content">
	                    <p data-type="content"><?php echo wp_kses_post($description) ?></p>
	                </div>
	                <?php } ?>
	            </div>
	        </div>
	    </div>
    </div>
<?php } ?>
</div>