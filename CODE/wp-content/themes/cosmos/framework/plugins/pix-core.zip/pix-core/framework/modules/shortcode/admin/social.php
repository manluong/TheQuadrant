<?php
$sc_controller = new Cosmos_Core_Shortcodes_Controller();
$style = array(
	esc_html__('Style 1','pix-core')	=> '1',
	esc_html__('Style 2','pix-core')	=> '2',
	esc_html__('Style 3','pix-core')	=> '3',
);
$align = Cosmos_Core_Params::get('align');
$social = Cosmos_Core_Params::teammbox_social();
$icon ='';
foreach ($social as $key => $value) {
	$icon[$value] = $key;
}
$params = array(
	array(
		'type' 			=> 'dropdown',
		'admin_label'	=> true,
		'heading'	 	=>  esc_html__( 'Style', 'pix-core' ),
		'param_name' 	=> 'style',
		'value'			=> $style,
		'description'	=>	esc_html__( 'Choose style', 'pix-core' ),
	),
	array(
		'type' 			=> 'dropdown',
		'heading'	 	=>  esc_html__( 'Align', 'pix-core' ),
		'param_name' 	=> 'align',
		'value'			=> $align,
		'description'	=>	esc_html__( 'Choose align', 'pix-core' ),
	),
	array(
		'type'       => 'param_group',
		'heading'    => esc_html__( 'Social Content', 'pix-core' ),
		'param_name' => 'social',
		'callbacks'   => array(
		   'after_add' => 'vcChartParamAfterAddCallback'
		),
		'params'     => array(
			array(
				'type'       	=> 'dropdown',
				"class"       	=> "",
				'admin_label' 	=> true,
				'value'			=> $icon,
				'heading'    	=> esc_html__( 'Choose Social', 'pix-core' ),
				'param_name' 	=> 'icon',
				'description'	=> esc_html__( 'Please choose social to show', 'pix-core' ),
			),
			array(
				'type'        => 'vc_link',
				'heading'     => esc_html__( 'Link', 'pix-core' ),
				'param_name'  => 'url',
				'value'       => '',
				'description' => esc_html__( 'Please input to url redirect.', 'pix-core' )
			),
		)
	),
	array(
		"type"        => "colorpicker",
		"class"       => "",
		"heading"     => esc_html__( "Icon Color", 'pix-core' ),
		"param_name"  => "icon_color",
		"description" => esc_html__( "Choose the icon color.", 'pix-core' ),
		'group'       => esc_html__('Options', 'pix-core'),
	),
	array(
		"type"        => "colorpicker",
		"class"       => "",
		"heading"     => esc_html__( "Icon Color Hover", 'pix-core' ),
		"param_name"  => "icon_color_hover",
		"description" => esc_html__( "Choose the icon color when hover.", 'pix-core' ),
		'group'       => esc_html__('Options', 'pix-core'),
	),
	array(
		"type"        => "colorpicker",
		"class"       => "",
		"heading"     => esc_html__( "Border Icon Color", 'pix-core' ),
		"param_name"  => "border_icon_color",
		"description" => esc_html__( "Choose color for border icon.", 'pix-core' ),
		'group'       => esc_html__('Options', 'pix-core'),
		'dependency'    => array(
			'element'=> 'style',
			'value'         => array( '3' )
		),
	),
	array(
		"type"        => "colorpicker",
		"class"       => "",
		"heading"     => esc_html__( "Background Icon Color", 'pix-core' ),
		"param_name"  => "bg_color",
		"description" => esc_html__( "Choose color for background icon.", 'pix-core' ),
		'group'       => esc_html__('Options', 'pix-core'),
		'dependency'    => array(
			'element'=> 'style',
			'value'         => array( '1' )
		),
	),
	array(
		"type"        => "colorpicker",
		"class"       => "",
		"heading"     => esc_html__( "Background Icon Color Hover", 'pix-core' ),
		"param_name"  => "bg_color_hover",
		"description" => esc_html__( "Choose color for background icon when hover.", 'pix-core' ),
		'group'       => esc_html__('Options', 'pix-core'),
		'dependency'    => array(
			'element'=> 'style',
			'value'         => array( '1' )
		),
	),
	array(
		'type'            => 'textfield',
		'heading'         => esc_html__( 'Extra Class', 'pix-core' ),
		'param_name'      => 'extra_class',
		'description'     => esc_html__( 'Style particular content element differently - add a class name and refer to it in custom CSS.', 'pix-core' )
	),
	$sc_controller->cosmos_animation_style(),
	$sc_controller->cosmos_animation_delay(),

);

vc_map(
	array(
		"name"			=> esc_html__( 'PIX Social Box', 'pix-core' ),
		"base"			=> "pixcore_social_sc",
		"class"			=> "pixcore-sc",
		"category"		=> COSMOS_CORE_SC_CATEGORY,
		'icon'			=> 'icon-pixcore_social_sc',
		"description"	=> esc_html__( 'Social Box.', 'pix-core' ),
		"params"		=> $params
	)
);