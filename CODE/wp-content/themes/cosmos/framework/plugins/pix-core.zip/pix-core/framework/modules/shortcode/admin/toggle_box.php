<?php
$sc_controller = new Cosmos_Core_Shortcodes_Controller();
$params = array(
	array(
		"type"        => "textfield",
		"heading"     => esc_html__( "Block Title", 'pix-core' ),
		"param_name"  => "block_title",
		"description" => esc_html__( "Please enter block title.", 'pix-core' ),
	),
	array(
		'type'       => 'param_group',
		'heading'    => esc_html__( 'Toggle Content', 'pix-core' ),
		'param_name' => 'toggle_content',
		'callbacks'   => array(
		   'after_add' => 'vcChartParamAfterAddCallback'
		),
		'params'     => array(
			array(
				"type"        => "textfield",
				"holder"      => "div",
				"class"       => "",
				'admin_label' => true,
				"heading"     => esc_html__( 'Title', 'pix-core' ),
				"param_name"  => "title",
				"description" => esc_html__( 'Enter question of FAQ', 'pix-core' )
			),
			array(
				"type"        => "textarea",
				"holder"      => "div",
				"class"       => "",
				"heading"     => esc_html__( "Content", 'pix-core' ),
				"param_name"  => "content",
				"description" => esc_html__( "Enter answer of FAQ", 'pix-core' )
			)
		)
	),
	array(
		"type"        => "colorpicker",
		"class"       => "",
		"heading"     => esc_html__( "Block Title Color", 'pix-core' ),
		"param_name"  => "block_title_color",
		"description" => esc_html__( "Choose text color for block title.", 'pix-core' ),
		'group'       => esc_html__('Options', 'pix-core'),
	),
	array(
		"type"        => "colorpicker",
		"class"       => "",
		"heading"     => esc_html__( "Block Title Background Color", 'pix-core' ),
		"param_name"  => "block_title_bg",
		"description" => esc_html__( "Choose background color for block title.", 'pix-core' ),
		'group'       => esc_html__('Options', 'pix-core'),
	),
	array(
		"type"        => "colorpicker",
		"class"       => "",
		"heading"     => esc_html__( "Title Question Color", 'pix-core' ),
		"param_name"  => "title_color",
		"description" => esc_html__( "Choose the title question color.", 'pix-core' ),
		'group'       => esc_html__('Options', 'pix-core'),
	),
	array(
		"type"        => "colorpicker",
		"class"       => "",
		"heading"     => esc_html__( "Answer Text Color", 'pix-core' ),
		"param_name"  => "content_color",
		"description" => esc_html__( "Choose the color for text in answer.", 'pix-core' ),
		'group'       => esc_html__('Options', 'pix-core'),
	),
	array(
		"type"        => "colorpicker",
		"class"       => "",
		"heading"     => esc_html__( "Content Background Color", 'pix-core' ),
		"param_name"  => "content_bg_color",
		"description" => esc_html__( "Choose the color for background content.", 'pix-core' ),
		'group'       => esc_html__('Options', 'pix-core'),
	),
	array(
		"type"        => "colorpicker",
		"class"       => "",
		"heading"     => esc_html__( "Active Color", 'pix-core' ),
		"param_name"  => "active_color",
		"description" => esc_html__( "Choose the active color.", 'pix-core' ),
		'group'       => esc_html__('Options', 'pix-core'),
	),
	
	array(
		'type'            => 'textfield',
		'heading'         => esc_html__( 'Extra Class', 'pix-core' ),
		'param_name'      => 'extra_class',
		'description'     => esc_html__( 'Style particular content element differently - add a class name and refer to it in custom CSS.', 'pix-core' )
	),
	$sc_controller->cosmos_animation_style(),
	$sc_controller->cosmos_animation_delay(),
	array(
		'type'        => 'dropdown',
        'heading'     => esc_html__( 'Animation To Children', 'pix-core' ),
        'param_name'  => 'is_parent_animation',
        'value'       => array(
                            esc_html__('Yes', 'pix-core')=> 'yes',
                            esc_html__('No', 'pix-core') => 'no',
                        ),
        'std'         => 'no',
        'description' => esc_html__('Apply run animation to children element'),
        'group'       => esc_html__('Animation', 'pix-core'),
	)  

);

vc_map(
	array(
		"name"			=> esc_html__( 'PIX Toggle Box', 'pix-core' ),
		"base"			=> "pixcore_toggle_box_sc",
		"class"			=> "pixcore-sc",
		"category"		=> COSMOS_CORE_SC_CATEGORY,
		'icon'			=> 'icon-pixcore_toggle_box_sc',
		"description"	=> esc_html__( 'Toggle Box.', 'pix-core' ),
		"params"		=> $params
	)
);
