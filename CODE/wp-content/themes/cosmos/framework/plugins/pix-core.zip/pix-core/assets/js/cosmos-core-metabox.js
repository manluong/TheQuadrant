jQuery(document).ready(function($) {
		"use strict";
		var pixAddSection = $(".pix-add-section-project");
		var pixRemoveSectionRow = $(".pix-row-remove") ;
		var objClone = ".pix-content-attributes .pix-section-clone";
		var objCloneClasses = $(objClone).prop("classList");
		var objCloneHtml = $(objClone).eq(0).html();
		var objCloneTagName = $(objClone).eq(0).prop("tagName");
		$(objClone).eq(0).remove();
		pixAddSection.live("click", function(){
				objCloneTagName = objCloneTagName.toLowerCase();
				$(".pix-content-attributes").append('<'+objCloneTagName+' class="'+objCloneClasses+'">'+objCloneHtml+'</'+objCloneTagName+'>');
				var count = ($(objClone).length)-1;
				$(objClone).eq(count).find('input').each(function(){
					var name = $(this).attr('name').replace('[]', '['+(count)+']');
					$(this).attr('name', name);
					//alert(name);
				})
			});
		pixRemoveSectionRow.live("click", function(){
				$(this).parents(objClone).remove();
				console.log(pixRemoveSectionRow.index(this));
				
			});
		//sort with drag or drop
		$( ".pix-content-attributes" ).sortable({
			//to do code
		});

		$(window).on('load', function(){
			var checkbox = $('.pix-switch input[type="hidden"]').val();
			var data_show = $('.pix-switch').attr('data-show');
			if(checkbox == 1) {
				if($('.show_' + data_show).hasClass('hide')) {
					$('.show_' + data_show).removeClass('hide');
					$('.show_' + data_show).addClass('show');
				} else {
					$('.show_' + data_show).addClass('show');
				}
			} else {
				if($('.show_' + data_show).hasClass('show')) {
					$('.show_' + data_show).removeClass('show');
					$('.show_' + data_show).addClass('hide');
				} else {
					$('.show_' + data_show).addClass('hide');
				}
			}
		});
		
		$('.pix-switch input[type="checkbox"]').change(function(){
			var data_show = $('.pix-switch').attr('data-show');
			if($(this).prop('checked')) {
				$('.pix-switch input[type="hidden"]').val(1);
				if($('.show_' + data_show).hasClass('hide')) {
					$('.show_' + data_show).removeClass('hide');
					$('.show_' + data_show).addClass('show');
				} else {
					$('.show_' + data_show).addClass('show');
				}
			}
			else{
				$('.pix-switch input[type="hidden"]').val(0);
				if($('.show_' + data_show).hasClass('show')) {
					$('.show_' + data_show).removeClass('show');
					$('.show_' + data_show).addClass('hide');
				} else {
					$('.show_' + data_show).addClass('hide');
				}
			}
		});
	});