jQuery(document).ready(function($) {
	"use strict";
	$('.datepicker').datetimepicker({
		timepicker:false,
		format:'Y-m-d'
	});
	$('.timepicker').datetimepicker({
		datepicker:false,
		format:'H:i',
		step:15
	});
	$('.vc_pix_datetimepicker').datetimepicker({
		timepicker:true,
		format:'M d, Y H:i:s'
	});
	$('.vc_pix_datepicker').datetimepicker({
		timepicker:false,
		format:'Y-m-d'
	});
});