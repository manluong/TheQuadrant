<?php
$model      = new Cosmos_Core_Faq();
$model->init( $atts );
$custom_css = "";
$sc_id      = $model->attributes['uniq_id'];
$block_class= $model->attributes['extra_class'] . ' ' . $sc_id;

$css_animation = '';
$css_animation_class = '';
$delay_animation = 0;
$css_animation_parent = '';
$css_animation_parent_class = '';
$delay_animation_parent = 0;

if ( !empty($model->attributes['css_animation']) && !empty($model->attributes['is_parent_animation']) && $model->attributes['is_parent_animation'] != 'yes') {
	$css_animation = $model->attributes['css_animation'];
	$css_animation_class = 'animate-run';
	$delay_animation = (int) $model->attributes['delay_animation'];
}

if ( !empty($model->attributes['css_animation']) && !empty($model->attributes['is_parent_animation']) && $model->attributes['is_parent_animation'] == 'yes') {
	$css_animation_parent = $model->attributes['css_animation'].'-children';
	$css_animation_parent_class = 'animate-run';
	$delay_animation_parent = (int) $model->attributes['delay_animation'];
}

if( !empty($atts['block_title_color']) ) {
	$custom_css .= '.%1$s .section_faq.style-1 p.title {color:%2$s}'."\n";
}
if( !empty($atts['block_title_bg']) ) {
	$custom_css .= '.%1$s .section_faq.style-1 p.title {background:%3$s}'."\n";
}
if( !empty( $atts['active_color'] ) ){
	$custom_css .= '.%1$s .section_faq.style-1 .faq-item.active .faq-question {color:%4$s}'."\n";
	$custom_css .= '.%1$s .section_faq.style-1 .faq-item.active .faq-question:after {background:%4$s}'."\n";
}
if( !empty( $atts['title_color'] ) ){
	$custom_css .= '.%1$s .section_faq.style-1 .faq-item .faq-question {color:%5$s;}' ."\n";
	$custom_css .= '.%1$s .section_faq.style-1 .faq-item .faq-question:after {background:%5$s;}' ."\n";
}
if( !empty( $atts['content_color'] ) ){
	$custom_css .= '.%1$s .section_faq.style-1 .faq-item .faq-answer {color:%6$s;}' ."\n";
}
if( !empty( $atts['content_bg_color'] ) ){
	$custom_css .= '.%1$s .section_faq.style-1 .faq-item .faq-answer {background:%7$s;}' ."\n";
}

if ( !empty( $custom_css ) ) {
	$custom_css = sprintf($custom_css,
			esc_attr($sc_id),
			esc_attr($atts['block_title_color']),
			esc_attr($atts['block_title_bg']),
			esc_attr($atts['active_color']),
			esc_attr($atts['title_color']),
			esc_attr($atts['content_color']),
			esc_attr($atts['content_bg_color'])
			);
	do_action( COSMOS_CORE_ADD_INLINE_CSS, $custom_css );
}
?>

<div class="pix-shortcode sc-faq <?php echo esc_attr($block_class) ?> <?php echo esc_attr($css_animation_class); ?>"  data-animate="<?php echo esc_attr($css_animation); ?>" data-delay="<?php echo esc_attr($delay_animation); ?>" data-id="<?php echo esc_attr($sc_id);?>">
	<div class="section_faq style-1">
		<?php if(!empty($atts['block_title'])) { ?>
		<p class="title"><?php echo esc_attr($atts['block_title']) ?></p>
		<?php } ?>
		<div class="<?php echo esc_attr($css_animation_parent_class);?>" data-animate="<?php echo esc_attr($css_animation_parent); ?>" data-delay="<?php echo esc_attr($delay_animation_parent); ?>">
			<?php
			/*
			%1$s is title
			%2$s is content
			*/
			$html_format = ('
			    <div class="faq-item">
			        <div class="faq-question">
			        	%1$s
			        </div>
			        <div class="faq-answer">
			        	%2$s
			        </div>
			    </div>
			');
			$html_option = array(
				'html_format'=> $html_format,
			);
			$model->render_faq_sc($html_option);
			?>		
    	</div>
    </div>
</div>