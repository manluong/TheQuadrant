<?php
class Cosmos_Core_Blog_Model {
	public $post_id;
	public $title;
	public $title_attribute;
	public $has_thumbnail = false;
	public $permalink;

	public $uniq_id;
	public $post;
	public $attributes = array();
	public $query;

	public function set_attributes( $atts = array() ) {
		$this->uniq_id = Cosmos_Core::make_id();
		$default = array(
			'layout'               => '',
			'post_type'			   => '',
			'style'                => '',
			'block_title'          => '',
			'block_title_color'    => '',
			'block_title_bg_color' => '',
			'limit_post'           => '',
			'offset_post'          => '0',
			'extra_class'          => '',
			'sort_by'              => '',
			'pagination'           => '',
			'max_post'             => '',
			'category_filter'      => '',
			'category_filter_text' => 'All',
			'title_length'         => '',
			'excerpt_length'       => '',
			'show_category'        => '',
			'show_tag'             => '',
			'show_date'            => '',
			'show_author'          => '',
			'show_comments'        => '',
			'show_views'           => '',
			'show_excerpt'         => '',
			'show_meta'            => '',
			'category_list'        => '',
			'tag_list'             => '',
			'author_list'          => '',
			'format_list'          => '',
			'category_slug'        => '',
			'tag_slug'             => '',
			'author'               => '',
			'post_format'          => '',
			'cur_post_id'          => '',
			'post_filter_by'       => '',
			'block-class'          => '',
			'responsive-class'     => '',
			'column'               => '1',
			'related_post_count'   => '2',
			'paged'                => '',
			'cur_limit'            => '',
			'button_text'          => '',
			'show_content'         => '',
			'show_sticky'          => '',
            'category_color'       => '',
            'title_color'       	=> '',
            'title_color_hv'    	=> '',
            'meta_color'        	=> '',
            'meta_color_hv'     	=> '',
            'line_color'        	=> '',
            'excerpt_color'     	=> '',
            'button_color'      	=> '',
            'button_color_hv'   	=> '',
            'css_animation'   		=> '',
            'is_parent_animation'	=> 'no',
            'delay_animation'		=> '0',
		);
		$data = Cosmos_Core::set_shortcode_defaults( $default, $atts);
		if( empty( $data['category_slug'] ) ) {
			list( $data['category_list_parse'], $data['category_slug'] ) = Cosmos_Core_Util::get_list_vc_param_group( $data, 'category_list', 'category_slug' );
		}
		if( empty( $data['tag_slug'] ) ) {
			list( $data['tag_list_parse'], $data['tag_slug'] ) = Cosmos_Core_Util::get_list_vc_param_group( $data, 'tag_list', 'tag_slug' );
		}
		if( empty( $data['author'] ) ) {
			list( $data['author_list_parse'], $data['author'] ) = Cosmos_Core_Util::get_list_vc_param_group( $data, 'author_list', 'author' );
		}
		if( empty( $data['post_format'] ) ) {
			list( $data['format_list_parse'], $data['post_format'] ) = Cosmos_Core_Util::get_list_vc_param_group( $data, 'format_list', 'post_format' );
		}
		// Check valid
		if($data['limit_post'] != -1) {
			$data['limit_post'] = absint($data['limit_post']);
		}
		$data['offset_post'] = absint($data['offset_post']);
		if( empty($data['offset_post']) ) {
			$data['offset_post'] = 0;
		}
		if( empty($data['block-class'] ) ) {
			$data['block-class'] = sprintf( '%s-%s', $data['layout'], $this->uniq_id ) ;
		}
		$this->attributes = $data;
		// query
		$this->query = $this->get_query( $data );
	}
	/**
	 * Loop posts.
	 */
	public function loop_index() {
		global $post;

		$this->post_id = $post->ID;
		$this->post = $post;

		$this->title = get_the_title( $post->ID );
		$this->title_attribute = esc_attr( strip_tags( $this->title ) );
		$this->permalink = esc_url( $this->get_post_url( $post->ID ) );

		if ( has_post_thumbnail( $post->ID ) ) {
			$this->has_thumbnail = true;
		} else {
			$this->has_thumbnail = false;
		}
	}
	/**
	 * Query
	 * 
	 * @return WP_Query
	 */
	private function get_query( $data, $paged = '') {
		$is_paging = false;
		$query_args = array(
			'post_type' => 'post',
			'post_status' => 'publish',
			'ignore_sticky_posts' => 1 // do not move sticky posts to the start of the set.
		);
		if (isset($data['post_type']) ) {
			$query_args['post_type'] = $data['post_type'];
		}

		$posts_per_page = get_option('posts_per_page');
		//custom pagination limit
		if ( empty($data['limit_post'] ) ) {
			$data['limit_post'] = $posts_per_page;
		}
		if( $data['cur_limit'] ) {
			$data['limit_post'] = $data['cur_limit'];
		}
		$query_args['posts_per_page'] = $data['limit_post'];
		
		if( isset($data['paged']) && $data['paged'] ) {
			$paged = $data['paged'];
		} else {
			$paged = ( get_query_var('paged') ) ? get_query_var('paged') : 1;
		}
		if( empty($data['paged']) && ($data['pagination'] == 'ajax' || $data['pagination'] == 'load_more') ) {
			$paged = 1;
		}
		// Offset start: 0
		$offset = $data['offset_post'];
		if( $data['pagination'] == '' ) {
			$query_args['nopaging '] = false;
		} else {
			$query_args['nopaging '] = 'paging';
			$query_args['paged'] = $paged;
			$is_paging = true;
			if( isset($data['offset_post']) && $paged > 1 ) {
				$offset = $offset + ( ($paged - 1) * $data['limit_post']) ;
			}
		}
		$query_args['offset'] = $offset ;
		if( !empty( $data['category_slug'] ) ) {
			if( is_array( $data['category_slug'] ) ) {
				$data['category_slug'] = implode(',', $data['category_slug']);
			}
			$query_args['category_name'] = $data['category_slug'];
		}
		if( !empty( $data['tag_slug'] ) ) {
			if( is_array( $data['tag_slug'] )) {
				$data['tag_slug'] = implode(',', $data['tag_slug']);
			}
			$query_args['tag'] = $data['tag_slug'];
		}
		if( !empty( $data['author'] ) ) {
			//author_id
			if( is_array( $data['author'] )) {
				$data['author'] = implode(',', $data['author']);
			}
			$query_args['author'] = $data['author'];
		}
		// filter by post format
		if( isset($data['post_format']) && !empty( $data['post_format'] ) ) {
			$arr_post_format = array();
			foreach( $data['post_format'] as $format ){
				$arr_post_format[] = 'post-format-' . $format;
			}
			$query_args['tax_query'] = array(
				array(
					'taxonomy' => 'post_format',
					'field'    => 'slug',
					'terms'    => $arr_post_format,
					'include_children' => 0
				)
			);
		}
		// post id
		if( isset( $data['show_sticky'] ) &&  $data['show_sticky'] == 'yes' ) {
			unset( $query_args['ignore_sticky_posts'] );
		}
		// filter by
		if( !empty( $data['post_filter_by'] ) ) {
			$cur_post_id = $this->attributes['cur_post_id'];
			if( empty($cur_post_id) ) {
				$cur_post_id = get_the_ID();
			}
			switch ($data['post_filter_by'] ) {
				case 'post_same_author':
					$query_args['author'] = get_post_field( 'post_author', $cur_post_id );
					$query_args['post__not_in'] = array( $this->post_id );
					break;
				case 'post_same_category':
					$query_args['category__in'] = wp_get_post_categories( $cur_post_id );
					$query_args['post__not_in'] = array( $cur_post_id );
					
					break;
				case 'post_same_format':
					$post_format = get_post_format( $cur_post_id );
					if( $post_format ) {
						$tax_query = array(
							array(
								'taxonomy' => 'post_format',
								'field' => 'slug',
								'terms' => array("post-format-{$post_format}")
							)
						);
						$query_args["tax_query"] = $tax_query;
						$query_args['post__not_in'] = array( $cur_post_id );
					}
					break;
				case 'post_same_tag':
					$tags = wp_get_post_tags( $cur_post_id );
					if ( $tags ) {
						$tag_list = array();
						for ($i = 0; $i <= 4; $i++) {
							if (!empty($tags[$i])) {
								$taglist[] = $tags[$i]->term_id;
							} else {
								break;
							}
						}
						$query_args['tag__in'] = $tag_list;
						$query_args['post__not_in'] = array( $this->post_id  );
					}
					break;
			}
		}
		// sort by
		switch ( $data['sort_by'] ) {
			case 'az_order':
				$query_args['orderby'] = 'title';
				$query_args['order'] = 'ASC';
				break;
			case 'za_order':
				$query_args['orderby'] = 'title';
				$query_args['order'] = 'DESC';
				break;
			case 'popular':
				$query_args['meta_key'] = COSMOS_CORE_POST_VIEWS;
				$query_args['orderby'] = 'meta_value_num';
				$query_args['order'] = 'DESC';
				break;
			case 'random_posts':
				$query_args['orderby'] = 'rand';
				break;
			case 'random_today':
				$query_args['orderby'] = 'rand';
				$query_args['year'] = date('Y');
				$query_args['monthnum'] = date('n');
				$query_args['day'] = date('j');
				break;
			case 'random_7_day':
				$query_args['orderby'] = 'rand';
				$query_args['date_query'] = array(
					'column' => 'post_date_gmt',
					'after' => '1 week ago'
				);
				break;
			case 'random_month':
				$query_args['orderby'] = 'rand';
				$query_args['date_query'] = array(
					'column' => 'post_date_gmt',
					'after' => '1 month ago'
				);
				break;
			case 'comment_count':
				$query_args['orderby'] = 'comment_count';
				$query_args['order'] = 'DESC';
				break;
			default:
		}
		
		if( $is_paging && !empty($this->attributes['max_post']) && $this->attributes['max_post'] > 0 ) {
			$max_num_pages = ceil( $this->attributes['max_post'] / $query_args['posts_per_page']);
			if ( $this->attributes['max_post'] < $query_args['posts_per_page'] ) {
				$query_args['posts_per_page'] = $this->attributes['max_post'];
			}
			// go to first page when paged larger paged after apply max_post
			if ($query_args['paged'] > $max_num_pages) {
				$query_args['offset'] = $data['offset_post'];
				$query_args['paged'] = 1;
			}
		}
		
		$query = new WP_Query( $query_args );
		
		if( $is_paging ) {
			$start_offset = !empty($this->attributes['offset_post']) && $this->attributes['offset_post'] > 0 ? $this->attributes['offset_post'] : 0;
			$query->found_posts = $this->recalc_found_posts($query, $start_offset );
			if (!empty($this->attributes['max_post']) && $this->attributes['max_post'] < $query->found_posts ) {
				$query->found_posts = $this->attributes['max_post'];
			}
			$query->max_num_pages = ceil( $query->found_posts / $query_args['posts_per_page']);
		}
		
		return $query;
	}
	public function recalc_found_posts($query, $offset) {
		$found_posts = $query->found_posts;
		if( $offset ) {
			return $found_posts - $offset;
		}
		return $found_posts;
	}
	/**
	 * Get post author.
	 * 
	 * @param string $echo - false(default)
	 * @return string
	 */
	public function get_author( $html_option = array(), $echo = false ) {
		$out = $format = '';
		if( $this->attributes['show_author'] != 'hide' ) {
			if ( is_singular() || is_multi_author() ) {
				$format = '<div class="author">'.esc_html__('Posted by', 'pix-core').' : <a href="%1$s">%2$s</a></div>';
				if ( isset($html_option['author_format'])) {
					$format = $html_option['author_format'];
				}
				$url = get_author_posts_url( $this->post->post_author );
				$out = sprintf( $format,
						esc_url( $url ),
						esc_html( get_the_author_meta('display_name', $this->post->post_author ) )
				);
			}
		}
		if( ! $echo ) {
			return $out;
		}
		echo wp_kses_post( $out );
	}
	/**
	 * Get post views
	 * 
	 * @param string $echo - false(default)
	 * @return string
	 */
	public function get_views( $html_option = array(), $echo= false ) {
		$out = '';
		$format = '<div class="view"><i class="icon fa fa-user"></i><span>%1$s : %2$s</span></div>';
		if ( isset($html_option['views_format'])) {
			$format = $html_option['views_format'];
		}
		if( $this->attributes['show_views'] != 'hide' ) {
			$viewcount = $this->get_post_view( $this->post_id );
			$out = sprintf( $format, esc_html__('View', 'pix-core'), esc_html( $viewcount ) );
		}
		if( ! $echo ) {
			return $out;
		}
		echo wp_kses_post( $out );
		
	}
	/**
	 * Get post comment number.
	 * 
	 * @param string $echo - false(default)
	 * @return string
	 */
	public function get_comments( $html_option = array(), $echo= false ) {
		$out = '';
		$format = '<div class="comment"><i class="icon fa fa-comment"></i><span>%1$s : %2$s</span></div>';
		if ( isset($html_option['comments_format'])) {
			$format = $html_option['comments_format'];
		}
		if( $this->attributes['show_comments'] != 'hide' ) {
			if ( ! post_password_required() && ( comments_open() || get_comments_number() ) ) {
				$out = sprintf( $format, esc_html__('Comment', 'pix-core'), get_comments_number(), get_comments_link( $this->post_id ) );
			}
		}
		if( ! $echo ) {
			return $out;
		}
		echo wp_kses_post( $out );
	}
	/**
	 * Get post date
	 * 
	 * @param string $echo - false(default)
	 * @return string
	 */
	public function get_date( $html_option = array(), $echo= false, $default = false ) {
		$out = '';
		$format = '<div class="post-date"><a href="%1$s"><span class="date">%2$s</span>%3$s %4$s</a></div>';
		if ( isset($html_option['date_format'])) {
			$format = $html_option['date_format'];
		}
		$day = get_the_time('d');
		$month = get_the_time('M');
		$year = get_the_time('Y');
		$out  = sprintf( $format, $this->permalink, $day, $month, $year );
		if ($default) {
			$out  = sprintf($format, $this->permalink, get_the_date() );
		}
		if( ! $echo ) {
			return $out;
		}
		echo wp_kses_post( $out );
	}
	/**
	 * Get main category of post
	 * 
	 */
	/**
	 * Get main category of post.
	 * 
	 * @param string $echo - false(default)
	 * @return string
	 */
	public function get_category( $html_option = array(), $echo = false ) {
		$out = $cat = '';
		if( $this->attributes['show_category'] != 'hide' ) {
			$format = '<div class="info"><i class="fa fa-file-o"></i><a href="%1$s" class="info-inner">%2$s</a></div>';
			if ( isset($html_option['category_format'])) {
				$format = $html_option['category_format'];
			}
			// Read the post meta
			$post_options = get_post_meta( $this->post_id, COSMOS_CORE_THEME_PREFIX . '_post_options', true);
			if ( isset( $post_options['main_category'] ) && !empty( $post_options['main_category'] ) ) {
				// Main category has seleted post setting
				$cat = get_category_by_slug( $post_options['main_category'] );
			} else {
				// Get one auto
				$cat = current( get_the_category( $this->post ) );
			}
			if ( $cat ) {
				$out = sprintf( $format, get_category_link($cat->cat_ID), esc_attr( $cat->name ) );
			}
		}
		if( !$echo ) {
			return $out;
		}
		echo wp_kses_post( $out );
	}
	/**
	 * Feature images
	 * 
	 */
	public function get_featured_image( $thumb_type = 'large', $echo = false, $options = array() ) {
		$out = $thumb_img = $img_cate = '';
		$thumb_size = $this->attributes['thumb-size'][$thumb_type];
		
		if( ! isset( $options['thumb_href_class'] ) ) {
			$options['thumb_href_class'] = 'media-image';
		}
		// 1: href, 2: image, 3: icon format, 4: thumb_href_class
		$format = '<a href="%1$s" class="%4$s">%2$s%3$s</a>';
		if(!empty($options['image_format'])) {
			$format = $options['image_format'];
		}
		$thumb_class = 'img-responsive';
		if( isset($options['thumb_class'])) {
			$thumb_class = $options['thumb_class'];
		}
		if( $this->has_thumbnail ) {
			$thumb_id = get_post_thumbnail_id( $this->post_id );
			// regenerate if not exist.
			$helper = new Cosmos_Core_Helper();
			$helper->regenerate_attachment_sizes($thumb_id, $thumb_size);
			$thumb_img = wp_get_attachment_image( $thumb_id, $thumb_size, false, array('class' => $thumb_class ) );
		} else {
			$thumb_img = Cosmos_Core_Util::get_no_image( $this->attributes['thumb-size'], $this->post, $thumb_type, $options );
		}
		$format_icon = Cosmos_Core_Params::get( 'post-format-icon' );
		$post_format = get_post_format( $this->post_id );
		if( isset($format_icon[$post_format]) ) {
			$img_cate = $format_icon[$post_format];
			$img_cate = sprintf('<div class="img-cate"><i class="fa %s"></i></div>', $img_cate );
		}
		$out = sprintf( $format, $this->permalink, $thumb_img, $img_cate, $options['thumb_href_class'] );
		if( !$echo ) {
			return $out;
		}
		echo wp_kses_post( $out );
	}
	public function get_featured_url( $thumb_type = 'large' ) {
		$thumb_size = $this->attributes['thumb-size'][$thumb_type];
		if( $this->has_thumbnail ) {
			$thumb_id = get_post_thumbnail_id( $this->post_id );
			$attach_img = wp_get_attachment_image_src( $thumb_id, $thumb_size );
			if( $attach_img ) {
				$thumb_url = $attach_img[0];
			}
		}
		if( empty($thumb_url)) {
			$thumb_url = Cosmos_Core_Util::get_no_image_url( $this->attributes['thumb-size'], $this->post, $thumb_type );
		}
		return $thumb_url;
	}
	public function get_featured_image_only( $thumb_type = 'large', &$options = array() ) {
		$out = $thumb_img = '';
		$thumb_size = $this->attributes['thumb-size'][$thumb_type];
	
		$image_class = 'img-responsive';
		if( isset($options['image_class'])) {
			$image_class = $options['image_class'];
		}
		$thumb_href_class = '';
		if( isset( $options['thumb_href_class'] ) ) {
			$thumb_href_class = $options['thumb_href_class'];
		}
		// 1: image
		$format = '<a href="%1$s" class="%3$s">%2$s</a>';
		if( isset( $options['image_format'] ) ) {
			$format = $options['image_format'];
		}
		if( $this->has_thumbnail ) {
			$thumb_id = get_post_thumbnail_id( $this->post_id );
			$thumb_img = wp_get_attachment_image( $thumb_id, $thumb_size, false, array('class' => $image_class ) );
			$options['ret_attach_img'] = wp_get_attachment_image_src( $thumb_id, $thumb_size );
		}
		if( $thumb_img ) {
			$out = sprintf( $format, $this->permalink, $thumb_img, $thumb_href_class );
		}
		return $out;
	}
	/**
	 * Get related post
	 * 
	 * @param string $limit
	 * @param string $echo
	 * @return string
	 */
	public function get_related_post( $limit = '', $echo = false, $options = array() ) {
		$out = '';
		if( empty($limit) ) {
			$limit = -1;
		}
		$args = array( 'posts_per_page' => $limit );
		$related_query = Cosmos_Core_Com::get_query_related_posts( $this->post_id, $args );
		$format = '<a href="%1$s"><i class="fa fa-caret-right"></i><span>%2$s</span></a>';
		if ( $related_query->have_posts() ) {
			$related_posts = $related_query->posts;
			foreach($related_posts as $row ) {
				$title = isset( $row->post_title ) ? $row->post_title : '';
				if( ! empty ( $title ) ) {
					$out .= sprintf($format, get_permalink($row->ID), get_the_title($row->ID) );
				}
			}
		}
		if( empty( $out ) ) {
			return '';
		}
		$format = '<div class="sub-link">%s</div>';
		if( !$echo ) {
			return sprintf( $format, $out );
		}
		printf( $format, $out );
	}
	/**
	 * Get post title
	 * 
	 * @param string $limit
	 * @param string $echo
	 * @return string
	 */
	public function get_title( $options = array(), $is_limit = true, $echo = false  ) {
		$output = '<a href="%2$s" class="%3$s" >%1$s</a>';
		if( ! isset( $options['title_class'] ) ) $options['title_class'] = 'title-text';
		if( isset( $options['title_format'] ) && !empty( $options['title_format'] ) ) {
			$output = $options['title_format'];
		}
		$title = $this->title;
		$limit = $this->attributes['title_length'];
		if( $is_limit && !empty( $limit ) ) {
			// cut title by limit
			$title = wp_trim_words($this->title, $limit);
		}
		if( ! $echo ) {
			return sprintf( $output, esc_html( $title ), esc_url($this->permalink), esc_attr($options['title_class'] ));
		} 
		printf( $output, esc_html( $title ), esc_url($this->permalink), esc_attr($options['title_class'] ));
	}
	/**
	 * Get the permalink
	 */
	
	public function get_link() {
		global $post;
		$this->post_id = $post->ID;
		$this->post = $post;
		$this->permalink = esc_url( $this->get_post_url( $post->ID ) );
		return $this->permalink;
	}
	/**
	 * Get the excerpt
	 * 
	 * @param string $limit
	 * @param string $echo
	 * @return string
	 */
	
	public function get_excerpt( $is_limit = true, $echo = false ) {
		$trim_excerpt = '';
		if ( $this->attributes['show_excerpt'] != 'hide'){
			$trim_excerpt = get_the_excerpt();
			$limit = $this->attributes['excerpt_length'];
			if( $is_limit && !empty( $limit ) ) {
				$trim_excerpt = wp_trim_words($trim_excerpt, $limit, ' […]');
			}
		}
		if( !$echo ) {
			return $trim_excerpt;
		}
		echo wp_kses_post($trim_excerpt);
	}
	private function isLink( $post_id ) {
		return get_post_format( $post_id ) === 'link';
	}
	private function isVideo($post_id) {
		return get_post_format( $post_id ) === 'video';
	}
	private function isGallery($post_id) {
		return get_post_format( $post_id ) === 'gallery';
	}
	private function get_post_url( $post_id ) {
		if( $this->isLink( $post_id ) ) {
			$content = get_the_content( $post_id );
			$has_url = get_url_in_content( $content );
				
			return ( $has_url ) ? $has_url : apply_filters( 'the_permalink', get_permalink( $post_id ) );
		} else {
			return get_permalink( $post_id );
		}
	}
	public function add_post_filter_atts( $atts ) {
		if ( !empty( $atts['post_filter_by'] ) ) {
			$atts['cur_post_id'] = get_queried_object_id(); //add the current post id
			$atts['cur_post_author'] =  get_post_field( 'post_author', $atts['cur_post_id']); //get the current author
		}
		return $atts;
	}
	public function get_post_view( $post_id = '' ) {
		global $post;
		if( empty( $post_id ) && $post ) {
			$post_id = $post->ID;
		}
		$count_key = COSMOS_CORE_POST_VIEWS;
		$count = get_post_meta( $post_id, $count_key, true );
		$res = '';
		if($count == '') {
			delete_post_meta( $post_id, $count_key );
			add_post_meta( $post_id, $count_key, '0' );
			$res = 0;
		} else {
			$res = $count;
		}
		return $res;
	}
	public function get_post_class( $class = '', $post_id = '' ) {
		if( empty( $post_id ) ) {
			$post_id = $this->post_id;
		}
		return join( ' ', get_post_class( $class, $post_id ) );
	}
	public function view_more_button( $echo = false, $post_id = '', $btn_content = '', $html_options = array() ) {
		if( empty( $btn_content ) ) {
			$btn_content = esc_html__( 'View more', 'pix-core' );
		}
		if( ! isset( $html_options['class'] ) ) {
			$html_options['class'] = 'btn btn-viewmore';
		}
		if( $echo ) {
			return printf( '<a href="%1$s" class="%2$s">%3$s</a>', $this->permalink, $html_options['class'], $btn_content );
		}
		return sprintf( '<a href="%1$s" class="%2$s">%3$s</a>', $this->permalink, $html_options['class'], $btn_content );
	}
	public function get_featured_by_format( $thumb_type = 'large', &$options = array() ) {
		$opts = $options;
		$opts['image_format'] = '%2$s';
		$featured_image = $this->get_featured_image_only( $thumb_type, $opts );
		if( ! $this->isVideo( $this->post_id ) ) {
			if( $featured_image ) {
				if( isset( $options['image_format']) ) {
					return sprintf( $options['image_format'], $this->permalink, $featured_image);
				} else {
					return $featured_image;
				}
			}
			
		} else {
			//video
			$post_meta_video = get_post_meta( $this->post_id, COSMOS_CORE_THEME_PREFIX . '_feature_video', true );
			$is_video_type = false;
			$iframe_video = '';
			if ( !empty($post_meta_video) ) {
				if ( $post_meta_video['video_type'] == 'youtube' && !empty($post_meta_video['youtube_id']) ) {
					$is_video_type = true;
				} elseif ( $post_meta_video['video_type'] == 'vimeo' && !empty($post_meta_video['vimeo_id']) ) {
					$is_video_type = true;
				}
			}
			if ($is_video_type == true) {
				$video_type = $post_meta_video['video_type'];
				if ($video_type == "youtube") {
					$iframe_video = '<iframe src="https://www.youtube.com/embed/'.esc_html( $post_meta_video['youtube_id'] ).'?rel=0" allowfullscreen="allowfullscreen" class="video-embed"></iframe>';
				} elseif ($video_type == "vimeo") {
					$iframe_video = '<iframe src="https://player.vimeo.com/video/'.esc_html( $post_meta_video['vimeo_id'] ).'?'.'" webkitallowfullscreen mozallowfullscreen allowfullscreen class="video-embed"></iframe>';
				}
			}
			if( $featured_image ) {
				$options['bg_image'][$this->post_id] = $opts['ret_attach_img'][0];
			}
			return sprintf( $options['video_format'], $iframe_video, $featured_image );
		}
		$options['no_thumbnails_image'] = 'no-thumbnails-image';
	}
}