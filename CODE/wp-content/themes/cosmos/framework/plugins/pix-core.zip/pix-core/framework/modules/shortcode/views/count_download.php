<?php
$uniq_id = 'sc-count-download-'.esc_attr( $id );
$custom_css = '';
$style = ( ! empty($style) ) ? $style : 3;

if( !empty( $title_color ) ){
    $custom_css .= sprintf('.%1$s .section_download .download-app .download-text { color: %2$s;}',
                        esc_attr($uniq_id), esc_attr($title_color) );
}
if( !empty( $number_color ) ){
    $custom_css .= sprintf('.%1$s .section_download .download-app .download-number { color: %2$s;}',
                        esc_attr($uniq_id), esc_attr($number_color) );
}
if( !empty( $background_icon_color ) && $style == 5) {
    $custom_css .= sprintf('.%1$s .section_download .download-app.style-5 .download-img{ background: %2$s;}',
                        esc_attr($uniq_id), esc_attr($background_icon_color) );
}

if ( !empty( $custom_css ) ) {
    do_action( COSMOS_CORE_ADD_INLINE_CSS, $custom_css );
}

$image_background = wp_get_attachment_image_src($icon_download, 'full', false);
if ( ! empty ($image_background) ) { 
    $image_src = $image_background[0];
    $image_width = $image_background[1];
    $image_height = $image_background[2];
} else {
    $image_src = NULL;
    $image_width = NULL;
    $image_height = NULL;
}
?>

<div id="<?php echo esc_attr($uniq_id)?>" class="pix-shortcode sc-count-download <?php echo esc_attr($uniq_id).' '.esc_attr( $extra_class )?> animate-run" data-animate="<?php echo esc_attr($css_animation); ?>" data-delay="<?php echo (int) esc_attr($delay_animation); ?>">
    <div class="section_download style-<?php echo esc_attr($style) ?>">
        <div class="download-app style-<?php echo esc_attr($style) ?>">
            <div class="download-img">
            <?php if ( ! empty ($image_src)) { ?>
                <img src="<?php echo esc_attr($image_src) ?> " alt="window" data-type="image">
            <?php } ?>
            </div>
            <div class="download-number">
                <span data-type="title"><?php echo esc_html(intval($number_download)) ?></span>
            </div>
            <div class="download-text">
                <span data-type="title"><?php echo esc_html($title_download) ?></span>
            </div>
        </div>
    </div>
</div>