<?php
$sc_controller = new Cosmos_Core_Shortcodes_Controller();
$style = array(
	esc_html__( 'Style 1', 'pix-core' )				=> '1',
	esc_html__( 'Style 2', 'pix-core' )				=> '2',
);
$params = array(
	array(
		'type'        => 'dropdown',
		"class"       => "",
		'heading'     => esc_html__( 'Style', 'pix-core' ),
		'param_name'  => 'style',
		'value'       => $style,
		'description' => esc_html__( 'Select style.',  'pix-core'  )
	),
	array(
		'type'        => 'pix_datetime_picker',
		"class"       => "",
		'heading'     => esc_html__( 'End Date', 'pix-core' ),
		'param_name'  => 'end_date',
		'value'       => '',
		'description' => esc_html__( 'Select End Date.',  'pix-core'  )
	),
	array(
		"type"        => "colorpicker",
		"class"       => "",
		"heading"     => esc_html__( "Title Color", 'pix-core' ),
		"param_name"  => "title_color",
		"description" => esc_html__( "Choose title color.", 'pix-core' ),
		'group'       => esc_html__('Options', 'pix-core'),
	),
	array(
		"type"        => "colorpicker",
		"class"       => "",
		"heading"     => esc_html__( "Number Color", 'pix-core' ),
		"param_name"  => "number_color",
		"description" => esc_html__( "Choose number color.", 'pix-core' ),
		'group'       => esc_html__('Options', 'pix-core'),
	),
	array(
		"type"        => "colorpicker",
		"class"       => "",
		"heading"     => esc_html__( "Border Color", 'pix-core' ),
		"param_name"  => "border_color",
		"description" => esc_html__( "Choose border color.", 'pix-core' ),
		'group'       => esc_html__('Options', 'pix-core'),
		'dependency'  => array(
			'element' 	=> 'style',
			'value'   	=> array('1')
		),
	),
	array(
		'type'            => 'textfield',
		'heading'         => esc_html__( 'Extra Class', 'pix-core' ),
		'param_name'      => 'extra_class',
		'description'     => esc_html__( 'Style particular content element differently - add a class name and refer to it in custom CSS.', 'pix-core' )
	),
	$sc_controller->cosmos_animation_style(),
	$sc_controller->cosmos_animation_delay(),

);

vc_map(
	array(
		"name"			=> esc_html__( 'PIX Count Down', 'pix-core' ),
		"base"			=> "pixcore_count_down_sc",
		"class"			=> "pixcore-sc",
		"category"		=> COSMOS_CORE_SC_CATEGORY,
		'icon'			=> 'icon-pixcore_count_down_sc',
		"description"	=> esc_html__( 'Count down to date', 'pix-core' ),
		"params"		=> $params
	)
);