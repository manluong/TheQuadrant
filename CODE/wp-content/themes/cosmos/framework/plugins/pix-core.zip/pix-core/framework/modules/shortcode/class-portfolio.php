<?php
class Cosmos_Core_Portfolio extends Cosmos_Core_Custom_Post_Model {

	private $post_type = 'cosmos_portfolio';
	private $post_taxonomy = 'cosmos_portfolio_cat';
	private $html_format;

	public function __construct() {
		$this->meta_attributes();
		$this->set_meta_attributes();
		$this->post_meta_prefix = $this->post_type . '_';
		$this->taxonomy_cat = $this->post_taxonomy;
	}

	public function meta_attributes() {
		$meta_atts = array(
			'portfolio_images'      => esc_html__('Portfolio Images', 'pix-core'),
		);
		$this->post_meta_atts = $meta_atts;
	}

	public function set_meta_attributes() {
		$meta_arr = array();
		$meta_label_arr = array();
		foreach( $this->post_meta_atts as $att => $name ){
			$key = $att;
			$meta_arr[$key] = '';
			$meta_label_arr[$key] = $name;
		}
		$this->post_meta_def = $meta_arr;
		$this->post_meta = $meta_arr;
		$this->post_meta_label = $meta_label_arr;
	}

	public function reset(){
		wp_reset_postdata();
	}

	public function init( $atts = array(), $query_args = array() ) {
		// set attributes
		$default_atts = array(
			'layout'				=> 'portfolio',
			'limit_post'			=> '-1',
			'offset_post'			=> '',
			'sort_by'				=> 'post__in',
			'pagination'			=> '',
			'column'				=> ''
		);
		$atts = array_merge( $default_atts, $atts );
		if ( $atts['method'] == 'cat' ) {
            $atts['post_id'] = $this->parse_cat_slug_to_post_id(
                $this->taxonomy_cat,
                $atts['category_slug'],
                $this->post_type
            );
        }
        elseif ($atts['method'] == 'portfolio') {
            $atts['post_id'] = $this->parse_list_to_array( 'post_id', $atts['post_list'] );
        }
		$this->attributes = $atts;
		// query
		$default_args = array(
			'post_type' => $this->post_type,
		);
		$query_args = array_merge( $default_args, $query_args );
		// setting
		$this->setting( $query_args);
	}

	public function setting( $query_args ){
		if( !isset( $this->attributes['uniq_id'] ) ) {
			$this->attributes['uniq_id'] = $this->post_type . '-' .Cosmos_Core::make_id();
		}
		// query
		if( !isset($this->attributes['no_setting_query'])) {
			$this->query = $this->get_query( $query_args, $this->attributes );
			$this->post_count = 0;
			if( $this->query->have_posts() ) {
				$this->post_count = $this->query->post_count;
			}
			$custom_css = $this->add_custom_css();
			if( $custom_css ) {
				do_action( COSMOS_CORE_ADD_INLINE_CSS, $custom_css );
			}
		}
		// image size
		$this->get_thumb_size();
		$this->set_responsive_class();
	}

	public function set_responsive_class( $atts = array() ) {
		$class = '';
		$column = $this->attributes['column'];
		$def = array(
			'1' => 'col-xs-12 portfolio-1col',
			'2' => 'col-sm-6 col-xs-6 portfolio-2col',
			'3' => 'col-md-4 col-sm-6 col-xs-6 portfolio-3col',
			'4' => 'col-lg-3 col-md-4 col-sm-6 col-xs-6 portfolio-4col',
		);
		
		if( $column && isset($def[$column])) {
			return $this->attributes['responsive-class'] = $def[$column];
		} else {
			return $this->attributes['responsive-class'] = $def['4'];
		}
	}

	public function add_custom_css() {
		$custom_css = '';
		
		return $custom_css;
	}

	public function set_default_options( $html_options = array() ) {
		$defaults = array(
		);
		$html_options = array_merge( $defaults, $html_options );
		return $html_options;
	}

	public function get_thumb_size() {
		$params = Cosmos_Core_Params::get( 'block_image_size', $this->attributes['layout'] );
		$this->attributes['thumb-size'] = Cosmos_Core_Util::get_thumb_size( $params, $this->attributes );
	}


	/****************/
	/*  RENDER HTML */
	/****************/
	public function get_filter( $html_options = array() ) {
		$this->html_format = $this->set_default_options( $html_options );
		$count = 0;
		if( $this->query->have_posts() ) {
			while ( $this->query->have_posts() ) {
				$count++;
				$class_active = '';
				if($count == 1) {
					$class_active = 'active';
				}
				$this->query->the_post();
				$this->loop_index();
				$html_options = $this->html_format;

				printf( $html_options['html_format'],
					esc_attr($class_active),
					esc_attr($this->attributes['uniq_id'].'-'.$this->post_slug),
					$this->get_title( $html_options)
				);
			}
			$this->reset();
		}
	}

	public function render_portfolio_sc( $html_options = array() ) {
		$this->html_format = $this->set_default_options( $html_options );
		$count = 0;
		if( $this->query->have_posts() ) {
			while ( $this->query->have_posts() ) {
				$count++;
				$class_active = '';
				if($count == 1) {
					$class_active = 'active';
				}
				$this->query->the_post();
				$this->loop_index();
				$html_options = $this->html_format;

				$thumb_type = 'large';

				printf( $html_options['html_format'],
					esc_attr($class_active),
					esc_attr($this->attributes['uniq_id'].'-'.$this->post_slug),
					$this->get_meta_portfolio_image( $thumb_type )
				);
			}
			$this->reset();
		}
	}

	public function get_meta_portfolio_image( $thumb_type = 'large', $thumb_size = '', $echo = false ) {
		$portfolioArr = array();
		if( $this->has_thumbnail ) {
			$thumb_id = get_post_thumbnail_id( $this->post_id );
			$portfolioArr[] = $thumb_id;
		}
		$output = $thumb_size_style = $thumb_img_style = '';
		$portfolio = $this->post_meta['portfolio_images'];
		$portfolio = str_replace(',,', ',', $portfolio);
		$image_meta = explode(',', $portfolio);
		$image_metaArr = array_filter($image_meta);
		$portfolioArr =array_merge($portfolioArr,$image_metaArr);

		$class_active = '';
		$column_def = array(
			'1' => 'col-xs-12 process-1col',
			'2' => 'col-sm-6 col-xs-6 process-2col',
			'3' => 'col-md-4 col-sm-6 col-xs-6 process-3col',
			'4' => 'col-md-3 col-sm-4 col-xs-6 process-4col',
		);
		
		if( !empty($portfolioArr) && is_array($portfolioArr) ) {
			foreach ($portfolioArr as $key => $thumb_id) {
				$column = $this->attributes['column'];
				$get_attached_file = get_attached_file($thumb_id);
				if ( !file_exists($get_attached_file) ) {
					continue;
				}
				if( !empty($thumb_id) ) {
					$thumb_img_large_src = wp_get_attachment_image_src( $thumb_id, 'full' );

					if($column == 4) {
						$thumb_size_style = $this->attributes['thumb-size']['small'];
						$thumb_img_style = wp_get_attachment_image( $thumb_id, $thumb_size_style );
						
					} else {
						$thumb_size_style = $this->attributes['thumb-size']['large'];
						$thumb_img_style = wp_get_attachment_image( $thumb_id, $thumb_size_style );
					}
					$output .= sprintf( '
						<div class="%4$s padding0">
                            <a class="item__img fancybox-thumb " data-fancybox-group="%1$s" href="%2$s">
                        		%3$s
                            </a>
                        </div>',
						esc_attr($this->attributes['uniq_id'].'-'.$this->post_slug),
						esc_url($thumb_img_large_src[0]),
						wp_kses_post($thumb_img_style),
						esc_attr($column_def[$column])
					);
					
				}
			}
		}

		if( $echo ) {
			echo wp_kses_post( $output );
		} else {
			return $output;
		}
	}
}