jQuery(document).ready(function($) {
	"use strict";
	// Instantiates the variable that holds the media library frame.
	var pix_upload_frame;
	var pix_btn_upload;
	var library_support = 'video';
	var video;

	// Runs when the image button is clicked.
	$('.pix-btn-upload-video').live('click', function(e){

		// Prevents the default action from occuring.
		e.preventDefault();

		pix_btn_upload = $(this);
		// If the frame already exists, re-open it.
		if ( pix_upload_frame ) {
			pix_upload_frame.open();
			return;
		}

		// Sets up the media library frame
		pix_upload_frame = wp.media.frames.meta_image_frame = wp.media({
			title: pix_meta_image.title,
			button: { text:  pix_meta_image.button },
			library: { type: library_support },
		});

		// Runs when an image is selected.
		pix_upload_frame.on('select', function(){
			// Grabs the attachment selection and creates a JSON representation of the model.
			var media_attachment = pix_upload_frame.state().get('selection').first().toJSON();

			// Container
			var rel = pix_btn_upload.attr('data-rel');
			var self_parent = pix_btn_upload.parent();
			// Sends the attachment URL to our custom image input field.
			var url = media_attachment.type == 'video' && media_attachment.fileLength ? media_attachment.url : '';
			if ( typeof rel !== "undefined") {
				$('#' + rel + '_id').val(media_attachment.id);
				video = document.getElementById(rel + '_name');
				self_parent.find('video source').attr('src', url);
				video.load();
			}
			self_parent.find('div').removeClass('hide');
			pix_btn_upload.next().removeClass('hide');
		});

		// Opens the media library frame.
		pix_upload_frame.open();
	});

	$('.pix-btn-remove').live('click', function(e) {
		// Prevents the default action from occuring.
		e.preventDefault();

		var self = $(this);
		var rel = self.attr('data-rel');
		var self_parent = self.parent();

		if ( typeof rel !== "undefined") {
			$('#' + rel + '_name').val('');
			$('#' + rel + '_id').val('');
			self_parent.find('div').addClass('hide');
			self.addClass('hide');
		}
	});
		
});