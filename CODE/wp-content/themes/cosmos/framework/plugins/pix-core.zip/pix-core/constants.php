<?php
/**
 * Constants.
 * 
 * @author Swlabs
 * @package Pix-Core
 * @since 1.0
 */

defined( 'COSMOS_CORE_VERSION' )        || define( 'COSMOS_CORE_VERSION', '1.0' );
defined( 'COSMOS_CORE_SC_CATEGORY' )    || define( 'COSMOS_CORE_SC_CATEGORY', 'Cosmos' );
defined( 'COSMOS_CORE_CLASS' )          || define( 'COSMOS_CORE_CLASS', 'Cosmos_Core' );
defined( 'COSMOS_CORE_PREFIX' )         || define( 'COSMOS_CORE_PREFIX', 'cosmos_core' );

defined( 'COSMOS_CORE_URI' )            || define( 'COSMOS_CORE_URI', plugin_dir_url( __FILE__ ) );
defined( 'COSMOS_CORE_DIR' )            || define( 'COSMOS_CORE_DIR', dirname( __FILE__ ) );

defined( 'COSMOS_CORE_ASSET_URI' )      || define( 'COSMOS_CORE_ASSET_URI', COSMOS_CORE_URI . 'assets' );
defined( 'COSMOS_CORE_FRAMEWORK_DIR' )  || define( 'COSMOS_CORE_FRAMEWORK_DIR', COSMOS_CORE_DIR . '/framework' );

defined( 'COSMOS_CORE_SHORTCODE_DIR' )  || define( 'COSMOS_CORE_SHORTCODE_DIR', COSMOS_CORE_DIR . '/framework/modules/shortcode/admin/' );
defined( 'COSMOS_CORE_VENDOR_SUPPORT' ) || define( 'COSMOS_CORE_VENDOR_SUPPORT', COSMOS_CORE_DIR . '/extensions/vendor_support/' );


// Active ContactForm7 Plugin 
defined( 'COSMOS_CORE_WPCF7_ACTIVE' )       || define( 'COSMOS_CORE_WPCF7_ACTIVE', is_plugin_active( 'contact-form-7/wp-contact-form-7.php' ) );
//Active VC Plugin
defined( 'COSMOS_CORE_VC_ACTIVE' )          || define( 'COSMOS_CORE_VC_ACTIVE', is_plugin_active( 'js_composer/js_composer.php' ) );
//Active Woocommerce Plugin
defined( 'COSMOS_CORE_WOOCOMMERCE_ACTIVE' ) || define( 'COSMOS_CORE_WOOCOMMERCE_ACTIVE', is_plugin_active( 'woocommerce/woocommerce.php' ) );
defined( 'COSMOS_CORE_REVSLIDER_ACTIVE' )   || define( 'COSMOS_CORE_REVSLIDER_ACTIVE', is_plugin_active( 'revslider/revslider.php' ) );

// Default Image
defined( 'COSMOS_CORE_NO_IMG_REC' )         || define( 'COSMOS_CORE_NO_IMG_REC', COSMOS_CORE_ASSET_URI.'/images/no-image/thumb-rectangle.gif' );
defined( 'COSMOS_CORE_NO_IMG_SQUARE' )      || define( 'COSMOS_CORE_NO_IMG_SQUARE', COSMOS_CORE_ASSET_URI.'/images/no-image/thumb-square.gif' );
defined( 'COSMOS_CORE_NO_IMG_URI' )         || define( 'COSMOS_CORE_NO_IMG_URI', COSMOS_CORE_ASSET_URI.'/images/no-image/' );
defined( 'COSMOS_CORE_NO_IMG_DIR' )         || define( 'COSMOS_CORE_NO_IMG_DIR', COSMOS_CORE_DIR.'/assets/images/no-image/' );
defined( 'COSMOS_CORE_MAP_MAKER' )          || define( 'COSMOS_CORE_MAP_MAKER', COSMOS_CORE_ASSET_URI.'/images/map-maker.png' );

// Options
defined( 'COSMOS_CORE_THEME_CLASS' )        || define( 'COSMOS_CORE_THEME_CLASS', 'Cosmos' );
defined( 'COSMOS_CORE_THEME_PREFIX' )       || define( 'COSMOS_CORE_THEME_PREFIX', 'cosmos' );
defined( 'COSMOS_CORE_THEME_OPTIONS' )      || define( 'COSMOS_CORE_THEME_OPTIONS', 'cosmos_options' );
defined( 'COSMOS_CORE_POST_VIEWS' )         || define( 'COSMOS_CORE_POST_VIEWS', COSMOS_CORE_THEME_PREFIX . '_postview_number' );
defined( 'COSMOS_CORE_POST_RATES' )         || define( 'COSMOS_CORE_POST_RATES', COSMOS_CORE_THEME_PREFIX . '_postrate_number' );
defined( 'COSMOS_CORE_ADD_INLINE_CSS' )     || define( 'COSMOS_CORE_ADD_INLINE_CSS', COSMOS_CORE_THEME_PREFIX . '_add_inline_style' );

defined( 'COSMOS_CORE_TAXONOMY_CUS' )           || define( 'COSMOS_CORE_TAXONOMY_CUS', 'cosmos_taxonomy_cus' );
defined( 'COSMOS_CORE_IMPORT_TAXONOMY_ACTIVE' ) || define( 'COSMOS_CORE_IMPORT_TAXONOMY_ACTIVE', false );

// Importer
defined( 'COSMOS_CORE_CUSTOM_SIDEBAR_NAME' ) || define( 'COSMOS_CORE_CUSTOM_SIDEBAR_NAME', 'cosmos_custom_sidebar' );
defined( 'COSMOS_CORE_SAMPLE_DATA_DIR' ) || define( 'COSMOS_CORE_SAMPLE_DATA_DIR', COSMOS_CORE_DIR . '/sample-data/' );
defined( 'COSMOS_CORE_SAMPLE_DATA_URL' ) || define( 'COSMOS_CORE_SAMPLE_DATA_URL', COSMOS_CORE_URI . '/sample-data/' );
