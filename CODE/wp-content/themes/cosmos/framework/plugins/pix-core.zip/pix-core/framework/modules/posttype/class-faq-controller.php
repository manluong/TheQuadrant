<?php
/**
 * FAQ Controller
 * 
 * @since 1.0
 */

Cosmos_Core::load_class( 'Abstract' );

class Cosmos_Core_Faq_Controller extends Cosmos_Core_Abstract {

	public function save() {
		global $post;
		$post_id = $post->ID;
		parent::save();
		do_action( COSMOS_CORE_THEME_PREFIX .'_save_page', $post_id );
	}
}