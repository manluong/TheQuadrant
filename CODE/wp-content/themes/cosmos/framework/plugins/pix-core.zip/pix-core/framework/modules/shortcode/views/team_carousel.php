<?php
$model = new Cosmos_Core_Team();
$model->init( $atts );
$custom_css = "";
$sc_name    = 'team-carousel';
$sc_id      = $model->attributes['uniq_id'];
$block_class= $atts['extra_class'] . ' ' . $sc_id;

$css_animation = '';
$css_animation_class = '';
$delay_animation = 0;
$css_animation_parent = '';
$css_animation_parent_class = '';
$delay_animation_parent = 0;

if ( !empty($model->attributes['css_animation']) && !empty($model->attributes['is_parent_animation']) && $model->attributes['is_parent_animation'] != 'yes') {
	$css_animation = $model->attributes['css_animation'];
	$css_animation_class = 'animate-run';
	$delay_animation = (int) $model->attributes['delay_animation'];
}

if ( !empty($model->attributes['css_animation']) && !empty($model->attributes['is_parent_animation']) && $model->attributes['is_parent_animation'] == 'yes') {
	$css_animation_parent = $model->attributes['css_animation'].'-children';
	$css_animation_parent_class = 'animate-run';
	$delay_animation_parent = (int) $model->attributes['delay_animation'];
}


$style         = $model->attributes['style'];
$autoplay      = $model->attributes['autoplay'];
$autoplay_time = $model->attributes['autoplay_time'];
$item          = $model->attributes['item'];
$show_nav      = $model->attributes['show_nav'];
$show_dot      = $model->attributes['show_dot'];
$title_color       = $model->attributes['title_color'];
$position_color    = $model->attributes['position_color'];
$description_color = $model->attributes['description_color'];
$icon_color        = $model->attributes['icon_color'];
$icon_bg_color     = $model->attributes['icon_bg_color'];
$side_color        = $model->attributes['side_color'];
$title_quote_color = $model->attributes['title_quote_color'];
$quote_color       = $model->attributes['quote_color'];

$custom_css = '';
if ( ! empty( $title_quote_color ) ) {
    $custom_css .= sprintf('.%1$s .section_team.style-1 .carousel-items .team-wrap .info-text .info-text-title {color: %2$s;}', esc_attr($sc_id), esc_attr($title_quote_color) );
}
if ( ! empty( $quote_color ) ) {
    $custom_css .= sprintf('.%1$s .section_team.style-1 .carousel-items .team-wrap .info-text .info-text-content {color: %2$s;}', esc_attr($sc_id), esc_attr($quote_color) );
}

if ( !empty( $custom_css ) ) {
	do_action( COSMOS_CORE_ADD_INLINE_CSS, $custom_css );
}
?>

<?php 
	$html_format = '';
	/*
		%1$s is image
        %2$s is title
        %3$s is position
        %4$s is information
        %5$s is icon
        %6$s is social
        %7$s is quote
	*/
	if ($style == 1) {
		$html_format = ('
			<div class="team-wrap">
			  <div class="row">
			      <div class="col-lg-6 col-xs-12 pos">
			        <div class="slide slide-center">
			          <div class="img-slide">
			              	%1$s
			            	<div class="team-link1">%5$s</div>
			          </div>
			          <div class="slide-text">
			            %2$s
			            %3$s
			            %4$s
			            <div class="team-link2"></div>
			          </div>
			        </div>
			      </div>
			      <div class="col-lg-6 col-xs-12 info-text" >
		        	%7$s
			        <div class="social-group">%6$s</div>
			      </div>
			    </div>
			</div>
			');
	} elseif ($style == 2) {
		$html_format = ('
			<div class="team-wrap">
			    <div class="slide slide-center col-lg-3 ">
			        <div class="img-slide">
		              	%1$s
		            	<div class="team-link1">%5$s</div>
			        </div>
			        <div class="slide-text">
			            %2$s
			            %3$s
			            %4$s
			          	<div class="social-group">%6$s</div>
			          	<div class="team-link2"></div>
			        </div>
			    </div>
			</div>
			');
	}
	$html_option = array(
			'html_format' => $html_format
		);
?>

<div class="pix-shortcode <?php echo esc_attr("sc-$sc_name");?> <?php  echo esc_attr($block_class) ?> <?php echo esc_attr($css_animation_class); ?>"  data-animate="<?php echo esc_attr($css_animation); ?>" data-delay="<?php echo esc_attr($delay_animation); ?>" data-id="<?php echo esc_attr($sc_id);?>">
	<div class="section_team style-<?php  echo esc_attr($style) ?>" 
		data-type="bg"
		data-item="<?php echo esc_attr($item) ?>"
		data-autoplay="<?php echo esc_attr($autoplay) ?>"
		data-shownav="<?php echo esc_attr($show_nav) ?>" 
		data-showdots="<?php echo esc_attr($show_dot) ?>"
		data-timeplay="<?php echo esc_attr(floatval($autoplay_time)) ?>"
		>
		<?php if ($style == 1) { ?>
			<div class="carousel">
	        	<div class="carousel-items">
					<?php $model->render_sc($html_option); ?>
	        	</div>
	    	</div>
    	<?php } elseif ($style == 2) { ?>
	    	<div class="rowcarousel">
		        <div class="carousel">
					<div class="carousel-items">
						<?php $model->render_sc($html_option); ?>
					</div>
		            <?php if ($show_nav == 'true') { ?>
		            <div class="carousel-prev" data-type="icon"><i class="fa fa-angle-left" aria-hidden="true"></i></div>
		            <div class="carousel-next" data-type="icon"><i class="fa fa-angle-right" aria-hidden="true"></i></div>
		            <?php } ?>
				</div>
			</div>
		<?php } ?>
	</div>
</div>