<?php
$uniq_id = 'sc-coming-soon-'.esc_attr( $id );
$custom_css = '';
$end_date = !empty($end_date) ? $end_date : 0;
$title = !empty($title) ? $title : esc_html__( 'Coming Soon', 'pix-core' );
$header_logo_url  = Cosmos::get_option( 'pix-logo-header', 'url' );
if( empty($header_logo_url) ) {
	$header_logo_data = '<span>' .get_bloginfo( 'name', 'display' ) . '</span>';
} else {
	$header_logo_data = '<img id="logo" src="'. esc_url($header_logo_url).'" alt="logo">';
}

$image_background = wp_get_attachment_image_src($image_background, 'full', false);
if ( ! empty ($image_background) ) { 
    $image_src = $image_background[0];
    $image_width = $image_background[1];
    $image_height = $image_background[2];
} else {
    $image_src = NULL;
    $image_width = NULL;
    $image_height = NULL;
}

if( !empty( $title_color ) ){
	$custom_css .= sprintf('.%1$s .section_comming_soon .col-center p.title { color: %2$s;}', esc_attr($uniq_id), esc_attr($title_color) );
}
if( !empty( $description_color ) ){
	$custom_css .= sprintf('.%1$s .section_comming_soon .col-center p.content { color: %2$s;}', esc_attr($uniq_id), esc_attr($description_color) );
}

if ( ! empty( $input_color) ) {
	$custom_css .= sprintf('.%1$s .section_comming_soon .sign-up .comming-soon-input { color: %2$s;}', esc_attr($uniq_id), esc_attr($input_color) );
}
if ( ! empty( $input_border_color) ) {
	  $custom_css .= sprintf('.%1$s .section_comming_soon .sign-up .comming-soon-input {border-color: %2$s;}', esc_attr($uniq_id), esc_attr($input_border_color) );
}
if ( ! empty( $input_placeholder_color) ) {
	$custom_css .= sprintf('.%1$s .section_comming_soon .sign-up .comming-soon-input::-webkit-input-placeholder {color:%2$s;}, .%1$s .section_comming_soon .sign-up .comming-soon-input:-moz-placeholder {color:%2$s;}, .%1$s .section_comming_soon .sign-up .comming-soon-input::-moz-placeholder {color:%2$s;}, .%1$s .section_comming_soon .sign-up .comming-soon-input:-ms-input-placeholder {color:%2$s;}', esc_attr($uniq_id), esc_attr($input_placeholder_color) );
}
if ( ! empty( $input_bg_color) ) {
	$custom_css .= sprintf('.%1$s .section_comming_soon .sign-up .comming-soon-input {background-color: %2$s;}', esc_attr($uniq_id), esc_attr($input_bg_color) );
}
if ( ! empty( $button_color) ) {
    $custom_css .= sprintf('.%1$s .section_comming_soon .sign-up .comming-soon-button { color: %2$s;}', esc_attr($uniq_id), esc_attr($button_color) );
}
if ( ! empty( $button_bg_color) ) {
    $custom_css .= sprintf('.%1$s .section_comming_soon .sign-up .comming-soon-button { background-color: %2$s; border:solid 1px %2$s;}', esc_attr($uniq_id), esc_attr($button_bg_color) );
}
if( !empty( $image_src ) ){
	$custom_css .= sprintf('.%1$s { background: url("%2$s") no-repeat; background-size: cover; height: 100%%; }', esc_attr($uniq_id), esc_attr($image_src) );
}

if ( !empty( $custom_css ) ) {
	do_action( COSMOS_CORE_ADD_INLINE_CSS, $custom_css );
}
$input_sign_up_id = 'input=sign-up-' . esc_attr( $id );
$style_comming_soon = ($style == 2) ? 'style-2' : 'style-4';
$style_sign_up = ($style == 2) ? 'content' : '';

$countdown_sc = '';
if ( !empty($countdown_end_date) ) { 
	$countdown_style = ($style == 2) ? '1' : '2';
	$countdown_sc = sprintf( '[pixcore_count_down_sc style="%1$s" end_date="%2$s" block_title_color="%3$s" block_number_color="%4$s" border_color="%5$s"]',
							esc_attr( $countdown_style ),
							esc_attr( $countdown_end_date ),
							esc_attr( $countdown_title_color ),
							esc_attr( $countdown_number_color ),
							esc_attr( $countdown_border_color )
						);
	$countdown_sc_html = do_shortcode( $countdown_sc ); 
 }

$social_sc = sprintf( '[pixcore_social_sc style="%1$s" social="%2$s" icon_color="%3$s" icon_color_hover="%4$s" border_icon_color="%5$s" bg_color="%6$s" bg_color_hover="%7$s" align="%8$s"]',
						esc_attr( $social_style ),
						esc_attr( $social_data ),
						esc_attr( $social_icon_color ),
						esc_attr( $social_icon_color_hover ),
						esc_attr( $social_border_icon_color ),
						esc_attr( $social_bg_color ),
						esc_attr( $social_bg_color_hover ),
						esc_attr( $social_align )
					);
$social_sc_html = do_shortcode( $social_sc ); 
$form = '';
if (COSMOS_NEWSLETTER_ACTIVE) { 
    global $newsletter;
    $form = NewsletterSubscription::instance()->get_form_javascript();
    $form .= '<form action="' . home_url('/') . '?na=s" onsubmit="return newsletter_check(this)" method="post">';
    	$form .= '<input class="comming-soon-input" type="text" required name="ne" placeholder="'.esc_attr($input_email_placeholder).'" onclick="if (this.defaultValue==this.value) this.value=\'\'" onblur="if (this.value==\'\') this.value=this.defaultValue"/>';
    	$form .= '<button type="submit" class="comming-soon-button" data-type="button">'.esc_html($button_text).'</button>';
    $form .= '</form>';
	$form = $newsletter->replace($form);
} else {
	$form .= '<input class="comming-soon-input" type="text" placeholder="' . esc_attr($input_email_placeholder) . '"/>';
	$form .= '<button class="comming-soon-button" type="submit">' . esc_html($button_text) . '</button>';
}

?>

<div id="<?php echo esc_attr($uniq_id)?>" class="pix-shortcode sc-coming-soon <?php echo esc_attr($uniq_id).' '.esc_attr( $extra_class )?> animate-run" data-animate="<?php echo esc_attr($css_animation); ?>" data-delay="<?php echo (int) esc_attr($delay_animation); ?>">
	<div class="section_comming_soon <?php echo esc_attr( $style_comming_soon ) ?>">
		<?php if ( !empty($has_logo) ) { ?>
			<div class="logo-comming-soon"><?php echo wp_kses_post($header_logo_data);?></div>
		<?php } ?>
		<div class="col-center">
			<?php if ( !empty($title) ) { ?>
				<p class="title mg-t90">
					<?php echo esc_html($title); ?>
				</p>
			<?php } ?>
			<?php if ( !empty($description) ) { ?>
				<p class="content mg-t20">
					<?php echo esc_html($description); ?>
				</p>
			<?php } ?>
			<?php if ($style == 2) { ?>
				<?php if ( !empty($countdown_end_date) ) { ?>
				<div class="mg-t70">
					<?php echo do_shortcode( $countdown_sc ); ?>
				</div>
				<?php } ?>
				<div class="mg-t90">
					<div class="sign-up row-eq-height <?php echo esc_attr( $style_sign_up ) ?>">
						<?php printf( '%s', $form ); ?>
			        </div>
		        </div>
				<div class="mg-t70">
					<?php echo do_shortcode( $social_sc ); ?>
				</div>
			<?php } else { ?> 
				<div class="mg-t70">
					<div class="col-lg-6 col-xs-12">
							<?php echo do_shortcode( $countdown_sc ); ?>
					</div>
					<div class="col-lg-6 col-xs-12">
						<div class="sign-up row-eq-height">
							<?php printf( '%s', $form ); ?>
				        </div>
				        <div class="mg-t40">
							<?php echo do_shortcode( $social_sc ); ?>
						</div>
					</div>
				</div>
			<?php } ?>
			<div class="pd-t140"></div>
		</div>
	</div>
</div>