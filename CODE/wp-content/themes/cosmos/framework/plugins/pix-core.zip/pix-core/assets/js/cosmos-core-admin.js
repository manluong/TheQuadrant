jQuery(document).ready(function($) {
	"use strict";
	//-------------posttype slider----------------
	jQuery.fn.pixCom.pixcore_slider();
	//------------------tool tip------------------------
	jQuery.fn.pixCom.pixcore_tooltip();
	//--------------Page template & mbox------------------
	//Set link for page
	jQuery.fn.pixCom.pixcore_link();
	// Show or hide metabox

	var pixPageTemplate = $("#page_template"),
	pixMboxes = $(".pix-mbox"),
	pixTabMboxes = $(".pix-tab-mbox"),
	pixCurrent,
	pixTpValues = [];

	function pixShow(selected) {
		var tab_active = "", active = ".pix-mbox-active-all";
		if (selected) {
			tab_active = ".pix-tab-template-"+selected;
			active += ",.pix-mbox-active-"+selected;
		}
		pixMboxes.parents(".postbox").hide();
		pixMboxes.filter(active).parents(".postbox").show();
		$(".pix-tab-mbox .pix-tab-template").addClass('hide');
		$(".pix-tab-mbox " + tab_active ).removeClass('hide');
		$(".pix-tab-mbox .pix-tab").removeClass('active');
		$(".pix-tab-mbox .tab-content").hide();
		if( selected != 'default' && $(tab_active).length > 0 ) {
			$(".pix-tab-mbox " + tab_active ).addClass('active');
			$(".pix-tab-mbox " + tab_active ).show();
		} else {
			$(".pix-tab-general").addClass('active');
			$(".pix-tab-general").show();
		}
	}
	function pixGetTpClass(template) {
		template = template.replace("page-templates/","");;
		return template.replace(".php","");
	}
	function pixGetTpValue(idx,el) {
		pixTpValues[idx]=pixGetTpClass($(el).attr("value"));
	}
	function pixTpChange(el) {
		var selected = pixGetTpClass(pixPageTemplate.val());
		if (selected != pixCurrent) {
			pixCurrent = selected;
			pixShow(selected);
		}
	}
	if (pixPageTemplate.length > 0) {
		pixPageTemplate
		.find("option")
		.each(pixGetTpValue)
		.end()
		.change(pixTpChange)
		.triggerHandler("change");
	}
	$(".pix-mbox-blog-column").change(function() {
			if( $(this).val() != '1') {
				$(".pix-mbox-blog-grid").show();
			} else {
				$(".pix-mbox-blog-grid").hide();
			}

		}).triggerHandler("change");

	//Select radio (image format)
	$('.pix-mbox-radio-row label').click(function() {
			$(this).parent().find('label').removeClass('pix-image-select-selected');
			$(this).addClass('pix-image-select-selected');
		});
	$('.pix-mbox-radio-row input').change(function() {
			if ($(this).is(':checked')) {
				$('label[for="' + $(this).attr('id') + '"]').click();
			}
		});
	// images in label ie fix
	$(document).on('click', 'label img', function() {
			$('#' + $(this).parents('label').attr('for')).click();
		});
	//Check box
	$('.pix-mbox-custom-bg-row input[type=checkbox]').click(function() {
			var divcolor = $(this).parent().parent().find('div');
			if ($(this).is(':checked')) {
				divcolor.removeClass('hide');
			} else {
				divcolor.addClass('hide');
			}
		});

	if(0 == $("#post-body-content > *").length) {
		$("#post-body-content").hide();
	}

	//  Tab Panel in page option
	$('.tab-list a').on('click', function(e){
			e.preventDefault();
			var tab_id = $(this).attr('href');
			var tab_content = $(this).parents('.tab-panel').find('.tab-container ' + '#' + tab_id);

			$(this).parents('.tab-list').find('li').removeClass('active');
			$(this).parent().addClass('active');

			$(this).parents('.tab-panel').find('.tab-container .tab-content.active').hide();
			tab_content.fadeIn().addClass('active');
		});
	// display / hide when default setting checkbox checked
	$('.pix-footer-option').live('click', function(){
			if ($(this).is(':checked')) {
				$("#div_pix_footer_option").addClass('hide');
			} else {
				$("#div_pix_footer_option").removeClass('hide');
			}
		});
	$('.pix-sidebar-option').live('click', function(){
			if ($(this).is(':checked')) {
				$("#div_pix_sidebar_option").addClass('hide');
			} else {
				$("#div_pix_sidebar_option").removeClass('hide');
			}
		});
	$('.pix-general-option').live('click', function(){
			if ($(this).is(':checked')) {
				$("#div_pix_general_option").addClass('hide');
			} else {
				$("#div_pix_general_option").removeClass('hide');
			}
		});
	$('.pix-header-option').live('click', function(){
			if ($(this).is(':checked')) {
				$("#div_pix_header_option").addClass('hide');
			} else {
				$("#div_pix_header_option").removeClass('hide');
			}
		});
	$('.pix-menu-option').live('click', function(){
			if ($(this).is(':checked')) {
				$("#div_pix_menu_option").addClass('hide');
			} else {
				$("#div_pix_menu_option").removeClass('hide');
			}
		});
	$('.pix-page-title-option').live('click', function(){
			if ($(this).is(':checked')) {
				$("#div_pix_page_title_option").addClass('hide');
			} else {
				$("#div_pix_page_title_option").removeClass('hide');
			}
		});
	$('.pix-page-title-type-display').live('change', function(){
			if ($(this).val() != '') {
				$("#div_page_title_type_display").removeClass('hide');
			} else {
				$("#div_page_title_type_display").addClass('hide');
				$("#div_page_title_type_display").find('input.title_custom_content').val('');
			}
		});
	//--------------End page template & mbox-------
	//video post type
	$("#pixcore_mbox_video_type").change(function(){
			if ( $(this).val() === 'vimeo'){
				$(this).parents('.pix-video-meta').find('.vimeo-id').addClass('active');
				$(this).parents('.pix-video-meta').find('.video_upload').removeClass('active');
				$(this).parents('.pix-video-meta').find('.youtube-id').removeClass('active');
				$(this).parents('.pix-video-meta').find('.video-option').addClass('active');
				$(this).parents('.pix-video-meta').find('.video-option').find('.hide-control').addClass('hide');
			}
			else if ( $(this).val() === 'youtube'){
				$(this).parents('.pix-video-meta').find('.youtube-id').addClass('active');
				$(this).parents('.pix-video-meta').find('.video_upload').removeClass('active');
				$(this).parents('.pix-video-meta').find('.vimeo-id').removeClass('active');
				$(this).parents('.pix-video-meta').find('.video-option').addClass('active');
				$(this).parents('.pix-video-meta').find('.video-option').find('.hide-control').removeClass('hide');
			}
			else if( $(this).val() === 'video-upload'){
				$(this).parents('.pix-video-meta').find('.video_upload').addClass('active');
				$(this).parents('.pix-video-meta').find('.vimeo-id').removeClass('active');
				$(this).parents('.pix-video-meta').find('.youtube-id').removeClass('active');
				$(this).parents('.pix-video-meta').find('.video-option').addClass('active');
			}
			else{
				$(this).parents('.pix-video-meta').find('.vimeo-id').removeClass('active');
				$(this).parents('.pix-video-meta').find('.youtube-id').removeClass('active');
				$(this).parents('.pix-video-meta').find('.video_upload').removeClass('active');
				$(this).parents('.pix-video-meta').find('.video-option').removeClass('active');
			}
		})

	if($('.pix_upload_button').length ) {
		window.uploadfield = '';
		$('.pix_upload_button').live('click', function() {
				window.uploadfield = $('.textbox-url-video', $(this).parents( '.upload' ));
				tb_show('Upload', 'media-upload.php?type=image&TB_iframe=true', false);
				return false;
			});
		window.send_to_editor_backup = window.send_to_editor;
		window.send_to_editor = function(html) {
			if(window.uploadfield) {
				if($('img', html).length >= 1) {
					var image_url = $('img', html).attr('src');
				} else {
					var image_url = $($(html)[0]).attr('href');
				}
				$(window.uploadfield).val(image_url);
				window.uploadfield = '';
				tb_remove();
			} else {
				window.send_to_editor_backup(html);
			}
		}
	}
	//upload video in post and post type video
	if ( $('#pixcore_mbox_video_type').val() === 'video-upload' ){
		$('.pix-video-meta').find('.video_upload').addClass('active');
	}
	/* Demo Importer */
	jQuery('.td-progress-show-details').click(function(){
			var textShow = jQuery(this).data('text-show');
			var textHide = jQuery(this).data('text-hide');
			if ( jQuery(this).hasClass('opened') == true ) {
				jQuery('div.td-demo-msg').hide();
				jQuery(this).removeClass('opened').text(textShow);
			} else {
				jQuery('div.td-demo-msg').show();
				jQuery(this).addClass('opened').text(textHide);
			}
		});


	$(document).ready(function() {
		$(".pix-select2").select2();
		function formatState (state) {
			if (!state.id) {
				return state.text;
			}
			var $state = $(
				'<span><i class="' + state.element.value.toLowerCase() + '"></i>  '+ state.text +' </span>'
			);
			return $state;
		};
		$(".pix-select2-icon").select2({
			templateResult: formatState
		})
	});

});