<?php
$sc_controller = new Cosmos_Core_Shortcodes_Controller();
$column = array(
	esc_html__( 'One', 'pix-core' )				=> '1',
	esc_html__( 'Two', 'pix-core' )				=> '2',
	esc_html__( 'Three', 'pix-core' )			=> '3',
	esc_html__( 'Four', 'pix-core' )			=> '4',
);

$method = array(
	esc_html__( 'Category', 'pix-core' ) => 'cat',
	esc_html__( 'Teams', 'pix-core' )    => 'team'
);

$sort_by    = Cosmos_Core_Params::get('sort-other') ;

$yes_no     = array(
	esc_html__('Yes', 'pix-core') => 'yes',
	esc_html__('No', 'pix-core')  => 'no'
);
$true_false = array(
	esc_html__('Yes', 'pix-core') => 'true',
	esc_html__('No', 'pix-core')  => 'false'
);
$pagination  = array(
    esc_html__('No', 'pix-core')         => 'no',
    esc_html__('Load Page', 'pix-core')  => 'yes',
);
// get Team categories
$taxonomy   = 'cosmos_team_cat';
$params_cat = array('empty'=> esc_html__( '-- All Team Categories --', 'pix-core' ) );
$categories = Cosmos_Core_Com::get_tax_options2slug( $taxonomy, $params_cat );
// get all team
$args       = array('post_type' => 'cosmos_team');
$options = array('empty'=> esc_html__( '-- None --', 'pix-core' ) );
$team_list  = Cosmos_Core_Com::get_post_title2id( $args, $options );
$params = array(
	array(
		'admin_label'	=> true,
		'type'        	=> 'dropdown',
		'heading'     	=> esc_html__( 'Column', 'pix-core' ),
		'param_name'  	=> 'column',
		'value'       	=> $column,
		'std'      		=> '3',
		'description' 	=> esc_html__( 'Choose column number will be displayed.', 'pix-core' )
	),
    array(
        'type'            => 'dropdown',
        'heading'         => esc_html__( 'Show Pagination', 'pix-core' ),
        'param_name'      => 'pagination',
        'value'           => $pagination,
        'std'           => 'yes',
        'description'     => esc_html__( 'Show or hide pagination.', 'pix-core' ),
    ),
	array(
        'type'       => 'textfield',
        'heading'    => esc_html__( 'Description Length', 'pix-core' ),
        'param_name' => 'description_length',
        'value'      => '',
        'description'=> esc_html__( 'Set length for description', 'pix-core' ),
    ),
    array(
        'type'       => 'textfield',
        'heading'    => esc_html__( 'Limit Posts', 'pix-core' ),
        'param_name' => 'limit_post',
        'value'      => '-1',
        'description'=> esc_html__( 'Add limit posts per page. Set -1 or empty to show all.', 'pix-core' ),
    ),
    array(
        'type'       => 'textfield',
        'heading'    => esc_html__( 'Offset Posts', 'pix-core' ),
        'param_name' => 'offset_post',
        'value'      => '0',
        'description'=> esc_html__( 'Enter offset to pass over posts. If you want to start on record 6, using offset 5', 'pix-core' )
    ),
    array(
        'type'       => 'dropdown',
        'heading'    => esc_html__( 'Sort By', 'pix-core' ),
        'param_name' => 'sort_by',
        'value'      => $sort_by,
        'description'=> esc_html__( 'Select order to display list properties.', 'pix-core' ),
    ),
	// Filter
    array(
        'type'       => 'dropdown',
        'heading'    => esc_html__( 'Display by', 'pix-core' ),
        'param_name' => 'method',
        'value'      => $method,
        'std'        => 'cat',
        'description'=> esc_html__( 'Choose Team category or special Team to display.',  'pix-core'  ),
        'group'      => esc_html__('Filter', 'pix-core')
    ),
    array(
        'type'       => 'param_group',
        'heading'    => esc_html__( 'Category', 'pix-core' ),
        'param_name' => 'category_list',
        'callbacks'   => array(
           'after_add' => 'vcChartParamAfterAddCallback'
        ),
        'params'    => array(
            array(
                'type'       => 'dropdown',
                'admin_label'=> true,
                'heading'    => esc_html__( 'Add Category', 'pix-core' ),
                'param_name' => 'category_slug',
                'value'      => $categories,
                'description'=> esc_html__( 'Choose special category to filter', 'pix-core'  )
            ),
        ),
        'value'      => '',
        'dependency' => array(
            'element'   => 'method',
            'value'     => array('cat' )
        ),
        'description'=> esc_html__( 'Default no filter by category.', 'pix-core' ),
        'group'      => esc_html__('Filter', 'pix-core')
    ),
    array(
        'type'       => 'param_group',
        'heading'    => esc_html__( 'Team List', 'pix-core' ),
        'param_name' => 'team_list',
        'callbacks'   => array(
           'after_add' => 'vcChartParamAfterAddCallback'
        ),
        'params'     => array(
            array(
                'type'       => 'dropdown',
                'admin_label'=> true,
                'heading'    => esc_html__( 'Add Team', 'pix-core' ),
                'param_name' => 'team_id',
                'value'      => $team_list,
                'description'=> esc_html__( 'Choose Team to show', 'pix-core'  )
            ),
        ),
        'value'      => '',
        'dependency' => array(
            'element'=> 'method',
            'value'  => array('team')
        ),
        'description'=> esc_html__( 'Default empty.', 'pix-core' ),
        'group'      => esc_html__('Filter', 'pix-core')
    ),
	// Custom color
	array(
		"type"        => "colorpicker",
		"class"       => "",
		"heading"     => esc_html__( "Title Color", 'pix-core' ),
		"param_name"  => "title_color",
		"description" => esc_html__( "Choose title color.", 'pix-core' ),
		'group'       => esc_html__('Custom Color', 'pix-core'),
	),
	array(
		"type"        => "colorpicker",
		"class"       => "",
		"heading"     => esc_html__( "Description Color", 'pix-core' ),
		"param_name"  => "description_color",
		"description" => esc_html__( "Choose description color.", 'pix-core' ),
		'group'       => esc_html__('Custom Color', 'pix-core'),
	),
	array(
		"type"        => "colorpicker",
		"class"       => "",
		"heading"     => esc_html__( "Position Color", 'pix-core' ),
		"param_name"  => "position_color",
		"description" => esc_html__( "Choose position color.", 'pix-core' ),
		'group'       => esc_html__('Custom Color', 'pix-core'),
	),
	array(
		"type"        => "colorpicker",
		"class"       => "",
		"heading"     => esc_html__( "Icon Color", 'pix-core' ),
		"param_name"  => "icon_color",
		"description" => esc_html__( "Choose icon color.", 'pix-core' ),
		'group'       => esc_html__('Custom Color', 'pix-core'),
	),
	array(
		"type"        => "colorpicker",
		"class"       => "",
		"heading"     => esc_html__( "Icon Background Color", 'pix-core' ),
		"param_name"  => "icon_bg_color",
		"description" => esc_html__( "Choose icon Background color.", 'pix-core' ),
		'group'       => esc_html__('Custom Color', 'pix-core'),
	),
	array(
		"type"        => "colorpicker",
		"class"       => "",
		"heading"     => esc_html__( "Side Color", 'pix-core' ),
		"param_name"  => "side_color",
		"description" => esc_html__( "Choose side color.", 'pix-core' ),
		'group'       => esc_html__('Custom Color', 'pix-core'),
	),
	array(
		'type'            => 'textfield',
		'heading'         => esc_html__( 'Extra Class', 'pix-core' ),
		'param_name'      => 'extra_class',
		'description'     => esc_html__( 'Style particular content element differently - add a class name and refer to it in custom CSS.', 'pix-core' )
	),
    $sc_controller->cosmos_animation_style(),
    $sc_controller->cosmos_animation_delay(),
    array(
        'type'        => 'dropdown',
        'heading'     => esc_html__( 'Animation To Children', 'pix-core' ),
        'param_name'  => 'is_parent_animation',
        'value'       => array(
                            esc_html__('Yes', 'pix-core')=> 'yes',
                            esc_html__('No', 'pix-core') => 'no',
                        ),
        'std'         => 'no',
        'description' => esc_html__('Apply run animation to children element'),
        'group'       => esc_html__('Animation', 'pix-core'),
    )  
);

vc_map(
	array(
		'name'          => esc_html__( 'PIX Team List', 'pix-core' ),
		"base"			=> "pixcore_team_list_sc",
		"class"			=> "pixcore-sc",
		"category"		=> COSMOS_CORE_SC_CATEGORY,
		'icon'			=> 'icon-pixcore_team_list_sc',
		'description'   => esc_html__( 'A list of team.', 'pix-core' ),
		"params"		=> $params
	)
);