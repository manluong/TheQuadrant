<?php
$prefix = 'cosmos_testi_';
?>
<div class="pix-custom-meta" >
	<div class="pix-meta-row" >
		<div class="pix-desc">
			<span><?php esc_html_e( 'Position', 'pix-core' );?></span>
			<span class="f-right"><?php $this->tooltip_html( esc_html__( 'Position of testimonial.', 'pix-core' ) );?></span>
		</div>
		<div class="pix-field">
			<?php echo ( $this->text_field( $prefix .'meta['. $prefix .'position]',
					$this->get_field( $data_meta, 'position' ),
					array( 'class' => 'pix-block' ) ) );?>
		</div>
	</div>
	<div class="pix-meta-row" >
		<div class="pix-desc">
			<span><?php esc_html_e( 'Quote', 'pix-core' );?></span>
			<span class="f-right"><?php $this->tooltip_html( esc_html__( 'Quote of testimonial.', 'pix-core' ) );?></span>
		</div>
		<div class="pix-field">
			<?php echo ( $this->text_area( $prefix .'meta['.$prefix.'quote]',
					$this->get_field( $data_meta, 'quote' ),
					array('class'=>'pix-block','rows' => '6') ) );?>
		</div>
	</div>
</div>