<?php
class Cosmos_Core_Timeline extends Cosmos_Core_Custom_Post_Model {

	private $post_type = 'cosmos_timeline';
	private $post_taxonomy = 'cosmos_timeline_cat';
	private $html_format;

	public function __construct() {
		$this->meta_attributes();
		$this->set_meta_attributes();
		$this->post_meta_prefix = $this->post_type . '_';
		$this->taxonomy_cat = $this->post_taxonomy;
	}

	public function meta_attributes() {
		$meta_atts = array(
			'timeline_images' => esc_html__('Timeline Images', 'pix-core'),
			'date'            => esc_html__('Date', 'pix-core'),
			'description'     => esc_html__('Description', 'pix-core'),
		);
		$this->post_meta_atts = $meta_atts;
	}

	public function set_meta_attributes()
    {
        $meta_arr = array();
        $meta_label_arr = array();
        foreach ( $this->post_meta_atts as $att => $name ) {
            $key = $att;
            $meta_arr[$key] = '';
            $meta_label_arr[$key] = $name;
        }
        $this->post_meta_def = $meta_arr;
        $this->post_meta = $meta_arr;
        $this->post_meta_label = $meta_label_arr;
    }
    public function init( $atts = array(), $query_args = array() )
    {
        // set attributes
        $default_atts = array(
            'layout'     => 'timeline',
            'method'     => 'cat',
            'limit_post' => '',
            'offset_post'=> '',
            'sort_by'    => 'timeline_newest',
            'post_ids'    => '',
            'keyword'    => '',
        );
        $atts = array_merge( $default_atts, $atts );
        if ( is_tax() ) {
            $currentObject = get_queried_object();
            if ( !empty($currentObject) && is_object($currentObject) ) {
                $this->taxonomy_cat = $currentObject->taxonomy;
            }
        }
        if ( $atts['method'] == 'cat' ) {
            $atts['post_ids'] = $this->parse_cat_slug_to_post_id( $this->taxonomy_cat, $atts['category_slug'], $this->post_type );
        }
        elseif ($atts['method'] == 'post') {
            $atts['post_ids'] = $this->parse_list_to_array( 'post_id', $atts['post_list'] );
        }

        $timeline_order = array();
        // if ( !empty($atts['sort_by'])) {
        //     if($atts['sort_by'] == 'timeline_newest'){
        //         $atts['meta_key'] = $this->post_meta_prefix.'date';
        //         $atts['meta_type'] = 'DATE';
        //         $atts['orderby'] = 'meta_value';
        //         $atts['order'] = 'DESC';

        //         // $timeline_order = array(
        //         //     'metakey' =>  $this->post_meta_prefix.'date',
        //         //     'orderby' => 'meta_value',
        //         //     'order' => 'DESC',
        //         // );
        //     }
        //     if($atts['sort_by'] == 'timeline_lastes'){
        //         $timeline_order = array(
        //             'metakey' =>  $this->post_meta_prefix.'date',
        //             'orderby' => 'meta_value',
        //             'order' => 'ASC',
        //         );
        //     }
        // }
        $this->attributes = $atts;
        // query
        $default_args = array(
            'post_type'=> $this->post_type,
        );
        $query_args = array_merge( $default_args, $query_args );
        // setting
        $this->setting( $query_args);
    }
    public function setting( $query_args )
    {
        if ( !isset( $this->attributes['uniq_id'] ) ) {
            $this->attributes['uniq_id'] = $this->post_type . '-' .Cosmos_Core::make_id();
        }
        // query
        $this->query = $this->get_query( $query_args, $this->attributes );
        $this->post_count = 0;
        if ( $this->query->have_posts() ) {
            $this->post_count = $this->query->post_count;
        } else {
            get_template_part( 'inc/content', 'none-search' );
        }
        $this->get_thumb_size();
        $this->set_responsive_class();
        // image size
        $custom_css = $this->add_custom_css();
        if ( $custom_css ) {
            do_action( COSMOS_CORE_ADD_INLINE_CSS, $custom_css );
        }
    }
    public function reset()
    {
        wp_reset_postdata();
    }
    public function set_responsive_class( $atts = array() )
    {   if(empty($this->attributes['column'])){
            return;
        }
        $class = '';
        $column= $this->attributes['column'];
        $def   = array(
           	'1'=> 'column-1 col-xs-12',
			'2'=> 'column-2 col-xs-12 col-sm-6',
			'3'=> 'column-3 col-xs-12 col-sm-6 col-md-4',
			'4'=> 'column-4 col-xs-12 col-sm-6 col-md-3',
        );

        if ( $column && isset($def[$column])) {
            return $this->attributes['responsive-class'] = $def[$column];
        } else {
            return $this->attributes['responsive-class'] = $def['2'];
        }
    }
    public function add_custom_css()
    {
        $sc_id      = $this->attributes['uniq_id'];
        $custom_css = '';
        if (!empty( $this->attributes['title_color'])) {
            $custom_css .= sprintf( '.%1$s .section_timeline.style-1 .timeline-title{color: %2$s}',
                esc_attr( $sc_id ),
                esc_attr( $this->attributes['title_color'] )
            );
        }
        if (!empty( $this->attributes['excerpt_color'])) {
            $custom_css .= sprintf( '.%1$s .section_timeline.style-1 .timeline-text {color: %2$s}',
                esc_attr( $sc_id ),
                esc_attr( $this->attributes['excerpt_color'] )
            );
        }
        if (!empty( $this->attributes['button_color'])) {
            $custom_css .= sprintf( '.%1$s .section_timeline.style-1 .timeline-button{background-color: %2$s}',
                esc_attr( $sc_id ),
                esc_attr( $this->attributes['button_color'] )
            );
        }
        if (!empty( $this->attributes['button_text_color'])) {
            $custom_css .= sprintf( '.%1$s .section_timeline.style-1 .timeline-button{color: %2$s}',
                esc_attr( $sc_id ),
                esc_attr( $this->attributes['button_text_color'] )
            );
        }
        if (!empty( $this->attributes['button_color_hv'])) {
            $custom_css .= sprintf( '.%1$s .section_timeline.style-1 .timeline-button:hover{background-color: %2$s}',
                esc_attr( $sc_id ),
                esc_attr( $this->attributes['button_color_hv'] )
            );
        }
        return $custom_css;
    }
    public function set_default_options( & $html_options = array() )
    {
        $defaults = array(
            'title_format'=> '%1$s',
            'image_format'=> '%1$s',
            'description_format'=> '%1$s',
        );
        $html_options = array_merge( $defaults, $html_options );
        return $html_options;
    }
    public function get_thumb_size()
    {
        $params = Cosmos_Core_Params::get( 'block_image_size', $this->attributes['layout'] );
        $this->attributes['thumb-size'] = Cosmos_Core_Util::get_thumb_size( $params, $this->attributes );
    }

    /* Render */
    public function render_timeline_sc( $html_options = array() )
    {
		$html_options['thumb_class'] = 'img-responsive img-full';
        $this->html_format = $this->set_default_options( $html_options );
        if ( $this->query->have_posts() ) {
            $_class = array('left','right');
            $key=0;
            while ( $this->query->have_posts() ) {
                $this->query->the_post();
                $this->loop_index();
                $gallery = '';
				if(get_post_format() == 'gallery'){
					$gallery = $this->get_meta_galery();
				}elseif(get_post_format() == 'video'){
					$gallery = $this->get_meta_video();
				}else{
					$gallery = $this->get_featured_image($html_options);
				}
                cosmos_printf( $html_options['html_format'],
                    array(
                        'IMAGE'         => $gallery,
                        'FEATURED_IMAGE'=> $this->get_featured_image($html_options),
                        'CLASS'         => $_class[($key%2)],
                        'DATE'          => $this->get_timeline_date(),
                        'TITLE'         => $this->get_title( $html_options),
                        'TITLE_DEFAULT' => get_the_title(),
                        'EXCERPT'       => $this->get_meta_description(),
                        'CONTENT'       => $this->get_content($html_options),
                        'BUTTON'        => $this->get_button_more_info(),

                    )
                );
                $key++;
            }
            $this->reset();
        }

    }


    public function render_slide_widget( $html_options = array() ) {
        $html_options['price_format'] = '<div class="product-title">%1$s</div>';
        $this->html_format = $this->set_default_options( $html_options );
        $custom_css = '';
        if( $this->query->have_posts() ) {
            while ( $this->query->have_posts() ) {
                $this->query->the_post();
                $this->loop_index();
                $html_options = $this->html_format;

                $image_url = '';
                $classItem = 'item-'.$this->post_id;
                if ( $this->has_thumbnail ) {
                    $image_url = $this->get_feature_image_url();
                    if ( !empty($image_url) ) {
                        $custom_css .= sprintf( '.%1$s .%2$s { background-image: url(%3$s); }',
                                                esc_attr( $this->attributes['uniq_id'] ),
                                                esc_attr( $classItem ),
                                                esc_attr( $image_url )
                        );
                    }
                } else {
                    continue;
                }
                printf( $html_options['html_format'],
                    $this->get_title($html_options),
                    $this->get_price($this->html_format),
                    $this->get_button_more_info(),
                    $classItem
                );
            }
            $this->reset();
            if ( $custom_css ) {
                do_action( Cosmos_Core_ADD_INLINE_CSS, $custom_css );
            }
        }
    }

    /*custom function*/

    //Show title default}
    public function get_timeline_date(){
        $format = '<div class="timeline-date">
    			    <span class="day">%1$s</span>
    			    <span class="month">%2$s</span>
    			    <span class="year">%3$s</span>
    	        </div>';
        if(isset($this->html_format['date_format'])){
            $format = $this->html_format['date_format'];
        }
        if(empty($this->post_meta['date'])){
            return;
        }
        $val = $this->post_meta['date'];
        $date = strtotime($val);
        $day = date('d', $date);
        $month = date('M', $date);
        $year = date('Y', $date);
        $out = sprintf($format,$day, $month, $year);
        return $out;
    }
    public function get_button_more_info()
    {
        $format = ('<a class="timeline-button item">%1$s</a>');
        if ( isset($this->html_format['button_format']) ) {
            $format = $this->html_format['button_format'];
        }
        $out    = '';
        if ( !empty($this->attributes['button_text']) ) {
            $out = sprintf(
                $format,
                esc_html($this->attributes['button_text'])
            );
        }
        return $out;
    }
    public function get_meta_description($trim = true){
    	if(empty($this->attributes['show_content']) && $trim == true){
			return;
		}
		$format = '%1$s';
		if ( isset($this->html_format['description_format']) ){
			$format = $this->html_format['description_format'];
		}
		$val = $this->post_meta['description'];
		$out = '';
		if ( !empty($val) ){
			if((int)($this->attributes['content_length']) > 0 && $trim == true){
				$val = wp_trim_words($val,(int)($this->attributes['content_length']));
			}
			$out = sprintf( $format, esc_html( $val ) );
		}
		return $out;
	}
    public function get_meta_galery( $thumb_type = 'large', $thumb_size = '', $echo = false ) {
		$output = $thumb_img = $thumb_img_src = '';
		$gallery = get_post_meta(get_the_ID(), $this->post_type.'_timeline_images', true);
        $galleryArr = explode(',', $gallery);
		$galleryArr = array_filter($galleryArr);
		if( $this->has_thumbnail ) {
			$thumb_id_post = get_post_thumbnail_id( $this->post_id );
			array_unshift($galleryArr, $thumb_id_post);
		}
		$get_post = get_post($this->post_id);
		if( !empty($galleryArr) && is_array($galleryArr) ) {
			foreach ($galleryArr as $thumb_id) {
				$get_attached_file = get_attached_file($thumb_id);
				if ( !file_exists($get_attached_file) ) {
					continue;
				}
				if( !empty($thumb_id) ) {
					$thumb_size = $this->attributes['thumb-size']['large'];
					$thumb_size_small = $this->attributes['thumb-size']['small'];
					$helper = new Cosmos_Core_Helper();
					$helper->regenerate_attachment_sizes($thumb_id, $thumb_size);
					$thumb_img = wp_get_attachment_image( $thumb_id, $thumb_size_small );
					$output .= sprintf( '%1$s', wp_kses_post($thumb_img));
				}
			}
		}
		return wp_kses_post($output);
	}
	public function get_meta_video($options = array()) {
		$output = $thumb_img = $img_cate = $iframe_video = '';
		//$options['thumb_href_class'] = 'link';

		// 1: thumbnail image
		$out_image = '%2$s';
		// 1: thumbnail image, 2: iframe
		$out_video = '
            <div class="video-youtube">%1$s
                <a href="javascript:void(0);" title="Close" class="button-close fancybox-close" style="display:none;"></a>
                <a class="button-play" href="javascript:void(0);" data-video="%2$s">
                    <img src="'.COSMOS_PUBLIC_URI.'/images/button-play.png" alt="button play">
                </a>

            </div>';
		$post_format = get_post_format( $this->post_id );
		$post_meta_video = get_post_meta( $this->post_id, COSMOS_CORE_THEME_PREFIX.'_feature_video', true );
		$is_video_type = false;
		if (!empty($post_meta_video)) {
			if ( $post_meta_video['video_type'] == 'youtube' && !empty($post_meta_video['youtube_id']) ) {
				$is_video_type = true;
			} elseif ( $post_meta_video['video_type'] == 'vimeo' && !empty($post_meta_video['vimeo_id']) ) {
				$is_video_type = true;
			}
		}
		if ($post_format == 'video' ) {
			if ($is_video_type == true) {
				$video_type = $post_meta_video['video_type'];
				if ($video_type == "youtube") {
					$iframe_video = 'https://www.youtube.com/embed/'.esc_attr( $post_meta_video['youtube_id'] );
				} elseif ($video_type == "vimeo") {
					$iframe_video = 'https://player.vimeo.com/video/'.esc_attr( $post_meta_video['vimeo_id'] );
				}
				$options['no_href_image'] = true;
			}
			$output = sprintf( $out_video, $this->get_featured_image(array('image_format'=>'%1$s')), $iframe_video );
		}else {
			$options['hide_no_image'] = true;
			$output = sprintf( $out_image, $this->get_featured_image($options) );
		}
		return $output;
	}



}