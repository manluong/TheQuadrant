<?php
$custom_css = "";
$sc_id      = 'banner-'. $id;
$block_class= $extra_class . ' ' . $sc_id . " style-$style";
$link_array = array(
	'title'    =>'',
	'text'     =>'',
	'url_title'=>'',
	'target'   =>'',
	'link'     =>'#'
);
//display custom css
if (!empty($bg_img)){
	$bg_img = wp_get_attachment_image_src($bg_img,'full', false)[0];
	$custom_css .= sprintf('.%1$s .h-option-4 .bg-h-4-des{background-image:url(%2$s);}',
		esc_attr( $sc_id ),
		esc_attr($bg_img));
}
if (!empty($bg_color)){
	$custom_css .= sprintf('.%1$s .h-option-4 .bg-h-4-des{background-color:%2$s;}',
		esc_attr( $sc_id ),
		esc_attr($bg_color));
}
if (!empty($header_color)){
	$custom_css .= sprintf('.%1$s .text-header{color:%2$s !important;}',
		esc_attr( $sc_id ),
		esc_attr($header_color));
}
if (!empty($slides_color)){
	$custom_css .= sprintf('.%1$s .slider-carousel figcaption{color:%2$s;}',
		esc_attr( $sc_id ),
		esc_attr($slides_color));
}
if (!empty($features_color)){
	$custom_css .= sprintf('.%1$s .items-text-h-8 > li{color:%2$s;}',
		esc_attr( $sc_id ),
		esc_attr($features_color));
}
if (!empty($color_background)){
	$custom_css .= sprintf('.%1$s .h-option-4 .bg-h-4-des { background-color:%2$s;}',
		esc_attr( $sc_id ),
		esc_attr($color_background));
}
if (!empty($header_size)){
	$custom_css .= sprintf('@media only screen and (min-width: 1024px) { 
		.%1$s .block-left-text.h-option-3 h2, 
		.%1$s .block-contain-text .text-header, 
		.%1$s .perfect-landing .text-header,
		.%1$s .text-header,
		.%1$s .perfect-landing p.text-header
		{font-size:%2$s;} }',
		esc_attr( $sc_id ),
		esc_attr($header_size));
}
if (!empty($image_background_mb)){
	$custom_css .= sprintf('@media only screen and (max-width: 767px) { .%1$s.sc-banner.style-4 .option-4 { background-image:url(%2$s); background-size: cover; } }',
		esc_attr( $sc_id ),
		esc_url( wp_get_attachment_image_url($image_background_mb,'full', false) )
	);
}

$images_array = array();
if (!empty($images)){
	$del_space = str_replace(" ","", trim($images));
    $output = str_replace(',,',',',$del_space);
	$images_array = explode(',', $output);
}
?>
<div class="pix-shortcode sc-banner banner-style-<?php  echo esc_attr($style) ?> <?php  echo esc_attr($block_class) ?>" id="<?php echo esc_attr($sc_id); ?>">
	<?php
	if ($style == 1){
		?>
		<div class="header-page option-3 color-txt-white">
			<!-- content header -->
			<div class="block-content-header h-option-3">
				<div class="block-left-text h-option-3">
					<div class="block-contain-text">
						<h2 class="wow fadeInLeft text-header" data-wow-duration="1s" data-wow-delay="1s">
							<?php echo !empty($header) ? esc_html($header) : ''; ?>
						</h2>
						<div class="wow fadeInLeft text-description" data-wow-duration="1s" data-wow-delay="0.8s">
							<?php echo !empty($description) ? wp_kses_post($description) : '';  ?>
						</div>
						<?php
						if (!empty($btn_link)){
							$class_animation = array('fadeInRight', 'fadeInLeft'); 
							foreach ($btn_link as $key => $value){
								$_link = 'href="javascript:;"';
								if (!empty($value['link'])){
									$_link = Cosmos_Core_Util::get_link_to_attr($value['link']);
								}
								$_style_css = '';
								if (!empty($value['text_color'])){
									$custom_css .= sprintf('.%1$s .option-3 .h-option-3 .%2$s.bnt-head { color:%3$s; }',
										esc_attr( $sc_id ),
										esc_attr( 'button-link-'.$key ),
										esc_attr( $value['text_color'] )
									);
								}
								if (!empty($value['text_color_hover'])){
									$custom_css .= sprintf('.%1$s .option-3 .h-option-3 .%2$s.bnt-head:hover { color:%3$s; }',
										esc_attr( $sc_id ),
										esc_attr( 'button-link-'.$key ),
										esc_attr( $value['text_color_hover'] )
									);
								}
								if (!empty($value['bg_color'])){
									$custom_css .= sprintf('.%1$s .option-3 .h-option-3 .%2$s.bnt-head { background-color:%3$s; }',
										esc_attr( $sc_id ),
										esc_attr( 'button-link-'.$key ),
										esc_attr( $value['bg_color'] )
									);
								}
								if (!empty($value['bg_color_hover'])){
									$custom_css .= sprintf('.%1$s .option-3 .h-option-3 .%2$s.bnt-head:hover { background-color:%3$s; }',
										esc_attr( $sc_id ),
										esc_attr( 'button-link-'.$key ),
										esc_attr( $value['bg_color_hover'] )
									);
								}
								if (!empty($value['bg_img'])){
									$custom_css .= sprintf('.%1$s .option-3 .h-option-3 .%2$s.bnt-head { background-image:url(%3$s); }',
										esc_attr( $sc_id ),
										esc_attr( 'button-link-'.$key ),
										esc_url( wp_get_attachment_image_url($value['bg_img'],'full', false) )
									);
								}
								?>
								<a <?php echo wp_kses_post($_link); ?> class="bnt-head wow btn-text <?php echo esc_attr($class_animation[($key%2)]); ?> button-link-<?php echo esc_attr($key); ?>" data-wow-delay="1.7s">
									<?php
            						if (!empty($value['image'])){
            							echo wp_get_attachment_image($value['image'], 'full',false, array('class'=>'responsive'));
            						}else{
            							echo !empty($value['text']) ? esc_html($value['text']) : '';
            						}
            						?>
								</a>
								<?php
							}
						}
						?>
					</div>
				</div>
				<div class="block-right-img h-option-3">
					<figure>
						<?php
						if (!empty($img_primary)){
							echo wp_get_attachment_image($img_primary, 'full',false, array('class'=>'shadow-bg'));
						}?>
					</figure>
				</div><!-- end block-right-img h-option-3 -->
			</div><!-- end content header -->
		</div>
		<?php
	}elseif ($style == 2){
		?>
		<div class="header-page bg-img-header-1 color-txt-white">
			<!-- content header -->
			<div class="block-content-header h-option-1">
				<div class="container">
					<div class="row">
						<div class="col-md-12">
							<div class="perfect-landing mb-fix">
								<p class="wow fadeInDown text-header">
									<?php echo !empty($header) ? esc_html($header) : '';  ?>
								</p>
								<div class="wow fadeInUp text-description">
									<?php echo !empty($description) ? wp_kses_post($description) : '';  ?>
								</div>
							</div><!-- perfect landing -->
						</div>

						<div class="col-md-12">
							<?php
							if (!empty($btn_link)){
								?>
								<div class="block-gg-wd-app">
									<?php
									foreach ($btn_link as $key => $value){
										$_link = 'href="javascript:;"';
										if (!empty($value['link'])){
											$_link = Cosmos_Core_Util::get_link_to_attr($value['link']);
										}
										$_style_css = '';
										if (!empty($value['text_color'])){
											$custom_css .= sprintf('.%1$s .header-page .h-option-1 .%2$s.btn-app { color:%3$s; }',
												esc_attr( $sc_id ),
												esc_attr( 'button-link-'.$key ),
												esc_attr( $value['text_color'] )
											);
										}
										if (!empty($value['text_color_hover'])){
											$custom_css .= sprintf('.%1$s .header-page .h-option-1 .%2$s.btn-app:hover { color:%3$s; }',
												esc_attr( $sc_id ),
												esc_attr( 'button-link-'.$key ),
												esc_attr( $value['text_color_hover'] )
											);
										}
										if (!empty($value['bg_color'])){
											$custom_css .= sprintf('.%1$s .header-page .h-option-1 .%2$s.btn-app { background-color:%3$s; }',
												esc_attr( $sc_id ),
												esc_attr( 'button-link-'.$key ),
												esc_attr( $value['bg_color'] )
											);
										}
										if (!empty($value['bg_color_hover'])){
											$custom_css .= sprintf('.%1$s .header-page .h-option-1 .%2$s.btn-app:hover { background-color:%3$s; }',
												esc_attr( $sc_id ),
												esc_attr( 'button-link-'.$key ),
												esc_attr( $value['bg_color_hover'] )
											);
										}
										if (!empty($value['bg_img'])){
											$custom_css .= sprintf('.%1$s .header-page .h-option-1 .%2$s.btn-app { background-image: url(%3$s); }',
												esc_attr( $sc_id ),
												esc_attr( 'button-link-'.$key ),
												esc_url( wp_get_attachment_image_url($value['bg_img'],'full', false) )
											);
										}
										?>
											<a class="btn-app button-link-<?php echo esc_attr($key); ?>" <?php echo wp_kses_post($_link); ?> >
												<?php
												if (!empty($value['image'])){
													echo wp_get_attachment_image($value['image'], 'full',false, array('class'=>'wow flipInX', 'data-wow-delay' => '1.5s'));
												}else{
													echo !empty($value['text']) ? esc_html($value['text']) : '';
												}
												?>
											</a>

										<?php
									} ?>
								</div>
								<?php
							} ?>
						</div>

						<div class="col-md-12">
							<figure class="txt-center">
								<?php
								if (!empty($img_primary)){
									echo wp_get_attachment_image($img_primary, 'full',false, array('class'=>'wow head-bg-slider animated', 'data-animate' => 'fadeInUp'));
								}?>
							</figure>
						</div>
					</div>

				</div><!-- end container -->
			</div><!-- end content header -->
		</div>
		<?php
	}elseif ($style == 3){
		?>
		<div class="header-page option-2 color-txt-white">
			<!-- content header -->
			<div class="block-content-header h-option-2">
				<div class="col-1555">
					<figure class="col-left bn-3-pding-l-100">
						<?php
						if (!empty($img_primary)){
							echo wp_get_attachment_image($img_primary, 'full',false, array('class'=>'wow head-bg-slider animated'));
						}?>
					</figure>

					<div class="col-right-text">
						<h2 class="wow zoomInDown text-header" data-wow-duration="2s" data-wow-delay="0.5s">
							<?php echo !empty($header) ? wp_kses_post($header) : ''; ?>
						</h2>
						<div class="wow zoomInDown text-description" data-wow-duration="2s" data-wow-delay="1.5s">
							<?php echo !empty($description)? wp_kses_post($description) : null; ?>
						</div>
					</div>
				</div><!-- end col-1555 -->
			</div><!-- end content header -->
		</div>
		<?php
	}elseif ($style == 4){
		?>
		<div class="col-full-hd header-page option-2 option-4 color-txt-white over-hidden">
			<!-- content header -->
			<div class="block-content-header h-option-4 page-custom-4">
				<div class="bg-h-4-des"></div>
				<?php
				if (!empty($images_array[0])){
					echo wp_get_attachment_image($images_array[0], 'full',false, array('class'=>'item-bg-head-1 wow fadeInLeft', 'data-wow-duration'=>'1.5s', 'data-wow-delay'=>'1s'));
				}?>
				<?php
				if (!empty($images_array[1])){
					echo wp_get_attachment_image($images_array[1], 'full',false, array('class'=>'item-bg-head-3 wow fadeInDown', 'data-wow-duration'=>'1.5s'));
				}?>
				<?php
				if (!empty($images_array[2])){
					echo wp_get_attachment_image($images_array[2], 'full',false, array('class'=>'item-bg-head-4 wow zoomIn', 'data-wow-duration'=>'2s', 'data-wow-delay'=>'1.5s'));
				}?>
				<?php
				if (!empty($images_array[3])){
					echo wp_get_attachment_image($images_array[3], 'full',false, array('class'=>'item-bg-head-5 ', 'data-wow-duration'=>'2s'));
				}?>
				<?php
				if (!empty($images_array[4])){
					echo wp_get_attachment_image($images_array[4], 'full',false, array('class'=>'item-bg-head-6 wow fadeInLeft', 'data-wow-duration'=>'2s', 'data-wow-delay'=>'2.5s'));
				}?>
				<figure class="comsmos">
					<h2 class="wow fadeInUp text-header">
						<?php echo !empty($header) ? esc_html($header) : ''; ?>
					</h2>
				</figure>

				<div class="text-info">
					<?php echo !empty($description) ? wp_kses_post($description) : ''; ?>
				</div>
				<?php
				if (!empty($video)){
					?>
					<button class="play-vides">
						<i class="fa fa-play-circle play-icon" aria-hidden="true"></i>
						<i class="fa fa-pause-circle-o pause-icon" aria-hidden="true"></i>
					</button>
					<video>
						<source src="<?php echo wp_get_attachment_url($video); ?>" type="video/mp4"/>
						<?php esc_html_e('Your browser does not support the video tag.', 'cosmos'); ?>
					</video>
					<?php
				} ?>
			</div><!-- end content header -->
		</div>
		<?php
	}elseif ($style == 5){
		?>
		<div class="col-full-hd header--5 header-page option-7 color-txt-white over-hidden pad-right pad-left">
			<?php
			if (!empty($images_array[0])){
				echo wp_get_attachment_image($images_array[0], 'full',false, array('class'=>'mbile-head-1 fadeInLeft'));
			}?>
			<?php
			if (!empty($images_array[1])){
				echo wp_get_attachment_image($images_array[1], 'full',false, array('class'=>'mbile-head-2 wow fadeInDown'));
			}?>
			<!-- content header -->
			<div class="block-content-header h-option-7">
				<h2 class="wow fadeInUp description pull-right" data-wow-duration="2s" data-wow-delay="0.5s">
					<?php echo !empty($description) ? wp_kses_post($description) : ''; ?>
				</h2>
				<h3 class="bg-cosmos-text wow fadeInUp text-header" data-wow-duration="2s" data-wow-delay="1.6s">
					<?php echo !empty($header) ? esc_html($header) : ''; ?>
				</h3>
			</div><!-- end content header -->
		</div>
		<?php
	}elseif ($style == 6){
		?>
		<div class="bg-banner-6 header-page color-txt-white over-hidden">
			<!-- content header -->
			<div class="block-content-header h-option-8">
				<div class="content-h-8">
					<div class="slider-8-left">
						<figure class="slider-head-8-left">
						</figure>
						<div class="blk-sli-h-8 owl-carousel-h8 slider-carousel" data-autoplay="<?php echo !empty($autoplay) ? esc_attr($autoplay) : ''; ?>" data-timeout="<?php echo !empty($timeout) ? esc_attr((int)$timeout) : ''; ?>">
							<?php
							if (!empty($carousel) > 0){
								foreach ($carousel as $value){
									?>
									<figure class="item-ow-8">
										<?php
										if (!empty($value['image'])){
											echo wp_get_attachment_image($value['image'], 'full',false, array('class'=>'responsive'));
										}?>
										<figcaption>
											<h2>
												<?php echo esc_html($value['title']); ?>
											</h2>
											<p>
												<?php echo esc_html($value['description']); ?>
											</p>
										</figcaption>
									</figure>
									<?php
								}
							}
							?>
						</div>
					</div><!-- end slider-8-left -->
					<div class="center-element-h-8">
						<div class="cont-8-right">
							<h2 class="text-header">
								<?php echo !empty($header) ? esc_html($header) : ''; ?>
							</h2>
							<ul class="items-text-h-8">
								<?php
								if (!empty($features)){
									$class_animation = array('fadeInRight','fadeInLeft');
									foreach ($features as $key => $value){
										?>
										<li class="wow <?php echo esc_attr($class_animation[($key % 2)]);?>" data-wow-duration="2s">
											<span class="icon-title-bn">
												<i class="<?php echo esc_attr($value['vc_icon']); ?>" aria-hidden="true">
												</i>
											</span>
											<p class="title-bn">
												<?php echo esc_html($value['title']); ?>
											</p>
											<p>
												<?php echo esc_html($value['description']); ?>
											</p>
										</li>
										<?php
									}
								}?>
                                <?php
                                if (!empty($btn_link)){
                                ?>
									<li class="wow fadeInUp">
									    <?php
        							    foreach ($btn_link as $key => $value){
											$_link = 'href="javascript:;"';
											if (!empty($value['link'])){
												$_link = Cosmos_Core_Util::get_link_to_attr($value['link']);
											}
	        								$_style_css = '';
	        								if (!empty($value['text_color'])){
												$custom_css .= sprintf('.%1$s .header-page .h-option-8 .%2$s.btn-text { color:%3$s; }',
													esc_attr( $sc_id ),
													esc_attr( 'button-link-'.$key ),
													esc_attr( $value['text_color'] )
												);
	        								}
	        								if (!empty($value['text_color_hover'])){
												$custom_css .= sprintf('.%1$s .header-page .h-option-8 .%2$s.btn-text:hover { color:%3$s; }',
													esc_attr( $sc_id ),
													esc_attr( 'button-link-'.$key ),
													esc_attr( $value['text_color_hover'] )
												);
	        								}
	        								if (!empty($value['bg_color'])){
												$custom_css .= sprintf('.%1$s .header-page .h-option-8 .%2$s.btn-text { background-color:%3$s; }',
													esc_attr( $sc_id ),
													esc_attr( 'button-link-'.$key ),
													esc_attr( $value['bg_color'] )
												);
	        								}
	        								if (!empty($value['bg_color_hover'])){
												$custom_css .= sprintf('.%1$s .header-page .h-option-8 .%2$s.btn-text:hover { background-color:%3$s; }',
													esc_attr( $sc_id ),
													esc_attr( 'button-link-'.$key ),
													esc_attr( $value['bg_color_hover'] )
												);
	        								}
	        								if (!empty($value['bg_img'])){
												$custom_css .= sprintf('.%1$s .header-page .h-option-8 .%2$s.btn-text { background-image: url(%3$s); }',
													esc_attr( $sc_id ),
													esc_attr( 'button-link-'.$key ),
													esc_url( wp_get_attachment_image_url($value['bg_img'],'full', false) )
												);
	        								}
        								?>
										<a <?php echo wp_kses_post( $_link );?> class="see-all-h8 btn-text button-link-<?php echo esc_attr($key); ?>" >
											<?php
											if (!empty($value['image'])){
												echo wp_get_attachment_image($value['image'], 'full',false, array('class'=>'responsive'));
											}else{
												echo !empty($value['text']) ? esc_html($value['text']) : '';
											}
											?>
										</a>
                                        <?php } ?>
									</li>
									<?php
								}
								?>
							</ul>
						</div><!-- end slider-8-left -->
					</div>
				</div><!-- end content-h-8 -->
			</div><!-- end content header -->
		</div>
		<?php
	}elseif ($style == 7){
		?>
		<div class="h-option-10 header-page color-txt-white over-hidden pad-right pad-left">
			<!-- content header -->
			<div class="block-content-header h-option-10 ct-12-st">
				<div class="text-left-blk">
					<h2 class="wow fadeInUp text-header" data-wow-duration="1.5s" data-wow-delay="1.7s">
						<?php echo !empty($header) ? esc_html($header) : ''; ?>
					</h2>
					<p class="wow fadeInDown text-description" data-wow-duration="1.5s" data-wow-delay="1.7s">
						<?php echo !empty($description) ? wp_kses_post($description) : ''; ?>
					</p>
					<?php
					if (!empty($btn_link)){
						?>
						<ul class="download-icon">
							<?php
							foreach ($btn_link as $key => $value){
								$_link = 'href="javascript:;"';
								if (!empty($value['link'])){
									$_link = Cosmos_Core_Util::get_link_to_attr($value['link']);
								}
								$_style_css = '';
								if (!empty($value['text_color'])){
									$custom_css .= sprintf('.%1$s .header-page .h-option-10 .%2$s { color:%3$s; }',
										esc_attr( $sc_id ),
										esc_attr( 'button-link-'.$key ),
										esc_attr( $value['text_color'] )
									);
								}
								if (!empty($value['text_color_hover'])){
									$custom_css .= sprintf('.%1$s .header-page .h-option-10 .%2$s:hover { color:%3$s; }',
										esc_attr( $sc_id ),
										esc_attr( 'button-link-'.$key ),
										esc_attr( $value['text_color_hover'] )
									);
								}
								if (!empty($value['bg_color'])){
									$custom_css .= sprintf('.%1$s .header-page .h-option-10 .%2$s { background-color:%3$s; }',
										esc_attr( $sc_id ),
										esc_attr( 'button-link-'.$key ),
										esc_attr( $value['bg_color'] )
									);
								}
								if (!empty($value['bg_color_hover'])){
									$custom_css .= sprintf('.%1$s .header-page .h-option-10 .%2$s:hover { background-color:%3$s; }',
										esc_attr( $sc_id ),
										esc_attr( 'button-link-'.$key ),
										esc_attr( $value['bg_color_hover'] )
									);
								}
								if (!empty($value['bg_img'])){
									$custom_css .= sprintf('.%1$s .header-page .h-option-10 .%2$s { background-image: url(%3$s); }',
										esc_attr( $sc_id ),
										esc_attr( 'button-link-'.$key ),
										esc_url( wp_get_attachment_image_url($value['bg_img'],'full', false) )
									);
								}
								?>
								<li class="wow flipInX" data-wow-delay="1s">
									<a <?php echo wp_kses_post($_link); ?> class="button-link-<?php echo esc_attr($key); ?>" >
										<?php
										if (!empty($value['image'])){
											echo wp_get_attachment_image($value['image'], 'full',false, array('class'=>'responsive'));
										}else{
											echo !empty($value['text']) ? esc_html($value['text']) : '';
										}
										?>
									</a>
								</li>
								<?php
							} ?>
						</ul>
						<?php
					}?>
				</div><!-- end text-left-blk-->

				<div class="center-slider">
					<div class="dg-container slider-h-10-right slider-3d" data-autoplay="<?php echo !empty($autoplay) ? esc_attr($autoplay) : ''; ?>" data-timeout="<?php echo !empty($timeout) ? esc_attr((int)$timeout) : ''; ?>">
						<div class="dg-wrapper">
							<?php
							if (!empty($images)){
								foreach ($images_array as $key => $value){
							?>
                                    <a href="javascript:;">
										<?php echo wp_get_attachment_image($value,'full'); ?>
                                    </a>
                            <?php
								}
							} ?>
						</div>

					</div><!-- end slider -->
				</div><!-- end center -->


			</div><!-- end content header -->
		</div>
		<?php
	}elseif ($style == 8){
		?>
		<div class="h-option-9 header-page color-txt-white over-hidden pad-right pad-left">
			<!-- content header -->
			<div class="block-content-header h-option-9">
				<div class="slider-h-9">
					<div class="owl-carousel-h9 slider-carousel" data-autoplay="<?php echo !empty($autoplay) ? esc_attr($autoplay) : ''; ?>" data-timeout="<?php echo !empty($timeout) ? esc_attr((int)$timeout) : ''; ?>">
						<?php
						if (!empty($images)){
							foreach ($images_array as $img){
								?>
								<figure class="item-h-9">
									<?php echo wp_get_attachment_image($img, 'full',false, array('class'=>'')); ?>
								</figure><!-- end item -->
								<?php
							}
						}?>
					</div><!-- end slider -->

					<div class="text-h9">
						<h2 class="wow fadeIn text-header" data-wow-duration='2s' data-wow-delay='0.9s'>
							<?php echo !empty($header) ? esc_html($header) :''; ?>
						</h2>
						<div class="wow fadeIn" data-wow-duration='2s' data-wow-delay='1.2s'>
							<?php echo !empty($description) ? wp_kses_post($description) :''; ?>
						</div>
						<?php
						if (!empty($btn_link)){
						?>
						<div class="group-button">
						<?php
							foreach ($btn_link as $key => $value){
								$_link = 'href="javascript:;"';
								if (!empty($value['link'])){
									$_link = Cosmos_Core_Util::get_link_to_attr($value['link']);
								}
								$_style_css = '';
								if (!empty($value['text_color'])){
									$custom_css .= sprintf('.%1$s .header-page .h-option-9 .%2$s.btn-text { color:%3$s; }',
										esc_attr( $sc_id ),
										esc_attr( 'button-link-'.$key ),
										esc_attr( $value['text_color'] )
									);
								}
								if (!empty($value['text_color_hover'])){
									$custom_css .= sprintf('.%1$s .header-page .h-option-9 .%2$s.btn-text:hover { color:%3$s; }',
										esc_attr( $sc_id ),
										esc_attr( 'button-link-'.$key ),
										esc_attr( $value['text_color_hover'] )
									);
								}
								if (!empty($value['bg_color'])){
									$custom_css .= sprintf('.%1$s .header-page .h-option-9 .%2$s.btn-text { background-color:%3$s; }',
										esc_attr( $sc_id ),
										esc_attr( 'button-link-'.$key ),
										esc_attr( $value['bg_color'] )
									);
								}
								if (!empty($value['bg_color_hover'])){
									$custom_css .= sprintf('.%1$s .header-page .h-option-9 .%2$s.btn-text:hover { background-color:%3$s; }',
										esc_attr( $sc_id ),
										esc_attr( 'button-link-'.$key ),
										esc_attr( $value['bg_color_hover'] )
									);
								}
								if (!empty($value['bg_img'])){
									$custom_css .= sprintf('.%1$s .header-page .h-option-9 .%2$s.btn-text { background-image: url(%3$s); }',
										esc_attr( $sc_id ),
										esc_attr( 'button-link-'.$key ),
										esc_url( wp_get_attachment_image_url($value['bg_img'],'full', false) )
									);
								}
								?>
							<a <?php echo wp_kses_post($_link); ?> class="h-9-free btn-text button-link-<?php echo esc_attr($key); ?>">
								<?php
        						if (!empty($value['image'])){
        							echo wp_get_attachment_image($value['image'], 'full',false, array('class'=>'responsive'));
        						}else{
        							echo !empty($value['text']) ? esc_html($value['text']) : '';
        						}
        						?>
							</a>
							<?php
							} ?>
						</div>
						<?php
						}?>
					</div>
					
				</div><!-- end slider-h-9 -->
			</div><!-- end content header -->
		</div>
		<?php
	}?>
</div>
<?php 
if ( !empty( $custom_css ) ){
	do_action( COSMOS_CORE_ADD_INLINE_CSS, $custom_css );
}
?>