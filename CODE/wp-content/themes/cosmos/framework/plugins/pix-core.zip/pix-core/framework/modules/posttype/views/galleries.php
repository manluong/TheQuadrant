<?php $prefix= COSMOS_CORE_THEME_PREFIX.'_'; ?>
<div class="pix-custom-meta" >
	<div class="pix-meta-row active" >
		<div class="pix-desc">
			<span><?php esc_html_e( 'Gallery Images', 'pix-core' );?></span>
			<p class="description"><?php esc_html_e( 'Images should have minimum size: 800x600. Bigger size images will be cropped automatically.', 'pix-core' );?></p>
		</div>
		<div class="pix-field">
			<?php
			$this->gallery( $prefix . 'meta['. $prefix .'galleries]', $post_meta); 
			?>
		</div>
	</div>
</div>