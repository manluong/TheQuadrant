<?php
$sc_controller = new Cosmos_Core_Shortcodes_Controller();
$style = array(
	esc_html__( 'Style 1', 'pix-core' ) => 2,
	esc_html__( 'Style 2', 'pix-core' ) => 3
);

$params = array(
	array(
		'type'        => 'dropdown',
		'admin_label' => true,
		"class"       => "",
		'heading'     => esc_html__( 'Style', 'pix-core' ),
		'param_name'  => 'style',
		'value'       => $style,
		'description' => esc_html__( 'Select style.',  'pix-core'  )
	),
	array(
		'type'        => 'textfield',
		'heading'     => esc_html__( 'Title', 'pix-core' ),
		'param_name'  => 'title',
		'description' => esc_html__( 'Enter title', 'pix-core' ),
		'value'       => esc_html__('Subscribe For Our Monthly News Updates', 'pix-core')
	),
	array(
		'type'        => 'textfield',
		'heading'     => esc_html__( 'Sub title', 'pix-core' ),
		'param_name'  => 'sub_title',
		'description' => esc_html__( 'Enter sub title', 'pix-core' ),
		'value'       => esc_html__('Join our mailing list and stay informed about our news and updates.', 'pix-core')
	),
	array(
		'type'        => 'textfield',
		'heading'     => esc_html__( 'Fullname placeholder', 'pix-core' ),
		'param_name'  => 'input_fullname_placeholder',
		'description' => esc_html__( 'Enter fullname placeholder', 'pix-core' ),
		'value'       => esc_html__('Enter fullname', 'pix-core'),
		'dependency'  => array(
			'element' => 'style',
			'value'   => array('2')
		)
	),
	array(
		'type'        => 'textfield',
		'heading'     => esc_html__( 'Email placeholder', 'pix-core' ),
		'param_name'  => 'input_email_placeholder',
		'description' => esc_html__( 'Enter email placeholder', 'pix-core' ),
		'value'       => esc_html__('Enter your email', 'pix-core')
	),
	array(
		'type'        => 'textfield',
		'heading'     => esc_html__( 'Button text', 'pix-core' ),
		'param_name'  => 'button_text',
		'description' => esc_html__( 'Enter button text', 'pix-core' ),
		'value'       => esc_html__('Subscribe', 'pix-core')
	),
	array(
		"type"        => "colorpicker",
		"class"       => "",
		"heading"     => esc_html__( "Title Color", 'pix-core' ),
		"param_name"  => "title_color",
		"description" => esc_html__( "Choose title color.", 'pix-core' ),
		'group'       => esc_html__('Options', 'pix-core')
	),
	array(
		"type"        => "colorpicker",
		"class"       => "",
		"heading"     => esc_html__( "Sub title Color", 'pix-core' ),
		"param_name"  => "sub_title_color",
		"description" => esc_html__( "Choose sub title color.", 'pix-core' ),
		'group'       => esc_html__('Options', 'pix-core')
	),
	array(
		"type"        => "colorpicker",
		"class"       => "",
		"heading"     => esc_html__( "Input Color", 'pix-core' ),
		"param_name"  => "input_color",
		"description" => esc_html__( "Choose input color.", 'pix-core' ),
		'group'       => esc_html__('Options', 'pix-core'),
	),
	array(
		"type"        => "colorpicker",
		"class"       => "",
		"heading"     => esc_html__( "Input placeholder Color", 'pix-core' ),
		"param_name"  => "input_placeholder_color",
		"description" => esc_html__( "Choose input placeholder color.", 'pix-core' ),
		'group'       => esc_html__('Options', 'pix-core'),
	),
	array(
		"type"        => "colorpicker",
		"class"       => "",
		"heading"     => esc_html__( "Input background Color", 'pix-core' ),
		"param_name"  => "input_bg_color",
		"description" => esc_html__( "Choose input background color.", 'pix-core' ),
		'group'       => esc_html__('Options', 'pix-core'),
	),
	array(
		"type"        => "colorpicker",
		"class"       => "",
		"heading"     => esc_html__( "Border Color", 'pix-core' ),
		"param_name"  => "input_border_color",
		"description" => esc_html__( "Choose border color.", 'pix-core' ),
		'group'       => esc_html__('Options', 'pix-core'),
	),
	array(
		"type"        => "colorpicker",
		"class"       => "",
		"heading"     => esc_html__( "Button Color", 'pix-core' ),
		"param_name"  => "button_color",
		"description" => esc_html__( "Choose button color.", 'pix-core' ),
		'group'       => esc_html__('Options', 'pix-core'),
	),
	array(
		"type"        => "colorpicker",
		"class"       => "",
		"heading"     => esc_html__( "Button background Color", 'pix-core' ),
		"param_name"  => "button_bg_color",
		"description" => esc_html__( "Choose button background color.", 'pix-core' ),
		'group'       => esc_html__('Options', 'pix-core'),
	),
	array(
		"type"        => "colorpicker",
		"class"       => "",
		"heading"     => esc_html__( "Button hover Color", 'pix-core' ),
		"param_name"  => "button_hover_color",
		"description" => esc_html__( "Choose button hover color.", 'pix-core' ),
		'group'       => esc_html__('Options', 'pix-core'),
	),
	array(
		"type"        => "colorpicker",
		"class"       => "",
		"heading"     => esc_html__( "Button hover background Color", 'pix-core' ),
		"param_name"  => "button_hover_bg_color",
		"description" => esc_html__( "Choose button hover background color.", 'pix-core' ),
		'group'       => esc_html__('Options', 'pix-core'),
	),
	array(
		'type'            => 'textfield',
		'heading'         => esc_html__( 'Extra Class', 'pix-core' ),
		'param_name'      => 'extra_class',
		'description'     => esc_html__( 'Style particular content element differently - add a class name and refer to it in custom CSS.', 'pix-core' )
	),
	$sc_controller->cosmos_animation_style(),
	$sc_controller->cosmos_animation_delay(),

);

vc_map(
	array(
		"name"			=> esc_html__( 'PIX Subscribe email', 'pix-core' ),
		"base"			=> "pixcore_subscribe_email_sc",
		"class"			=> "pixcore-sc",
		"category"		=> COSMOS_CORE_SC_CATEGORY,
		'icon'			=> 'icon-pixcore_subscribe_email_sc',
		"description"	=> esc_html__( 'Subscribe email', 'pix-core' ),
		"params"		=> $params
	)
);