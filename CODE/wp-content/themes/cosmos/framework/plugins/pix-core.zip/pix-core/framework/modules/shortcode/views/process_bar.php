<?php
$uniq_id = 'sc-process-bar-'.esc_attr( $id );
$custom_css = '';
$column_def = array(
	'1' => 'col-xs-12 process-1col',
	'2' => 'col-sm-6 col-xs-12 process-2col',
	'3' => 'col-md-4 col-sm-6 col-xs-12 process-3col',
	'4' => 'col-xs-12 col-sm-6 col-md-3 process-4col',
);
if($style == 1) {
	if( !empty( $title_color ) ){
		$custom_css .= '.%1$s .section_process_bar.style-1 .content .title {color:%2$s;}'."\n";
	}
	if( !empty( $number_color ) ){
		$custom_css .= '.%1$s .section_process_bar.style-1 .content .percent {color:%3$s;}'."\n";
	}
	if( !empty( $border_color ) ){
		$custom_css .= '.%1$s .section_process_bar.style-1 .content {border-color:%4$s;}'."\n";
		$custom_css .= '.%1$s .section_process_bar.style-1 > .row > .content:last-child {border-color:%4$s;}'."\n";
	}
}
if($style == 2) {
	if( !empty( $title_color ) ){
		$custom_css .= '.%1$s .section_process_bar.style-4 .processbar-content .canvas-text span {color:%2$s;}'."\n";
	}
}

if ( !empty( $custom_css ) ) {
	$custom_css = sprintf($custom_css,
			esc_attr($uniq_id),
			esc_attr($title_color),
			esc_attr($number_color),
			esc_attr($border_color)
			);
	do_action( COSMOS_CORE_ADD_INLINE_CSS, $custom_css );
}
if( !empty( $values ) && is_array( $values ) ){
?>
	<div class="pix-shortcode sc-process-bar style-<?php echo esc_attr($style)?> <?php echo esc_attr($uniq_id).' '.esc_attr( $extra_class )?> animate-run" data-animate="<?php echo esc_attr($css_animation); ?>" data-delay="<?php echo (int) esc_attr($delay_animation); ?>" data-id="<?php echo esc_attr($uniq_id); ?>">
	<?php if($style == 1) { ?>
		<div class="section_process_bar style-1" data-type="bg">
			<div class="row" >
			<?php $i=0; foreach ($values as $value) { $i++;?>
				<div class="content <?php echo esc_attr($uniq_id) .'-'. esc_attr($i) ?>" data-text="<?php echo esc_attr($value['title']) ?>" data-perc="<?php echo esc_attr($value['number']) ?>" data-color="<?php echo !empty($process_color) ? esc_attr($process_color) : '#e1b55a' ?>" data-color-not-process="<?php echo !empty($not_process_color) ? esc_attr($not_process_color) : '#f9f9f9' ?>">
                    <div class="row">
                        <div class="col-xs-3">
                            <div class="title" data-type="title">
                                <?php echo esc_attr($value['title']) ?>
                            </div>
                        </div>
                        <div class="col-xs-7">
                            <div class="canvas">
                                <canvas id="<?php echo esc_attr($uniq_id) .'-'. esc_attr($i) ?>" class="canvas-style-1 rectangle"  height="8" ></canvas>
                            </div>
                        </div>
                        <div class="col-xs-2">
                            <div class="percent">
                                0%
                            </div>
                        </div>
                    </div>
                </div>
            <?php } ?>
			</div>
		</div>
	<?php } else { ?>
		<div class="section_process_bar style-4">
			<div class="row">
			<?php $i=0; foreach ($values as $value) { $i++;?>
				<div class="<?php echo esc_attr($column_def[$column]) ?>">
	                <div class="processbar-content <?php echo esc_attr($uniq_id) .'-'. esc_attr($i) ?>" data-perc="<?php echo esc_attr($value['number']) ?>" data-color="<?php echo !empty($process_color) ? esc_attr($process_color) : '#e1b55a' ?>" data-color-not-process="<?php echo !empty($not_process_color) ? esc_attr($not_process_color) : '#5a565c' ?>" data-number-color="<?php echo !empty($number_color) ? esc_attr($number_color) : '#ffffff' ?>">
	                    <canvas id="<?php echo esc_attr($uniq_id) .'-'. esc_attr($i)?>" class="canvas-style-4 circle" width="150" height="150"></canvas>
	                    <div class="canvas-text">
	                        <span data-type="title"><?php echo esc_attr($value['title']) ?></span>
	                    </div>
	                </div>
	            </div>
            <?php } ?>
    	    </div>
		</div>
	<?php } ?>
	</div>
<?php } ?>