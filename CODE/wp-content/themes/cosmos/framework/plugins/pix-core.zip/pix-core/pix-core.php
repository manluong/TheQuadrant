<?php
/*
Plugin Name: Pix Core
Plugin URI: http://themeforest.net/user/swlabs
Description: Pix Core Plugin for Cosmos Theme
Version: 1.0
Author: PIXArtThemes
Author URI: https://themeforest.net/user/pixartthemes
Text Domain: pix-core
*/

clearstatcache();

include_once( ABSPATH . 'wp-admin/includes/plugin.php' );

// load constants
require_once( plugin_dir_path( __FILE__ ) . '/constants.php' );

/* Load plugin textdomain.*/
load_plugin_textdomain( 'pix-core', false, plugin_basename( dirname( __FILE__ ) ) . '/languages' );

/* Initialization */
require_once( COSMOS_CORE_FRAMEWORK_DIR . '/class-pix-loader.php' );
require_once( COSMOS_CORE_FRAMEWORK_DIR . '/class-pix-config.php' );
require_once( COSMOS_CORE_FRAMEWORK_DIR . '/class-pix-params.php' );
require_once( plugin_dir_path( __FILE__ ) . '/class-pix.php' );
require_once( COSMOS_CORE_FRAMEWORK_DIR . '/class-pix-format.php' );
require_once( COSMOS_CORE_FRAMEWORK_DIR . '/class-pix-util.php' );
require_once( COSMOS_CORE_FRAMEWORK_DIR . '/class-pix-com.php' );

require_once( plugin_dir_path( __FILE__ ) . '/custom-functions.php' );
require_once( plugin_dir_path( __FILE__ ) . '/framework/modules/importer/index.php' );

Cosmos_Core::load_class( 'Abstract' );
Cosmos_Core::load_class( 'Helper' );
Cosmos_Core::load_class( 'models.Custom_Post_Model' );
Cosmos_Core::load_class( 'models.Taxonomy_Model' );
Cosmos_Core::load_class( 'models.Video_Model' );
Cosmos_Core::load_class( 'models.Pagination' );
Cosmos_Core::load_class( 'shortcode.Blog' );
Cosmos_Core::load_class( 'shortcode.Testimonial' );
Cosmos_Core::load_class( 'shortcode.Team' );
Cosmos_Core::load_class( 'shortcode.Portfolio' );
Cosmos_Core::load_class( 'shortcode.Timeline' );
Cosmos_Core::load_class( 'shortcode.Price' );
Cosmos_Core::load_class( 'shortcode.Banner' );
Cosmos_Core::load_class( 'shortcode.Faq' );
Cosmos_Core::load_class( 'Social_Share' );

$app = Cosmos_Core::new_object('Application');
$app->run();
if(COSMOS_CORE_IMPORT_TAXONOMY_ACTIVE) {
	$opt = Cosmos_Core::new_object('Options_Importer');
	$opt->instance();
}

if( COSMOS_CORE_VC_ACTIVE ) {
	add_action('vc_before_init', array( COSMOS_CORE_CLASS, '[shortcode.Shortcodes_Controller, vc_map_shortcodes]' ) );
}
add_action('init', array( COSMOS_CORE_CLASS, '[shortcode.Shortcodes_Controller, init]' ) );

if( ! is_admin() ) {
	add_action( 'wp_enqueue_scripts', array( COSMOS_CORE_CLASS, '[setting.Setting_Init, dev_enqueue_scripts]' ) );
}