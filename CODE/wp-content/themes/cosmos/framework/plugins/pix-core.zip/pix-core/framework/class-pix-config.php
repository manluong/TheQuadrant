<?php
/**
* Core config class.
*
* @author Swlabs
* @since 1.0
*/
if ( ! class_exists( 'Cosmos_Core_Config' ) ) {
    class Cosmos_Core_Config
    {
        private static $setting = array(
            'save_post'        => array(
                'cosmos_team'             => array('posttype.Team_Controller','save' ),
                'cosmos_testi'            => array('posttype.Testimonial_Controller','save' ),
                'cosmos_portfolio'        => array('posttype.Portfolio_Controller','save' ),
                'cosmos_timeline'         => array('posttype.Timeline_Controller','save'),
                'cosmos_price'            => array('posttype.Price_Controller','save' ),
                'post'            		  => array('posttype.Post_Controller','save' ),
            ),
            'shortcode'        => array(
                'pixcore_blog_list_sc'       => 'blog_list',
                'pixcore_block_title_sc'     => 'block_title',
                'pixcore_button_sc'          => 'button',
                'pixcore_count_down_sc'      => 'count_down',
                'pixcore_coming_soon_sc'     => 'coming_soon',
                'pixcore_contact_form_sc'    => 'contact_form',
                'pixcore_google_map_sc'      => 'google_map',
                'pixcore_icon_box_sc'        => 'icon_box',
                'pixcore_subscribe_email_sc' => 'subscribe_email',
                'pixcore_social_sc'          => 'social',
                'pixcore_team_carousel_sc'   => 'team_carousel',
                'pixcore_team_list_sc'       => 'team_list',
                'pixcore_testimonial_sc'     => 'testimonial',
                'pixcore_toggle_box_sc'      => 'toggle_box',
                'pixcore_recent_news_sc'     => 'recent_news',
                'pixcore_gallery_masonry_sc' => 'gallery_masonry',
                'pixcore_demo_app_sc'        => 'demo_app',
                'pixcore_carousel_sc'        => 'carousel',
                'pixcore_count_download_sc'  => 'count_download',
                'pixcore_banner_sc'  		 => 'banner',
                'pixcore_process_bar_sc'     => 'process_bar',
                'pixcore_screenshot_sc'      => 'screenshot',
                'pixcore_timeline_sc'        => 'timeline',
                'pixcore_faq_sc'             => 'faq',
                'pixcore_portfolio_sc'       => 'portfolio',
                'pixcore_price_sc'           => 'price',

            ),
            'post_type'        => array(
                'custom_column' => array(
                    'cosmos_team',
                    'cosmos_testi',
                    'cosmos_portfolio',
                    'cosmos_timeline',
                    'cosmos_faq',
                    'cosmos_price',
                ),
                'feature_video' => array('post', 'cosmos_timeline' )
            )
        );
        /**
        * Retrieve value from the config variable.
        *
        * @param string $name The key name of first level.
        * @param string $field optional The key name of second level.
        * @return mixed.
        */
        public static function get( $name, $field = NULL )
        {
            if ( isset( self::$setting[ $name ] ) ) {
                if ( $field ) {
                    return ( isset( self::$setting[ $name ][ $field ] ) ) ? self::$setting[ $name ][ $field ] : null;
                } else {
                    return self::$setting[ $name ];
                }
            }

            return array();
        }
    }
}