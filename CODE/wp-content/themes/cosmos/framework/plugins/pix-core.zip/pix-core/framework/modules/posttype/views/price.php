<?php $prefix       = 'cosmos_price_';?>
<div class="pix-custom-meta" >
	<div class="pix-meta-row " >
		<div class="pix-desc">
			<label><?php esc_html_e( 'Is Featured:', 'pix-core' );?></label>
		</div>
		<div class="pix-field">
			
			<label class="pix-switch" data-show="is_featured">
				<?php
				echo ( $this->hidden_field( $prefix.'meta[' . $prefix . 'is_featured]', 
											$this->get_field( $data_meta, 'is_featured' ), 
											null) );
				?>
				<input type="checkbox" <?php if( $this->get_field( $data_meta, 'is_featured' ) ) : echo esc_attr( 'checked' ); endif; ?> />
				<div class="slider round"></div>
			</label>
		</div>
	</div>
	<div class="pix-meta-row show_is_featured hide">
		<div class="pix-desc">
			<label><?php esc_html_e( 'Featured Text:', 'pix-core' );?></label>
		</div>
		<div class="pix-field">
			<?php echo ( $this->text_field( $prefix.'meta[' . $prefix . 'featured_text]',
											$this->get_field( $data_meta, 'featured_text' ),
											array('class'=>'') ) ); ?>
			<p class="text-style-italic"><?php esc_html_e( 'Input text you want show for price. example: Best Sell', 'slz-core' );?></p>
		</div>
	</div>
	<div class="pix-meta-row" >
		<div class="pix-desc">
			<label><?php esc_html_e( 'Price:', 'pix-core' );?></label>
		</div>
		<div class="pix-field">
			<?php echo ( $this->text_field( $prefix.'meta[' . $prefix . 'price]',
											$this->get_field( $data_meta, 'price' ),
											array('class'=>'') ) ); ?>
			<p class="text-style-italic"><?php esc_html_e( 'Should enter positive number.', 'slz-core' );?></p>
		</div>
	</div>
	<div class="pix-meta-row" >
		<div class="pix-desc">
			<label><?php esc_html_e( 'Unit:', 'pix-core' );?></label>
		</div>
		<div class="pix-field">
			<?php echo ( $this->text_field( $prefix.'meta[' . $prefix . 'unit]',
											$this->get_field( $data_meta, 'unit' ),
											array('class'=>'') ) ); ?>
			<p class="text-style-italic"><?php esc_html_e( 'Please enter per Day or Month or Year.', 'slz-core' );?></p>
		</div>
	</div>
	<div class="pix-meta-row" >
		<div class="pix-desc">
			<label><?php esc_html_e( 'URL:', 'pix-core' );?></label>
		</div>
		<div class="pix-field">
			<?php echo ( $this->text_field( $prefix.'meta[' . $prefix . 'url]',
											$this->get_field( $data_meta, 'url' ),
											array('class'=>'') ) ); ?>
			<p class="text-style-italic"><?php esc_html_e( 'Please enter URL.', 'slz-core' );?></p>
		</div>
	</div>
	<div class="pix-meta-row" >
		<div class="pix-desc">
			<label><?php esc_html_e( 'Description:', 'pix-core' );?></label>
		</div>
		<div class="pix-field">
			<?php echo ( $this->text_area( $prefix.'meta[' . $prefix . 'description]',
											$this->get_field( $data_meta, 'description' ),
											array('class'=>'') ) ); ?>
			<p class="text-style-italic"><?php esc_html_e( 'Should enter description.', 'slz-core' );?></p>
		</div>
	</div>
	<div class="pix-meta-row">
		<div class="pix-desc">
			<label><?php esc_html_e( 'Attributes:', 'pix-core' );?></label>
		</div>
		<div class="pix-field">
			<input type="hidden" name="<?php echo esc_attr($prefix.'meta[' . $prefix . 'attr]'); ?>" value="" />
			<table class="form-table">
				<tbody class="pix-content-attributes">
					<?php
					$attrs = $this->get_field( $data_meta, 'attr' );
					$key   = - 1;
					do{
						//break loop when $attrs is empty
						if(empty($attrs) && $key == 0)break;
						if($key == - 1){
							$value_result = "";
							$key_count   = "";
						}
						else{
							$value_result = esc_html($attrs[$key]['name']);
							$key_count   = $key;
						}
						?>
						<tr class="last pix-section-clone">
							<td scope="row" colspan="2">
								<div class="pix-section-container postbox-container">
									<div class="pix-section">

										<a href="javascript:void(0);" class="pix-section-remove pix-row-remove">✕ <?php esc_html_e( 'Delete Attribute', 'pix-core' ); ?></a>
										<br>
										<div class="pix-custom-meta">
											<div class="pix-meta-row">
												<div class="pix-desc">
													<span><?php esc_html_e( 'Name', 'pix-core' ); ?></span>
												</div>
												<div class="pix-field">
													<?php echo ( $this->text_field( $prefix.'meta[' . $prefix . 'attr]['.$key_count.'][name]',
															$value_result,
															array('class'=>'') ) );?>
												</div>
											</div>
										</div>

									</div>

								</div>
							</td>
						</tr>
						<?php
						$key++;
					}
					while(count($attrs) > $key);
					?>

				</tbody>
				<tr>
					<td>
						<input type="button" class="button button-primary pix-add-section-project" data-item="<?php echo esc_attr($section_count)?>" data-metabox="<?php echo esc_attr( $prefix .'meta['. $prefix .'attr]' )?>" data-name="<?php echo esc_attr( 'name' )?>" data-value="<?php echo esc_attr( 'value' )?>" data-container=".pix-section-container" value="<?php esc_html_e( 'Add Attribute', 'pix-core' );?>" />
					</td>
				</tr>
			</table>
		</div>
	</div>
	
</div>