<?php
$sc_controller = new Cosmos_Core_Shortcodes_Controller();
$style = array(
	esc_html__( 'Style 1', 'pix-core' ) => 2,
	esc_html__( 'Style 2', 'pix-core' ) => 4,
);
$yes_no  = array(
	esc_html__('Yes', 'pix-core') => 'yes',
	esc_html__('No', 'pix-core')  => 'no',
);

$countdown_style = array(
	esc_html__( 'Countdown style 1', 'pix-core' )				=> '1',
	esc_html__( 'Countdown style 2', 'pix-core' )				=> '2',
);

$social_style = array(
	esc_html__('Social style 1','pix-core')	=> '1',
	esc_html__('Social style 2','pix-core')	=> '2',
	esc_html__('Social style 3','pix-core')	=> '3',
);
$align = Cosmos_Core_Params::get('align');
$social = Cosmos_Core_Params::teammbox_social();
$icon ='';
foreach ($social as $key => $value) {
	$icon[$value] = $key;
}

$params = array(
	array(
		'type'        	=> 'dropdown',
		'heading'     	=> esc_html__( 'Show Logo ?', 'pix-core' ),
		'param_name'  	=> 'has_logo',
		'value'       	=> $yes_no,
		'std'			=> 'yes',
		'description' 	=> esc_html__( 'Choose yes to show logo.', 'pix-core' ),
	),
	array(
		'type'        => 'dropdown',
		'admin_label' => true,
		"class"       => "",
		'heading'     => esc_html__( 'Style Comming Soon', 'pix-core' ),
		'param_name'  => 'style',
		'value'       => $style,
		'std'		  => '2',
		'description' => esc_html__( 'Select style comming soon.',  'pix-core'  )
	),
	array(
		'type'            => 'textfield',
		'heading'         => esc_html__( 'Title', 'pix-core' ),
		'param_name'      => 'title',
		'value'       	  => esc_html__( 'Coming Soon', 'pix-core' ),
		'description'     => esc_html__( 'Enter title.', 'pix-core' )
	),
	array(
		'type'            => 'textarea',
		'heading'         => esc_html__( 'Description', 'pix-core' ),
		'param_name'      => 'description',
		'value'       	  => '',
		'description'     => esc_html__( 'Enter description.', 'pix-core' )
	),
	array(
		'type'        => 'textfield',
		'heading'     => esc_html__( 'Email placeholder', 'pix-core' ),
		'param_name'  => 'input_email_placeholder',
		'description' => esc_html__( 'Enter email placeholder', 'pix-core' ),
		'value'       => esc_html__('Enter your email', 'pix-core')
	),
	array(
		'type'        => 'textfield',
		'heading'     => esc_html__( 'Button text', 'pix-core' ),
		'param_name'  => 'button_text',
		'description' => esc_html__( 'Enter button text', 'pix-core' ),
		'value'       => esc_html__('Sign Up', 'pix-core')
	),
	array(
		'type'        => 'pix_datetime_picker',
		'heading'     => esc_html__( 'End Date', 'pix-core' ),
		'param_name'  => 'countdown_end_date',
		'value'       => '',
		'description' => esc_html__( 'Select End Date for count down.',  'pix-core'  )
	),
	array(
		'type'        => 'dropdown',
		"class"       => "",
		'heading'     => esc_html__( 'Style Social', 'pix-core' ),
		'param_name'  => 'social_style',
		'value'       => $social_style,
		'std'		  => '2',
		'description' => esc_html__( 'Select style social.',  'pix-core'  )
	),
	array(
		'type'       => 'param_group',
		'heading'    => esc_html__( 'Social Content', 'pix-core' ),
		'param_name' => 'social_data',
		'callbacks'  => array(
		'after_add'  => 'vcChartParamAfterAddCallback'
		),
		'params'     => array(
			array(
				'type'       	=> 'dropdown',
				"class"       	=> "",
				'admin_label' 	=> true,
				'value'			=> $icon,
				'heading'    	=> esc_html__( 'Choose Social', 'pix-core' ),
				'param_name' 	=> 'icon',
				'description'	=> esc_html__( 'Please choose social to show', 'pix-core' ),
			),
			array(
				'type'        => 'vc_link',
				'heading'     => esc_html__( 'Link', 'pix-core' ),
				'param_name'  => 'url',
				'value'       => '',
				'description' => esc_html__( 'Please input to url redirect.', 'pix-core' )
			),
		)
	),
	array(
		'type'            => 'textfield',
		'heading'         => esc_html__( 'Extra Class', 'pix-core' ),
		'param_name'      => 'extra_class',
		'description'     => esc_html__( 'Style particular content element differently - add a class name and refer to it in custom CSS.', 'pix-core' )
	),
	array(
		'type'           => 'attach_image',
		'heading'        => esc_html__( 'Add background image', 'pix-core' ),
		'param_name'     => 'image_background',
		'description'    => esc_html__( 'Choose background image to add.', 'pix-core' ),
		'group'          => esc_html__('Custom Style', 'pix-core'),
	),
	array(
		"type"        => "colorpicker",
		"heading"     => esc_html__( "Title Color", 'pix-core' ),
		"param_name"  => "title_color",
		"description" => esc_html__( "Choose title color.", 'pix-core' ),
		'group'       => esc_html__('Custom Style', 'pix-core'),
	),
	array(
		"type"        => "colorpicker",
		"heading"     => esc_html__( "Description Color", 'pix-core' ),
		"param_name"  => "description_color",
		"description" => esc_html__( "Choose description color.", 'pix-core' ),
		'group'       => esc_html__('Custom Style', 'pix-core'),
	),
	array(
		'type'       => 'colorpicker',
		'heading'    => esc_html__( 'Input Color', 'pix-core' ),
		'param_name' => 'input_color',
		'description'=> esc_html__( 'Choose color for input', 'pix-core' ),
		'group'      => esc_html__( 'Custom Style', 'pix-core' ),
	),
	array(
		'type'       => 'colorpicker',
		'heading'    => esc_html__( 'Input Placeholder Color', 'pix-core' ),
		'param_name' => 'input_placeholder_color',
		'description'=> esc_html__( 'Choose color for input placeholder', 'pix-core' ),
		'group'      => esc_html__( 'Custom Style', 'pix-core' ),
	),
	array(
		'type'       => 'colorpicker',
		'heading'    => esc_html__( 'Input Background Color', 'pix-core' ),
		'param_name' => 'input_bg_color',
		'description'=> esc_html__( 'Choose color for input background', 'pix-core' ),
		'group'      => esc_html__( 'Custom Style', 'pix-core' ),
	),
	array(
		'type'       => 'colorpicker',
		'heading'    => esc_html__( 'Input Border Color', 'pix-core' ),
		'param_name' => 'input_border_color',
		'description'=> esc_html__( 'Choose color for input border', 'pix-core' ),
		'group'      => esc_html__( 'Custom Style', 'pix-core' ),
	),
	array(
		"type"        => "colorpicker",
		"class"       => "",
		"heading"     => esc_html__( "Button Color", 'pix-core' ),
		"param_name"  => "button_color",
		"description" => esc_html__( "Choose button color.", 'pix-core' ),
		'group'       => esc_html__('Custom Style', 'pix-core'),
	),
	array(
		"type"        => "colorpicker",
		"class"       => "",
		"heading"     => esc_html__( "Button background Color", 'pix-core' ),
		"param_name"  => "button_bg_color",
		"description" => esc_html__( "Choose button background color.", 'pix-core' ),
		'group'       => esc_html__('Custom Style', 'pix-core'),
	),

	array(
		"type"        => "colorpicker",
		"class"       => "",
		"heading"     => esc_html__( "Title Color", 'pix-core' ),
		"param_name"  => "countdown_title_color",
		"description" => esc_html__( "Choose title color.", 'pix-core' ),
		'group'       => esc_html__('Countdown Custom Style', 'pix-core'),
	),
	array(
		"type"        => "colorpicker",
		"class"       => "",
		"heading"     => esc_html__( "Number Color", 'pix-core' ),
		"param_name"  => "countdown_number_color",
		"description" => esc_html__( "Choose number color.", 'pix-core' ),
		'group'       => esc_html__('Countdown Custom Style', 'pix-core'),
	),
	array(
		"type"        => "colorpicker",
		"class"       => "",
		"heading"     => esc_html__( "Border Color", 'pix-core' ),
		"param_name"  => "countdown_border_color",
		"description" => esc_html__( "Choose border color.", 'pix-core' ),
		'group'       => esc_html__('Countdown Custom Style', 'pix-core'),
		'dependency'  => array(
			'element' 	=> 'countdown_style',
			'value'   	=> array('1')
		),
	),

	array(
		"type"        => "colorpicker",
		"class"       => "",
		"heading"     => esc_html__( "Icon Color", 'pix-core' ),
		"param_name"  => "social_icon_color",
		"description" => esc_html__( "Choose the icon color.", 'pix-core' ),
		'group'       => esc_html__('Social Custom Style', 'pix-core'),
	),
	array(
		"type"        => "colorpicker",
		"class"       => "",
		"heading"     => esc_html__( "Icon Color Hover", 'pix-core' ),
		"param_name"  => "social_icon_color_hover",
		"description" => esc_html__( "Choose the icon color when hover.", 'pix-core' ),
		'group'       => esc_html__('Social Custom Style', 'pix-core'),
	),
	array(
		"type"        => "colorpicker",
		"class"       => "",
		"heading"     => esc_html__( "Border Icon Color", 'pix-core' ),
		"param_name"  => "social_border_icon_color",
		"description" => esc_html__( "Choose color for border icon.", 'pix-core' ),
		'group'       => esc_html__('Social Custom Style', 'pix-core'),
		'dependency'    => array(
			'element'=> 'social_style',
			'value'         => array( '3' )
		),
	),
	array(
		"type"        => "colorpicker",
		"class"       => "",
		"heading"     => esc_html__( "Background Icon Color", 'pix-core' ),
		"param_name"  => "social_bg_color",
		"description" => esc_html__( "Choose color for background icon.", 'pix-core' ),
		'group'       => esc_html__('Social Custom Style', 'pix-core'),
		'dependency'    => array(
			'element'=> 'social_style',
			'value'         => array( '1' )
		),
	),
	array(
		"type"        => "colorpicker",
		"class"       => "",
		"heading"     => esc_html__( "Background Icon Color Hover", 'pix-core' ),
		"param_name"  => "social_bg_color_hover",
		"description" => esc_html__( "Choose color for background icon when hover.", 'pix-core' ),
		'group'       => esc_html__('Social Custom Style', 'pix-core'),
		'dependency'    => array(
			'element'=> 'social_style',
			'value'         => array( '1' )
		),
	),
	$sc_controller->cosmos_animation_style(),
	$sc_controller->cosmos_animation_delay(),

);

vc_map(
	array(
		"name"			=> esc_html__( 'PIX Coming Soon', 'pix-core' ),
		"base"			=> "pixcore_coming_soon_sc",
		"class"			=> "pixcore-sc",
		"category"		=> COSMOS_CORE_SC_CATEGORY,
		'icon'			=> 'icon-pixcore_coming_soon_sc',
		"description"	=> esc_html__( 'Coming soon for page', 'pix-core' ),
		"params"		=> $params
	)
);