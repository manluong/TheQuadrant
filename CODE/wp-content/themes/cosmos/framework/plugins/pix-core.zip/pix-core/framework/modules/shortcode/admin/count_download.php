<?php
$sc_controller = new Cosmos_Core_Shortcodes_Controller();
$style = array(
	esc_html__( 'Style 1', 'pix-core' ) => 3,
	esc_html__( 'Style 2', 'pix-core' ) => 5,
);
$params = array(
	array(
		'type'        => 'dropdown',
		"class"       => "",
		'heading'     => esc_html__( 'Style', 'pix-core' ),
		'param_name'  => 'style',
		'value'       => $style,
		'description' => esc_html__( 'Select style.',  'pix-core'  )
	),
	array(
		'type'        => 'attach_image',
		'heading'     => esc_html__( 'Icon download', 'pix-core' ),
		'param_name'  => 'icon_download',
		'description' => esc_html__( 'Choose icon download', 'pix-core' ),
	),
	array(
		'type'            => 'textfield',
		'heading'         => esc_html__( 'Title', 'pix-core' ),
		'param_name'      => 'title_download',
		'description'     => esc_html__( 'Enter title. Example: Google play store', 'pix-core' )
	),
	array(
		'type'            => 'textfield',
		'heading'         => esc_html__( 'Number download', 'pix-core' ),
		'param_name'      => 'number_download',
		'description'     => esc_html__( 'Enter number download. Example: 9999', 'pix-core' )
	),
	array(
		'type'            => 'textfield',
		'heading'         => esc_html__( 'Extra Class', 'pix-core' ),
		'param_name'      => 'extra_class',
		'description'     => esc_html__( 'Style particular content element differently - add a class name and refer to it in custom CSS.', 'pix-core' )
	),
	array(
		"type"        => "colorpicker",
		"heading"     => esc_html__( "Title Color", 'pix-core' ),
		"param_name"  => "title_color",
		"description" => esc_html__( "Choose title color.", 'pix-core' ),
		'group'       => esc_html__('Custom Style', 'pix-core'),
	),
	array(
		"type"        => "colorpicker",
		"heading"     => esc_html__( "Number download Color", 'pix-core' ),
		"param_name"  => "number_color",
		"description" => esc_html__( "Choose number color.", 'pix-core' ),
		'group'       => esc_html__('Custom Style', 'pix-core'),
	),
	array(
		"type"        => "colorpicker",
		"heading"     => esc_html__( "Icon background Color", 'pix-core' ),
		"param_name"  => "background_icon_color",
		"description" => esc_html__( "Choose count down color.", 'pix-core' ),
		'group'       => esc_html__('Custom Style', 'pix-core'),
		'dependency'  => array(
			'element' => 'style',
			'value'   => array('5')
		)
	),
	$sc_controller->cosmos_animation_style(),
	$sc_controller->cosmos_animation_delay(),

);

vc_map(
	array(
		"name"			=> esc_html__( 'PIX Count Download', 'pix-core' ),
		"base"			=> "pixcore_count_download_sc",
		"class"			=> "pixcore-sc",
		"category"		=> COSMOS_CORE_SC_CATEGORY,
		'icon'			=> 'icon-pixcore_count_download_sc',
		"description"	=> esc_html__( 'Count download for app', 'pix-core' ),
		"params"		=> $params
	)
);