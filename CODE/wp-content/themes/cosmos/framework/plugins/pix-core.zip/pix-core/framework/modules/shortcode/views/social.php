<?php
$uniq_id = 'sc-social-'.esc_attr( $id );
$custom_css = '';
if($style == 1) {
	if( !empty( $icon_color ) ){
		$custom_css .= '.%1$s .social-icon {color:%2$s;}'."\n";
	}
	if( !empty( $icon_color_hover ) ){
		$custom_css .= '.%1$s .social-icon:hover {color:%3$s;}'."\n";
	}
	if( !empty( $bg_color ) ){
		$custom_css .= '.%1$s .social-icon.fa {background:%5$s;}'."\n";
	}
	if( !empty($align) ) {
		$custom_css .= '.%1$s .social-group {text-align:%6$s;}'."\n";
	}
	if( !empty( $bg_color_hover ) ){
		$custom_css .= '.%1$s .social-icon.fa:hover {background:%7$s;}'."\n";
	}
}
if($style == 3) {
	if( !empty( $icon_color ) ){
		$custom_css .= '.%1$s .section_comming_soon.style-4 .col-center .contact a .fa {color:%2$s;}'."\n";
	}
	if( !empty( $icon_color_hover ) ){
		$custom_css .= '.%1$s .section_comming_soon.style-4 .col-center .contact a:hover .fa {color:%3$s;}'."\n";
		$custom_css .= '.%1$s .section_comming_soon.style-4 .col-center .contact a:hover{border-color:%3$s;}'."\n";
	}
	if( !empty( $border_icon_color ) ){
		$custom_css .= '.%1$s .section_comming_soon.style-4 .col-center .contact a{border-color:%4$s;}'."\n";
	}
	if( !empty($align) ) {
		$custom_css .= '.%1$s .section_comming_soon.style-4 .col-center .contact {text-align:%6$s;}'."\n";
	}
}
if($style == 2) {
	if( !empty( $icon_color ) ){
		$custom_css .= '.%1$s .social-icon {color:%2$s;}'."\n";
	}
	if( !empty( $icon_color_hover ) ){
		$custom_css .= '.%1$s .social-icon:hover {color:%3$s;}'."\n";
	}
	if( !empty($align) ) {
		$custom_css .= '.%1$s .section_comming_soon.style-2 .col-center .contact {text-align:%6$s;}'."\n";
	}
}

if ( !empty( $custom_css ) ) {
	$custom_css = sprintf($custom_css,
			esc_attr($uniq_id),
			esc_attr($icon_color),
			esc_attr($icon_color_hover),
			esc_attr($border_icon_color),
			esc_attr($bg_color),
			esc_attr($align),
			esc_attr($bg_color_hover)
			);
	do_action( COSMOS_CORE_ADD_INLINE_CSS, $custom_css );
}
if( !empty( $values ) && is_array( $values ) ){
?>
	<div class="pix-shortcode sc-social style-<?php echo esc_attr($style)?> <?php echo esc_attr($uniq_id).' '.esc_attr( $extra_class )?> animate-run" data-animate="<?php echo esc_attr($css_animation); ?>" data-delay="<?php echo (int) esc_attr($delay_animation); ?>">
	<?php if($style == 2 || $style == 3) { ?>
		<div class="section_comming_soon <?php if($style == 2) { ?> style-2 <?php } else { ?> style-4 <?php } ?>">
			<div class="col-center">
				<div class="contact">
				<?php foreach ($values as $value) {
					if ( !empty($value['url']) ) {
			            $value['url'] = Cosmos_Core_Util::get_link_to_attr($value['url']);
			        }
				?>
		        	<a <?php echo !empty($value['url']) ? $value['url'] : "href='javascrpipt:;'"; ?>>
	                    <i class="fa fa-<?php echo esc_attr($value['icon']) ?> social-icon bg-non" aria-hidden="true"></i>
	                </a>
	            <?php } ?>
		      	</div>
		    </div>
		</div>
	<?php } else { ?>
		<div class="section_team style-1" data-type="bg">
			<div class="social-group">
			<?php foreach ($values as $value) {
				if ( !empty($value['url']) ) {
		            $value['url'] = Cosmos_Core_Util::get_link_to_attr($value['url']);
		        }
			?>
				<a class="row-edit social-item twitter-icon" <?php echo !empty($value['url']) ? $value['url'] : "href='javascrpipt:;'"; ?>>
					<i class="fa fa-<?php echo esc_attr($value['icon']) ?> social-icon" aria-hidden="true"></i>
				</a>
			<?php } ?>
			</div>
		</div>
	<?php } ?>
	</div>
<?php } ?>
