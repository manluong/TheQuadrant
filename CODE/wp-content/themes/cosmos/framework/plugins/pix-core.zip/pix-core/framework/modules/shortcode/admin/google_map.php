<?php
$sc_controller = new Cosmos_Core_Shortcodes_Controller();
$style = array(
	esc_html__( 'Style 1', 'pix-core' ) => 1,
	esc_html__( 'Style 2', 'pix-core' ) => 2,
	esc_html__( 'Style 3', 'pix-core' ) => 3
);
$content_type = array(
	esc_html__( 'Windows info', 'pix-core' ) => 1,
	esc_html__( 'Box info', 'pix-core' )     => 2
);
$params = array(
	array(
		'type'        => 'dropdown',
		'admin_label' => true,
		"class"       => "",
		'heading'     => esc_html__( 'Style', 'pix-core' ),
		'param_name'  => 'style',
		'value'       => $style,
		'description' => esc_html__( 'Select style.',  'pix-core'  )
	),
	array(
		'type'        => 'dropdown',
		"class"       => "",
		'heading'     => esc_html__( 'Content type', 'pix-core' ),
		'param_name'  => 'content_type',
		'value'       => $content_type,
		'description' => esc_html__( 'Select content type.',  'pix-core'  )
	),
	array(
		'type'       => 'param_group',
		'heading'    => esc_html__( 'List location', 'pix-core' ),
		'param_name' => 'locations',
		'callbacks'  => array( 'after_add' => 'vcChartParamAfterAddCallback' ),
		'params'     => array(
			array(
				'type'        => 'textfield',
				'admin_label' => true,
				'heading'     => esc_html__( 'Latitude', 'pix-core' ),
				'param_name'  => 'latitude',
				'value'       => '',
				'description' => sprintf( esc_html__( 'The latitude of a location. Visit %s to get latitude.', 'pix-core' ), '<a href="http://www.latlong.net" target="_blank">' . esc_html__( 'here', 'pix-core' ) . '</a>' )
			),
			array(
				'type'        => 'textfield',
				'admin_label' => true,
				'heading'     => esc_html__( 'Longitude', 'pix-core' ),
				'param_name'  => 'longitude',
				'value'       => '',
				'description' => sprintf( esc_html__( 'The longitude of a location. Visit %s to get longitude.', 'pix-core' ), '<a href="http://www.latlong.net" target="_blank">' . esc_html__( 'here', 'pix-core' ) . '</a>' )
			),
			array(
				"type"        => "textfield",
				"holder"      => "div",
				"heading"     => esc_html__( 'Title', 'pix-core' ),
				"param_name"  => "title",
				"description" => esc_html__( 'Enter title here', 'pix-core' )
			),
			array(
				"type"        => "textarea",
				"holder"      => "div",
				"class"       => "",
				"heading"     => esc_html__( "Description", 'pix-core' ),
				"param_name"  => "description",
				"description" => esc_html__( "Enter description here", 'pix-core' )
			)
		)
	),
	array(
		'type'       => 'attach_image',
		'heading'    => esc_html__( 'Image marker', 'pix-core' ),
		'param_name' => 'image_marker',
		'description'=> esc_html__( 'The marker of location to display on the map', 'pix-core' ),
	),
	array(
		'type'        => 'textfield',
		"class"       => "",
		'heading'     => esc_html__( 'Height map', 'pix-core' ),
		'param_name'  => 'height_map',
		'value'       => '',
		'description' => esc_html__( "Height of map (px). Example: 300", 'pix-core' )
	),
	array(
		'type'        => 'textfield',
		"class"       => "",
		'heading'     => esc_html__( 'Zoom map', 'pix-core' ),
		'param_name'  => 'zoom_map',
		'value'       => '',
		'description' => esc_html__( "Enter zoom map, range from 3 to 23. Default show all location on map", 'pix-core' )
	),
	array(
		"type"        => "colorpicker",
		"class"       => "",
		"heading"     => esc_html__( "Title Color", 'pix-core' ),
		"param_name"  => "title_color",
		"description" => esc_html__( "Choose the title color.", 'pix-core' ),
		'group'       => esc_html__('Options', 'pix-core'),
	),
	array(
		"type"        => "colorpicker",
		"class"       => "",
		"heading"     => esc_html__( "Description Color", 'pix-core' ),
		"param_name"  => "description_color",
		"description" => esc_html__( "Choose the color for text in description.", 'pix-core' ),
		'group'       => esc_html__('Options', 'pix-core'),
	),
	array(
		"type"        => "colorpicker",
		"class"       => "",
		"heading"     => esc_html__( "Location hover Color", 'pix-core' ),
		"param_name"  => "content_hover_color",
		"description" => esc_html__( "Choose the color when hover location.", 'pix-core' ),
		'group'       => esc_html__('Options', 'pix-core'),
		'dependency'  => array(
			'element' => 'content_type',
			'value'   => array('2')
		)
	),
	array(
		"type"        => "colorpicker",
		"class"       => "",
		"heading"     => esc_html__( "Title location selected Color", 'pix-core' ),
		"param_name"  => "title_active_color",
		"description" => esc_html__( "Choose the color title location selected.", 'pix-core' ),
		'group'       => esc_html__('Options', 'pix-core'),
		'dependency'  => array(
			'element' => 'content_type',
			'value'   => array('2')
		)
	),
	array(
		"type"        => "colorpicker",
		"class"       => "",
		"heading"     => esc_html__( "Description location selected Color", 'pix-core' ),
		"param_name"  => "description_active_color",
		"description" => esc_html__( "Choose the color description location selected.", 'pix-core' ),
		'group'       => esc_html__('Options', 'pix-core'),
		'dependency'  => array(
			'element' => 'content_type',
			'value'   => array('2')
		)
	),
	array(
		"type"        => "colorpicker",
		"class"       => "",
		"heading"     => esc_html__( "Background location selected Color", 'pix-core' ),
		"param_name"  => "location_bg_active_color",
		"description" => esc_html__( "Choose the color background location selected.", 'pix-core' ),
		'group'       => esc_html__('Options', 'pix-core'),
		'dependency'  => array(
			'element' => 'content_type',
			'value'   => array('2')
		)
	),
	array(
		'type'            => 'textfield',
		'heading'         => esc_html__( 'Extra Class', 'pix-core' ),
		'param_name'      => 'extra_class',
		'description'     => esc_html__( 'Style particular content element differently - add a class name and refer to it in custom CSS.', 'pix-core' )
	),
);

vc_map(
	array(
		"name"			=> esc_html__( 'PIX Google map', 'pix-core' ),
		"base"			=> "pixcore_google_map_sc",
		"class"			=> "pixcore-sc",
		"category"		=> COSMOS_CORE_SC_CATEGORY,
		'icon'			=> 'icon-pixcore_google_map_sc',
		"description"	=> esc_html__( 'Google map.', 'pix-core' ),
		"params"		=> $params
	)
);