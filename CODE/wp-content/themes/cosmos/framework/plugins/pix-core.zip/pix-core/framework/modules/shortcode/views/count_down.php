<?php
$uniq_id = 'sc-count-down-'.esc_attr( $id );
$end_date = !empty($end_date) ? $end_date : 0;
$custom_css = '';

if( !empty( $title_color ) ){
	$custom_css .= '.%1$s .col-center .clockdiv-countdown .smalltext{color: %2$s;}' ."\n";
}
if( !empty( $number_color ) ){
	$custom_css .= '.%1$s .col-center .clockdiv-countdown .square span{color:%3$s;}' ."\n";
}
if( !empty( $border_color ) ){
	$custom_css .= '.%1$s .section_comming_soon.style-2 .col-center .clockdiv-countdown .square {border-color: %4$s;}' ."\n";
}

if ( !empty( $custom_css ) ) {
	$custom_css = sprintf($custom_css,
			esc_attr($uniq_id),
			esc_attr($title_color),
			esc_attr($number_color),
			esc_attr($border_color)
			);
	do_action( COSMOS_CORE_ADD_INLINE_CSS, $custom_css );
}
?>

<div id="<?php echo esc_attr($uniq_id)?>" class="pix-shortcode sc_count_down style<?php echo esc_attr($style)?> <?php echo esc_attr($uniq_id).' '.esc_attr( $extra_class )?> animate-run" data-animate="<?php echo esc_attr($css_animation); ?>" data-delay="<?php echo (int) esc_attr($delay_animation); ?>">
	<div class="section_comming_soon <?php if($style == 1) { ?> style-2 <?php } else { ?> style-4 <?php } ?> bg-img2">
		<div class="col-center" data-time="<?php echo esc_attr($end_date) ?>">
			<div class="clockdiv-countdown">
	        	<div class="row">
		        	<div class="col-sm-3 col-xs-12">
		        		<div class="square">
		                	<span class="days"></span>
		              	</div>
		              	<div class="smalltext"><?php echo esc_attr__('DAYS','cosmos') ?></div>
		        	</div>
		        	<div class="col-sm-3 col-xs-12">
		        		<div class="square">
		                	<span class="hours"></span>
		              	</div>
		              	<div class="smalltext"><?php echo esc_attr__('HOURS','cosmos') ?></div>
		        	</div>
		        	<div class="col-sm-3 col-xs-12">
		        		<div class="square">
		                	<span class="minutes"></span>
		              	</div>
		              	<div class="smalltext"><?php echo esc_attr__('MINUTES','cosmos') ?></div>
		        	</div>
		        	<div class="col-sm-3 col-xs-12">
		        		<div class="square">
		                	<span class="seconds"></span>
		              	</div>
		              	<div class="smalltext"><?php echo esc_attr__('SECONDS','cosmos') ?></div>
		        	</div>
		        </div>
	        </div>
		</div>
	</div>
</div>