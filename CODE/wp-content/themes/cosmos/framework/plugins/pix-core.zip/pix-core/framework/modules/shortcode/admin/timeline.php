<?php
$sc_controller = new Cosmos_Core_Shortcodes_Controller();
$method = array(
	esc_html__('Timeline', 'pix-core')=> 'post' ,
	esc_html__('Category', 'pix-core')=> 'cat',

);
$yes_no = array(
    esc_html__('Yes', 'pix-core')     => 'yes' ,
	esc_html__('No', 'pix-core')	  => 'no'
);
$sort_by    = Cosmos_Core_Params::get('sort-other') ;
$timeline_order = array(
    esc_html__('Date Of Timeline Newest','pix-core') => 'timeline_newest',
    esc_html__('Date Of Timeline Lastest','pix-core') => 'timeline_lastest'
);
$orderby = array_merge($sort_by, $timeline_order);
// get Timeline categories
$taxonomy   = 'cosmos_timeline_cat';
$params_cat = array('empty'=> esc_html__( '-- All Timeline Categories --', 'pix-core' ) );
$categories = Cosmos_Core_Com::get_tax_options2slug( $taxonomy, $params_cat );
// get All Timeline
$args       = array('post_type'=> 'cosmos_timeline');
$options = array('empty'=> esc_html__( '-- All Timeline --', 'pix-core' ) );
$post_ids        = Cosmos_Core_Com::get_post_title2id( $args, $options );
$params = array(
	array(
		'type'        => 'textfield',
		'heading'     => esc_html__( 'Limit Timelines', 'pix-core' ),
		'param_name'  => 'limit_post',
		'value'       => '-1',
		'description' => esc_html__( 'Enter limit of timelines per page. If it blank the limit Timelines will be the number from Wordpress settings -> Reading. If you want show all, enter "-1".', 'pix-core' )
	),
    array(
		'type'        => 'textfield',
		'heading'     => esc_html__( 'Show Item(s) Of Timelines ', 'pix-core' ),
		'param_name'  => 'show_item',
		'value'       => '4',
		'description' => esc_html__( 'Enter item of timelines when page load.', 'pix-core' )
	),
    array(
		'type'        => 'dropdown',
		'heading'     => esc_html__( 'Sort By', 'pix-core' ),
		'param_name'  => 'sort_by',
		'value'       => $orderby,
		'std'		  => 'timeline_newest',
		'description' => esc_html__( 'Choose criteria to display.', 'pix-core' )
	),
	array(
		'type'        => 'dropdown',
		'heading'     => esc_html__( 'Show Content', 'pix-core' ),
		'param_name'  => 'show_content',
		'value'       => $yes_no,
        'std'         => 'yes',
		'description' => esc_html__( 'Choose what you want to display as content of timeline.', 'pix-core' )
	),
    array(
		'type'        => 'textfield',
		'heading'     => esc_html__( 'Title Length', 'pix-core' ),
		'param_name'  => 'title_length',
		'value'       => '',
		'description' => esc_html__( 'Enter limit of text will be truncated. If it is empty, the default is not cut. It will trim word', 'pix-core' ),
	),
	array(
		'type'        => 'textfield',
		'heading'     => esc_html__( 'Content Length', 'pix-core' ),
		'param_name'  => 'content_length',
		'value'       => '',
		'description' => esc_html__( 'Enter limit of text will be truncated. If it is empty, the default is not cut. It will trim word', 'pix-core' ),
        'dependency'  => array(
            'element' => 'show_content',
            'value'   => 'yes'
        )
	),
	array(
		'type'        => 'textfield',
		'heading'     => esc_html__( 'Button Text', 'pix-core' ),
		'param_name'  => 'button_text',
		'value'       => esc_html__( 'Read More', 'pix-core' ),
		'description' => esc_html__( 'Enter button text.', 'pix-core' )
	),
	array(
		'type'       => 'dropdown',
		'heading'    => esc_html__( 'Display by', 'pix-core' ),
		'param_name' => 'method',
		'value'      => $method,
        'std'		 => 'cat',
		'description'=> esc_html__( 'Choose Timeline category or special Timelines to display.',  'pix-core'  ),
        'group'      => esc_html__('Filter', 'pix-core')
	),
	array(
		'type'       => 'param_group',
		'heading'    => esc_html__( 'Category', 'pix-core' ),
		'param_name' => 'category_list',
		'callbacks'   => array(
		   'after_add' => 'vcChartParamAfterAddCallback'
		),
		'params'     => array(
			array(
				'type'       => 'dropdown',
				'admin_label'=> true,
				'heading'    => esc_html__( 'Add Category', 'pix-core' ),
				'param_name' => 'category_slug',
				'value'      => $categories,
				'description'=> esc_html__( 'Choose special category to filter', 'pix-core'  )
			),
		),
		'value'      => '',
		'dependency'     => array(
			'element'=> 'method',
			'value'  => array('cat' )
		),
		'description'=> esc_html__( 'Default no filter by category.', 'pix-core' ),
        'group'      => esc_html__('Filter', 'pix-core')
	),
	array(
		'type'       => 'param_group',
		'heading'    => esc_html__( 'Featured Timeline Lists', 'pix-core' ),
		'param_name' => 'post_list',
		'callbacks'   => array(
		   'after_add' => 'vcChartParamAfterAddCallback'
		),
		'params'          => array(
			array(
				'type'       => 'dropdown',
				'admin_label'=> true,
				'heading'    => esc_html__( 'Add Featured Timeline', 'pix-core' ),
				'param_name' => 'post_id',
				'value'      => $post_ids,
				'description'=> esc_html__( 'Choose featured Timeline to show', 'pix-core'  )
			),
		),
		'value'      => '',
		'dependency'     => array(
			'element'=> 'method',
			'value'  => array('post')
		),
		'description'=> esc_html__( 'Default empty.', 'pix-core' ),
        'group'      => esc_html__('Filter', 'pix-core')
	),
    array(
		'type'        	=> 'dropdown',
		'heading'     	=> esc_html__( 'Display Button Show More', 'pix-core' ),
		'param_name'  	=> 'display_showmore',
		'value'  	    => $yes_no,
        'std'           =>'yes',
		'description' 	=> esc_html__( 'Show more items', 'pix-core' ),
	),
    array(
		'type'        	=> 'textfield',
		'heading'     	=> esc_html__( 'Enter Text For Button Show More', 'pix-core' ),
		'param_name'  	=> 'button_showmore',
		'value'  	    => esc_html__('Show more', 'pix-core'),
		'description' 	=> esc_html__( 'Button Text ', 'pix-core' ),
        'dependency'    => array(
			'element'=> 'display_showmore',
			'value'  => array('yes')
		),
	),
	array(
		'type'        	=> 'colorpicker',
		'heading'     	=> esc_html__( 'Title Color', 'pix-core' ),
		'param_name'  	=> 'title_color',
		'description' 	=> esc_html__( 'Choose color title', 'pix-core' ),
		'group'			=> esc_html__('Css', 'pix-core')
	),
	array(
		'type'        	=> 'colorpicker',
		'heading'     	=> esc_html__( 'Excerpt Color', 'pix-core' ),
		'param_name'  	=> 'excerpt_color',
		'description' 	=> esc_html__( 'Choose color excerpt', 'pix-core' ),
		'group'			=> esc_html__('Css', 'pix-core')
	),
    array(
		'type'        	=> 'colorpicker',
		'heading'     	=> esc_html__( 'Button Text Color', 'pix-core' ),
		'param_name'  	=> 'button_text_color',
		'description' 	=> esc_html__( 'Choose color button text', 'pix-core' ),
		'group'			=> esc_html__('Css', 'pix-core')
	),
	array(
		'type'        	=> 'colorpicker',
		'heading'     	=> esc_html__( 'Button Color', 'pix-core' ),
		'param_name'  	=> 'button_color',
		'description' 	=> esc_html__( 'Choose color button', 'pix-core' ),
		'group'			=> esc_html__('Css', 'pix-core')
	),
    array(
		'type'        	=> 'colorpicker',
		'heading'     	=> esc_html__( 'Button Color Hover', 'pix-core' ),
		'param_name'  	=> 'button_color_hv',
		'description' 	=> esc_html__( 'Choose color button hover', 'pix-core' ),
		'group'			=> esc_html__('Css', 'pix-core')
	),
    array(
		'type'        => 'textfield',
		'heading'     => esc_html__( 'Extra Class', 'pix-core' ),
		'param_name'  => 'extra_class',
		'description' => esc_html__( 'Enter extra class.', 'pix-core' )
	),
	$sc_controller->cosmos_animation_style(),
	$sc_controller->cosmos_animation_delay(),
	array(
		'type'        => 'dropdown',
        'heading'     => esc_html__( 'Animation To Children', 'pix-core' ),
        'param_name'  => 'is_parent_animation',
        'value'       => array(
                            esc_html__('Yes', 'pix-core')=> 'yes',
                            esc_html__('No', 'pix-core') => 'no',
                        ),
        'std'         => 'no',
        'description' => esc_html__('Apply run animation to children element'),
        'group'       => esc_html__('Animation', 'pix-core'),
	)  
);
vc_map(array(
	'name'               => esc_html__( 'PIX Timeline', 'pix-core' ),
	'base'               => 'pixcore_timeline_sc',
	'class'              => 'pixcore-sc',
	'icon'               => 'icon-pixcore_timeline_sc',
	'category'           => COSMOS_CORE_SC_CATEGORY,
	'description'        => esc_html__( 'Timeline of list', 'pix-core' ),
	'params'             => $params
));