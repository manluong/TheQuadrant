<?php
$sc_controller = new Cosmos_Core_Shortcodes_Controller();
$style = array(
	esc_html__('Style 1', 'pix-core')  => '1',
	esc_html__('Style 2', 'pix-core')  => '2',
	esc_html__('Style 3', 'pix-core')  => '3',
);
$heading = Cosmos_Core_Params::get('h-tag');
$align = Cosmos_Core_Params::get('align');

$params = array(
	array(
		'type'        		=> 'dropdown',
		'heading'     		=> esc_html__( 'Style', 'pix-core' ),
		'param_name'  		=> 'style',
		'admin_label' 		=> true,
		'value'       		=> $style,
		'std'         		=> '1',
		'description' 		=> esc_html__( 'Choose style to show.', 'pix-core' ),
	),
	array(
		'type'        		=> 'dropdown',
		'heading'     		=> esc_html__( 'Align', 'pix-core' ),
		'param_name'  		=> 'align',
		'value'       		=> $align,
		'description' 		=> esc_html__( 'Choose align to show.', 'pix-core' ),
	),
	array(
		'type'				=> 'attach_image',
		'heading'     		=> esc_html__( 'Logo', 'pix-core' ),
		'param_name'  		=> 'logo',
		'admin_label' 		=> true,
		'description' 		=> esc_html__( 'Choose logo you want.', 'pix-core' ),
		'dependency'    	=> array(
			'element'		=> 'style',
			'value'         => array( '2' )
		),
	),
	array(
		'type'				=> 'textfield',
		'heading'     		=> esc_html__( 'Block Title', 'pix-core' ),
		'param_name'  		=> 'title',
		'admin_label' 		=> true,
		'description' 		=> esc_html__( 'Please input title to show.', 'pix-core' ),
	),
	array(
		'type'        		=> 'textfield',
		'heading'     		=> esc_html__( 'Block Description', 'pix-core' ),
		'param_name'  		=> 'description',
		'admin_label' 		=> true,
		'description' 		=> esc_html__( 'Please input description to show.', 'pix-core' ),
	),
	array(
		'type'          	=> 'textfield',
		'heading'       	=> esc_html__( 'Extra Class', 'pix-core' ),
		'param_name'    	=> 'extra_class',
		'description'   	=> esc_html__( 'Enter extra class name.', 'pix-core' )
	),

	array(
		'type'        		=> 'dropdown',
		'heading'     		=> esc_html__( 'Heading', 'pix-core' ),
		'param_name'  		=> 'heading',
		'value'       		=> $heading,
		'std'         		=> 'h3',
		'description' 		=> esc_html__( 'Choose heading to show.', 'pix-core' ),
		'group'       		=> esc_html__( 'Font Style', 'pix-core' ),
	),
	array(
		'type'        		=> 'textfield',
		'heading'     		=> esc_html__( 'Title Font Size', 'pix-core' ),
		'param_name'  		=> 'title_size',
		'description' 		=> esc_html__( 'Please input title font size to text. Just enter positive integer. Ex: 20px or 5em or 10%', 'pix-core' ),
		'group'       		=> esc_html__( 'Font Style', 'pix-core' ),
	),
	array(
		'type'        		=> 'textfield',
		'heading'     		=> esc_html__( 'Description Font Size', 'pix-core' ),
		'param_name'  		=> 'description_size',
		'description' 		=> esc_html__( 'Please input description font size to text. Just enter positive integer. Ex: 20px or 5em or 10%', 'pix-core' ),
		'group'       		=> esc_html__( 'Font Style', 'pix-core' ),
	),

	array(
		'type'          => 'colorpicker',
		'heading'       => esc_html__( 'Block Title -  Color', 'pix-core' ),
		'param_name'    => 'title_color',
		'description'   => esc_html__( 'Choose color for title', 'pix-core' ),
		'group'         => esc_html__( 'Custom CSS', 'pix-core' ),
	),
	array(
		'type'          => 'colorpicker',
		'heading'       => esc_html__( 'Block Description - Color', 'pix-core' ),
		'param_name'    => 'description_color',
		'description'   => esc_html__( 'Choose color for description last', 'pix-core' ),
		'group'         => esc_html__( 'Custom CSS', 'pix-core' ),
	),
	$sc_controller->cosmos_animation_style(),
	$sc_controller->cosmos_animation_delay(),

);
vc_map(array(
	'name'               => esc_html__( 'PIX Block Title', 'pix-core' ),
	'base'               => 'pixcore_block_title_sc',
	'class'              => 'pixcore-sc',
	'icon'               => 'icon-pixcore_block_title_sc',
	'category'           => COSMOS_CORE_SC_CATEGORY,
	'description'        => esc_html__( 'Block of title', 'pix-core' ),
	'params'             => $params
));

