<?php
$uniq_id = 'sc-button-'.esc_attr( $id );
$custom_css = '';
$block_cls = $extra_class . ' ' . $uniq_id;

if( !empty( $text_color ) ){
	$custom_css .= '.%1$s .button-style.background-yellow {color:%2$s;}' ."\n";
}
if( !empty( $text_color_hover ) ){
	$custom_css .= '.%1$s .button-style.background-yellow:hover {color:%3$s;}' ."\n";
}
if( !empty( $button_color ) ){
	$custom_css .= '.%1$s .button-style.background-yellow {background:%4$s;}' ."\n";
}
if( !empty( $button_color_hover ) ){
	$custom_css .= '.%1$s .button-style.background-yellow:hover {background:%5$s;}' ."\n";
}
if($border == 'yes') {
	if( !empty( $border_color ) ){
		$custom_css .= '.%1$s .button-style.border {border-color:%6$s;}' ."\n";
	}
	if( !empty( $border_color_hover ) ){
		$custom_css .= '.%1$s .button-style.border:hover {border-color:%7$s;}' ."\n";
	}
}
	
if(!empty($align)) {
	$custom_css .= '.%1$s.sc-button { text-align: %8$s; }' ."\n";
}

if ( !empty( $custom_css ) ) {
	$custom_css = sprintf($custom_css,
			esc_attr($uniq_id),
			esc_attr($text_color),
			esc_attr($text_color_hover),
			esc_attr($button_color),
			esc_attr($button_color_hover),
			esc_attr($border_color),
			esc_attr($border_color_hover),
			esc_attr($align)
			);
	do_action( COSMOS_CORE_ADD_INLINE_CSS, $custom_css );
}
$icon_show = '';
if($show_icon == 'yes') {
	if($style_icon == 1) {
		$icon_show = 'icon-group';
	} else {
		$icon_show = 'icon-show';
	}
}
$shadow_button = '';
if($shadow == 'yes') {
	$shadow_button = 'shadow';
}
$border_button = '';
if($border == 'yes') {
	$border_button = 'border';
}
?>
<div class="pix-shortcode sc-button <?php echo esc_attr( $block_cls ); ?> style<?php echo esc_attr($style)?> animate-run" data-animate="<?php echo esc_attr($css_animation); ?>" data-delay="<?php echo (int) esc_attr($delay_animation); ?>">
<?php if($style == 1) { 
	if(!empty($title)) {
?>
	<a <?php echo !empty($url) ? $url : "href='javascript:;'" ?> class="button-style background-yellow <?php echo esc_attr($width) . ' ' . esc_attr($icon_show) . ' ' . esc_attr($shadow_button) . ' ' . esc_attr($border_button) ?>">
	<?php if($show_icon == 'yes') { 
		if(!empty($icon)) {
	?>
	<i class="<?php echo esc_attr($icon) ?>" aria-hidden="true"></i>
	<?php } } ?>
	<?php echo esc_attr($title) ?>
	</a>
<?php } } if($style == 2) { 
	if(!empty($title)) {
?>
	<a <?php echo !empty($url) ? $url : "href='javascript:;'" ?> class="button-style background-yellow border-style1 <?php echo esc_attr($width) . ' ' . esc_attr($icon_show) . ' ' . esc_attr($shadow_button) . ' ' . esc_attr($border_button) ?>">
	<?php if($show_icon == 'yes') { 
		if(!empty($icon)) {
	?>
	<i class="<?php echo esc_attr($icon) ?>" aria-hidden="true"></i>
	<?php } } ?>
	<?php echo esc_attr($title) ?>
	</a>
<?php } } if($style == 3) { 
	if(!empty($title)) {
?>
	<a <?php echo !empty($url) ? $url : "href='javascript:;'" ?> class="button-style background-yellow border-style2 <?php echo esc_attr($width) . ' ' . esc_attr($icon_show) . ' ' . esc_attr($shadow_button) . ' ' . esc_attr($border_button) ?>">
	<?php if($show_icon == 'yes') { 
		if(!empty($icon)) {
	?>
	<i class="<?php echo esc_attr($icon) ?>" aria-hidden="true"></i>
	<?php } } ?>
	<?php echo esc_attr($title) ?>
	</a>
<?php } } ?>
</div>