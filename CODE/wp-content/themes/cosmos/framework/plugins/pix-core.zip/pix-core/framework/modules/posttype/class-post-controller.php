<?php
/**
 * Controller Post.
 * 
 * @since 1.0
 */

Cosmos_Core::load_class( 'Abstract' );

class Cosmos_Core_Post_Controller extends Cosmos_Core_Abstract {

	public function save() {
		global $post;
		$post_id = $post->ID;
		parent::save();
		if( isset( $_POST[COSMOS_CORE_THEME_PREFIX.'_meta']) ) {
			$data_meta = $_POST[COSMOS_CORE_THEME_PREFIX.'_meta'];
			foreach( $data_meta as $key => $value ) {				
				update_post_meta ( $post_id, $key, $value );
			}
		}
	}
	public function metabox_feature_video() {
		global $post;
		$post_id = $post->ID;
		$post_meta = array();
		if( $post_id ) {
			$post_meta = get_post_meta( $post_id, COSMOS_CORE_THEME_PREFIX . '_feature_video', true );
		}
		$this->render( 'feature-video', array(
			'post_meta' => $post_meta
		));
	}
	public function metabox_galleries_options() {
		global $post;
		$post_id = $post->ID;
		$post_meta = array();
		if( $post_id ) {
			$post_meta = get_post_meta( $post_id,  COSMOS_CORE_THEME_PREFIX. '_galleries', true );
		}
		$this->render( 'galleries', array(
			'post_meta' => $post_meta
		));
	}
}