<?php
$model = new Cosmos_Core_Testimonial();
$model->init( $atts );
$custom_css = "";
$sc_name    = 'testimonial';
$sc_id      = $model->attributes['uniq_id'];
$block_class= $atts['extra_class'] . ' ' . $sc_id;

$css_animation = '';
$css_animation_class = '';
$delay_animation = 0;
$css_animation_parent = '';
$css_animation_parent_class = '';
$delay_animation_parent = 0;

if ( !empty($model->attributes['css_animation']) && !empty($model->attributes['is_parent_animation']) && $model->attributes['is_parent_animation'] != 'yes') {
	$css_animation = $model->attributes['css_animation'];
	$css_animation_class = 'animate-run';
	$delay_animation = (int) $model->attributes['delay_animation'];
}

if ( !empty($model->attributes['css_animation']) && !empty($model->attributes['is_parent_animation']) && $model->attributes['is_parent_animation'] == 'yes') {
	$css_animation_parent = $model->attributes['css_animation'].'-children';
	$css_animation_parent_class = 'animate-run';
	$delay_animation_parent = (int) $model->attributes['delay_animation'];
}


$style_sc = '';
if($atts['style'] == 1) {
	$style_sc = 'style-1';
} else {
	$style_sc = 'style-3';
}

if($atts['style'] == 1) {
	if( !empty( $atts['name_color'] ) ){
		$custom_css .= '.%1$s .section_testimonial.style-1 .testimonial-item-name {color:%2$s;}' ."\n";
	}
	if( !empty( $atts['position_color'] ) ){
		$custom_css .= '.%1$s .section_testimonial.style-1 .testimonial-item-position {color:%3$s}' ."\n";
	}
	if( !empty( $atts['description_color'] ) ){
		$custom_css .= '.%1$s .section_testimonial.style-1 .testimonial-item-quote {color:%4$s;}' ."\n";
	}
	if( !empty( $atts['bor_color'] ) ){
		$custom_css .= '.%1$s .section_testimonial.style-1 .testimonial-item-img {border-color:%6$s;}' ."\n";
	}
	if( !empty( $atts['nav_color'] ) ) {
		$custom_css .= '.%1$s .section_testimonial.style-1 .carousel-prev, .%1$s .section_testimonial.style-1 .carousel-next {border-color:%7$s;}' ."\n";
		$custom_css .= '.%1$s .section_testimonial.style-1 .carousel-prev i, .%1$s .section_testimonial.style-1 .carousel-next i {color:%7$s;}' ."\n";
	}
	if( !empty( $atts['dot_color'] ) ) {
		$custom_css .= '.%1$s .section_testimonial.style-1 .owl-controls .owl-pagination .owl-page span {border-color:%8$s;}' ."\n";
	}
	if( !empty( $atts['dot_color_hover'] ) ) {
		$custom_css .= '.%1$s .section_testimonial.style-1 .owl-controls .owl-pagination .owl-page.active span,
			.%1$s .section_testimonial.style-1 .owl-controls .owl-pagination .owl-page:hover span {border-color:%9$s;}' ."\n";
	}
} else {
	if( !empty( $atts['name_color'] ) ){
		$custom_css .= '.%1$s .section_testimonial.style-3 .testimonial-item-name {color:%2$s;}' ."\n";
	}
	if( !empty( $atts['position_color'] ) ){
		$custom_css .= '.%1$s .section_testimonial.style-3 .testimonial-item-position {color:%3$s}' ."\n";
	}
	if( !empty( $atts['description_color'] ) ){
		$custom_css .= '.%1$s .section_testimonial.style-3 .testimonial-item-quote {color:%4$s;}' ."\n";
	}
	if( !empty( $atts['bg_color'] ) ){
		$custom_css .= '.%1$s .section_testimonial.style-3 .testimonial-item {background:%5$s;}' ."\n";
	}
	if( !empty( $atts['nav_color'] ) ) {
		$custom_css .= '.%1$s .section_testimonial.style-3 .carousel-prev, .%1$s .section_testimonial.style-3 .carousel-next {border-color:%7$s;}' ."\n";
		$custom_css .= '.%1$s .section_testimonial.style-3 .carousel-prev i, .%1$s .section_testimonial.style-3 .carousel-next i {color:%7$s;}' ."\n";
	}
	if( !empty( $atts['dot_color'] ) ) {
		$custom_css .= '.%1$s .section_testimonial.style-3 .owl-controls .owl-pagination .owl-page span {border-color:%8$s;}' ."\n";
	}
	if( !empty( $atts['dot_color_hover'] ) ) {
		$custom_css .= '.%1$s .%1$s .section_testimonial.style-3 .owl-controls .owl-pagination .owl-page.active span,
			.%1$s .section_testimonial.style-3 .owl-controls .owl-pagination .owl-page:hover span {border-color:%9$s;}' ."\n";
	}
}


if ( !empty( $custom_css ) ) {
	$custom_css = sprintf($custom_css,
			esc_attr($sc_id),
			esc_attr($atts['name_color']),
			esc_attr($atts['position_color']),
			esc_attr($atts['description_color']),
			esc_attr($atts['bg_color']),
			esc_attr($atts['bor_color']),
			esc_attr($atts['nav_color']),
			esc_attr($atts['dot_color']),
			esc_attr($atts['dot_color_hover'])
			);
	do_action( COSMOS_CORE_ADD_INLINE_CSS, $custom_css );
}
?>

<div class="pix-shortcode <?php echo esc_attr("sc-$sc_name");?> <?php  echo esc_attr($block_class) ?> <?php echo esc_attr($css_animation_class); ?>"  data-animate="<?php echo esc_attr($css_animation); ?>" data-delay="<?php echo esc_attr($delay_animation); ?>" data-id="<?php echo esc_attr($sc_id) ?>">
	<div class="js-dynamic-menu section_testimonial <?php echo esc_attr($style_sc) .' '. esc_attr($sc_id) ?>" data-style="<?php echo esc_attr($style_sc) ?>" data-type="bg" data-autoplay="<?php echo esc_attr($atts['autoplay'])?>" data-nav="<?php echo esc_attr($atts['show_nav'])?>" data-item="<?php echo esc_attr($atts['item']) ?>">
		<div class="testimonial-content">
	        <div class="carousel">
	            <div class="carousel-items">
                <?php
                	// %1$s image
                	// %2$s is description
                	// %3$s is name
                	// %4$s is position
	                if($atts['style'] == 1) {
	                	$html_format = ('
	                		<div class="testimonial-item">
		                		<div class="testimonial-item-img">
			                        %1$s
			                    </div>
			                    <div class="testimonial-item-quote">
			                        <p data-type="content"> %2$s </p>
			                    </div>
			                    <div class="testimonial-item-name">
			                        <span data-type="title"> %3$s </span>
			                    </div>
			                    <div class="testimonial-item-position">
			                        <span data-type="title"> %4$s </span>
			                    </div>
		                    </div>
	                	');
	                } else {
	                	$html_format = ('
	                		<div class="testimonial-item">
		                		<div class="testimonial-item-name">
			                        <span data-type="title"> %3$s </span>
			                    </div>
			                    <div class="testimonial-item-position">
			                        <span data-type="title"> %4$s </span>
			                    </div>
			                    <div class="testimonial-item-quote">
			                        <p data-type="content"> %2$s </p>
			                    </div>
		                    </div>
	                	');
	                }
                	$html_option = array(
						'html_format' => $html_format,
					);
					$model->render_testimonial_sc($html_option);
                ?>
	            </div>
	            <div class="carousel-prev" data-type="icon">
	                <i class="fa fa-angle-left" aria-hidden="true"></i>
	            </div>
	            <div class="carousel-next" data-type="icon">
	                <i class="fa fa-angle-right" aria-hidden="true"></i>
	            </div>
	        </div>
	    </div>
	</div>
</div>