<?php
$sc_controller = new Cosmos_Core_Shortcodes_Controller();
$source = array(
	esc_html__( 'Youtube', 'pix-core' ) => 'youtube',
	esc_html__( 'Upload video', 'pix-core' ) => 'video'
);

$button_position = array(
	esc_html__( 'Under text', 'pix-core' ) => 'under',
	esc_html__( 'On text', 'pix-core' ) => 'on'
);

$params = array(
	array(
		'type'        => 'dropdown',
		"class"       => "",
		'heading'     => esc_html__( 'Source video', 'pix-core' ),
		'param_name'  => 'source',
		'value'       => $source,
		'description' => esc_html__( 'Select source video.',  'pix-core'  )
	),
	array(
		'type'          => 'textfield',
		'heading'       => esc_html__( 'Youtube ID', 'pix-core' ),
		'param_name'    => 'youtube_id',
		'description' => sprintf( esc_html__( 'For example: http://www.youtube.com/v/8OBfr46Y0cQ, the ID is %s.', 'pix-core' ), '<b>8OBfr46Y0cQ</b>' ),
		'dependency'     => array(
			'element' => 'source',
			'value'   => array( 'youtube' ),
		),
	),
	array(
		'type'           => 'attach_image',
		'heading'        => esc_html__( 'Upload your video', 'pix-core' ),
		'param_name'     => 'video_upload',
		'description'    => esc_html__( 'Choose video (file mp4) want to upload.', 'pix-core' ),
		'dependency'     => array(
			'element' => 'source',
			'value'   => array( 'video' ),
		),
	),
	array(
		'type'        => 'dropdown',
		"class"       => "",
		'heading'     => esc_html__( 'Button position', 'pix-core' ),
		'param_name'  => 'button_position',
		'value'       => $button_position,
		'description' => esc_html__( 'Select button position.',  'pix-core'  )
	),
	array(
		'type'        => 'textfield',
		'heading'     => esc_html__( 'Title', 'pix-core' ),
		'param_name'  => 'title',
		'description' => esc_html__( 'Enter title', 'pix-core' )
	),
	array(
		'type'        => 'textfield',
		'heading'     => esc_html__( 'Sub title', 'pix-core' ),
		'param_name'  => 'sub_title',
		'description' => esc_html__( 'Enter sub title', 'pix-core' )
	),
	array(
		"type"        => "textarea",
		"holder"      => "div",
		"class"       => "",
		"heading"     => esc_html__( "Description", 'pix-core' ),
		"param_name"  => "description",
		"description" => esc_html__( "Enter description here", 'pix-core' )
	),
	array(
		'type'           => 'attach_image',
		'heading'        => esc_html__( 'Add background image video', 'pix-core' ),
		'param_name'     => 'image_background',
		'description'    => esc_html__( 'Choose background image to add.', 'pix-core' ),
	),
	array(
		'type'        => 'textfield',
		'heading'     => esc_html__( 'Height video', 'pix-core' ),
		'param_name'  => 'height_video',
		'description' => esc_html__( 'Enter height video. Example: 200px or 100%', 'pix-core' )
	),
	array(
		"type"        => "colorpicker",
		"class"       => "",
		"heading"     => esc_html__( "Title Color", 'pix-core' ),
		"param_name"  => "title_color",
		"description" => esc_html__( "Choose title color.", 'pix-core' ),
		'group'       => esc_html__('Options', 'pix-core')
	),
	array(
		"type"        => "colorpicker",
		"class"       => "",
		"heading"     => esc_html__( "Sub title Color", 'pix-core' ),
		"param_name"  => "sub_title_color",
		"description" => esc_html__( "Choose sub title color.", 'pix-core' ),
		'group'       => esc_html__('Options', 'pix-core')
	),
	array(
		"type"        => "colorpicker",
		"class"       => "",
		"heading"     => esc_html__( "Description Color", 'pix-core' ),
		"param_name"  => "description_color",
		"description" => esc_html__( "Choose the color for text in description.", 'pix-core' ),
		'group'       => esc_html__('Options', 'pix-core'),
	),
	array(
		"type"        => "colorpicker",
		"class"       => "",
		"heading"     => esc_html__( "Button Color", 'pix-core' ),
		"param_name"  => "button_color",
		"description" => esc_html__( "Choose button color.", 'pix-core' ),
		'group'       => esc_html__('Options', 'pix-core'),
	),
	array(
		"type"        => "colorpicker",
		"class"       => "",
		"heading"     => esc_html__( "Button hover Color", 'pix-core' ),
		"param_name"  => "button_hover_color",
		"description" => esc_html__( "Choose button hover color.", 'pix-core' ),
		'group'       => esc_html__('Options', 'pix-core'),
	),
	array(
		'type'            => 'textfield',
		'heading'         => esc_html__( 'Extra Class', 'pix-core' ),
		'param_name'      => 'extra_class',
		'description'     => esc_html__( 'Style particular content element differently - add a class name and refer to it in custom CSS.', 'pix-core' )
	),
	$sc_controller->cosmos_animation_style(),
	$sc_controller->cosmos_animation_delay(),

);

vc_map(
	array(
		"name"			=> esc_html__( 'PIX Video', 'pix-core' ),
		"base"			=> "pixcore_video_sc",
		"class"			=> "pixcore-sc",
		"category"		=> COSMOS_CORE_SC_CATEGORY,
		'icon'			=> 'icon-pixcore_video_sc',
		"description"	=> esc_html__( 'Embed video', 'pix-core' ),
		"params"		=> $params
	)
);
