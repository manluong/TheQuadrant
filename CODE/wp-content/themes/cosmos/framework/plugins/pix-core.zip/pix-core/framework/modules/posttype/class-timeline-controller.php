<?php

/**
 * Time Controller
 *
 * @since 1.0
 */

Cosmos_Core::load_class( 'Abstract' );

class Cosmos_Core_Timeline_Controller extends Cosmos_Core_Abstract {

	public function save() {
		global $post;
		$post_id = $post->ID;
		parent::save();
		if( isset( $_POST['cosmos_timeline_meta']) ) {
			$data_meta = $_POST['cosmos_timeline_meta'];
			foreach( $data_meta as $key => $value ) {				
				update_post_meta ( $post_id, $key, $value );
			}
		}
		do_action( 'cosmos_core_save_feature_video', $post_id );
	}

	public function metabox_timeline_options() {
		global $post;
		$post_id = $post->ID;
		$obj_prop = new Cosmos_Core_Timeline();
		$obj_prop->loop_index();
		$data_meta = $obj_prop->post_meta;
		$this->render( 'timeline', array( 'data_meta' => $data_meta ) );
	}
}