<?php
class Cosmos_Core_Testimonial extends Cosmos_Core_Custom_Post_Model{

	private $post_type = 'cosmos_testi';
	private $post_taxonomy = 'cosmos_testi_cat';
	public $html_format;

	public function __construct(){
		$this->meta_attributes();
		$this->set_meta_attributes();
		$this->post_meta_prefix = $this->post_type . '_';
		$this->taxonomy_cat = $this->post_taxonomy;
	}
	public function meta_attributes(){
		$meta_atts = array(
			'position'=> esc_html__( 'Position', 'pix-core' ),
			'quote'       => esc_html__('Quote', 'pix-core')
		);
		$this->post_meta_atts = $meta_atts;
	}
	public function set_meta_attributes(){
		$meta_arr = array();
		$meta_label_arr = array();
		foreach ( $this->post_meta_atts as $att => $name ){
			$key = $att;
			$meta_arr[$key] = '';
			$meta_label_arr[$key] = $name;
		}
		$this->post_meta_def = $meta_arr;
		$this->post_meta = $meta_arr;
		$this->post_meta_label = $meta_label_arr;
	}
	public function init( $atts = array(), $query_args = array() ){
		// set attributes
		$default_atts = array(
			'layout'     => 'testimonial',
			'limit_post' => '',
			'offset_post'=> '',
			'sort_by'    => '',
			'post_id'    => '',
		);
		$atts = array_merge( $default_atts, $atts );
		if ( $atts['method'] == 'cat' ){
			$atts['post_id'] = $this->parse_cat_slug_to_post_id(
				$this->taxonomy_cat,
				$atts['category_list'],
				$this->post_type
			);
		}
		elseif ($atts['method'] == 'testi'){
			$atts['post_id'] = $this->parse_list_to_array( 'post_id', $atts['testi_list'] );
		}
		$this->attributes = $atts;

		// query
		$default_args = array(
			'post_type'=> $this->post_type,
		);
		$query_args = array_merge( $default_args, $query_args );
		// setting
		$this->setting( $query_args);
	}
	public function setting( $query_args ){
		if ( !isset( $this->attributes['uniq_id'] ) ){
			$this->attributes['uniq_id'] = $this->post_type . '-' .Cosmos_Core::make_id();
		}
		// query
		$this->query = $this->get_query( $query_args, $this->attributes );
		$this->post_count = 0;
		if ( $this->query->have_posts() ){
			$this->post_count = $this->query->post_count;
		}
		// image size
		$this->get_thumb_size();
		$custom_css = $this->add_custom_css();
		if( $custom_css ) {
			do_action( COSMOS_CORE_ADD_INLINE_CSS, $custom_css );
		}
	}
	public function reset(){
		wp_reset_postdata();
	}
	public function add_custom_css(){
		$sc_id = $this->attributes['uniq_id'];
		$custom_css = '';
		return $custom_css;
	}
	public function set_default_options( & $html_options = array() ){
		$defaults = array(
		);
		$html_options = array_merge( $defaults, $html_options );
		return $html_options;
	}
	public function get_thumb_size(){
		$params = Cosmos_Core_Params::get( 'block_image_size', $this->attributes['layout'] );
		$this->attributes['thumb-size'] = Cosmos_Core_Util::get_thumb_size( $params, $this->attributes );
	}

	/* Render HTML*/
	public function render_testimonial_sc( $html_options = array() ) {
		$this->html_format = $this->set_default_options( $html_options );
		if( $this->query->have_posts() ) {
			while ( $this->query->have_posts() ) {
				$this->query->the_post();
				$this->loop_index();
				$html_options = $this->html_format;

				printf( $html_options['html_format'],
					$this->get_featured_image(),
					$this->get_meta_quote(),
					$this->get_title( $html_options),
					$this->get_meta_position()
				);
			}
			$this->reset();
		}
	}

	/*custom function*/
	public function get_meta_position(){
		$out = $this->post_meta['position'];
		if ( empty( $out ) ){
			return '';
		}
		return $out;
	}
	public function get_meta_quote(){
		$format = '%1$s';
		if ( isset($this->html_format['quote']) ){
			$format = $this->html_format['quote'];
		}
		$val = $this->post_meta['quote'];

		$out = '';
		if ( !empty($val) ){
			$out = sprintf( $format, esc_html( $val ) );
		}
		return $out;
	}
}