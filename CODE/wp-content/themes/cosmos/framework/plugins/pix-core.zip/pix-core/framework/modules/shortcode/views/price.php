<?php
$model = new Cosmos_Core_Price();
$model->init( $atts );
$custom_css = "";
$sc_name    = 'price';
$sc_id      = $model->attributes['uniq_id'];
$block_class= $atts['extra_class'] . ' ' . $sc_id;

$css_animation = '';
$css_animation_class = '';
$delay_animation = 0;
$css_animation_parent = '';
$css_animation_parent_class = '';
$delay_animation_parent = 0;

if ( !empty($model->attributes['css_animation']) && !empty($model->attributes['is_parent_animation']) && $model->attributes['is_parent_animation'] != 'yes') {
	$css_animation = $model->attributes['css_animation'];
	$css_animation_class = 'animate-run';
	$delay_animation = (int) $model->attributes['delay_animation'];
}

if ( !empty($model->attributes['css_animation']) && !empty($model->attributes['is_parent_animation']) && $model->attributes['is_parent_animation'] == 'yes') {
	$css_animation_parent = $model->attributes['css_animation'].'-children';
	$css_animation_parent_class = 'animate-run';
	$delay_animation_parent = (int) $model->attributes['delay_animation'];
}


$style    = $model->attributes['style'];
$autoplay = $model->attributes['autoplay'];
$item     = $model->attributes['item'];
$show_nav = $model->attributes['show_nav'];

$color_bg_hover      = $model->attributes['color_bg_hover'];
$color_text_hover    = $model->attributes['color_text_hover'];
$color_text_featured = $model->attributes['color_text_featured'];
$color_bg_featured   = $model->attributes['color_bg_featured'];

$title_color        = $model->attributes['title_color'];
$description_color  = $model->attributes['description_color'];
$price_color        = $model->attributes['price_color'];
$attributes_color   = $model->attributes['attributes_color'];
$attributes_color_border   = $model->attributes['attributes_color_border'];
$unit_color         = $model->attributes['unit_color'];
$item_bg_color      = $model->attributes['item_bg_color'];
$color_border_box 	= $model->attributes['color_border_box'];
$color_button 		= $model->attributes['color_button'];
$color_button_hv 	= $model->attributes['color_button_hv'];
$color_button_border = $model->attributes['color_button_border'];
$color_button_border_hv = $model->attributes['color_button_border_hv'];
$color_button_bg 	= $model->attributes['color_button_bg'];
$color_button_bg_hv	= $model->attributes['color_button_bg_hv'];
$price_font_size    = $model->attributes['price_font_size'];
$currency_font_size = $model->attributes['currency_font_size'];

$custom_css = '';
if ($style == 1 && $item == 4) {
	$custom_css .= sprintf('.%1$s .section_pricing.style-1 .option1-content .list-group {
    padding-left: 10px; padding-right: 10px; }', esc_attr($sc_id) );
}
if ($style == 2 && $item == 4) {
	$custom_css .= sprintf('.%1$s .section_pricing.style-2 .option2-content .list-group {
    padding-left: 10px; padding-right: 10px; }', esc_attr($sc_id) );
}
if ( ! empty( $price_font_size ) ) {
    $custom_css .= sprintf('.%1$s .section_pricing .slide-item .rate .row-edit.number, .%1$s .section_pricing .slide-item div.btn1.price span.price {font-size: %2$s;}', esc_attr($sc_id), esc_attr(floatval($price_font_size)) );
}
if ( ! empty( $currency_font_size ) ) {
    $custom_css .= sprintf('.%1$s .section_pricing .slide-item .rate .row-edit.sup, .%1$s .section_pricing .slide-item div.btn1.price span.currency {font-size: %2$s;}', esc_attr($sc_id), esc_attr(floatval($currency_font_size)) );
}
if ( ! empty( $color_bg_hover) ) {
    $custom_css .= sprintf('.%1$s .section_pricing .slide-item:hover .button, .%1$s .section_pricing.style-1 .option1-content .slide-item:hover .rate, .%1$s .section_pricing.style-3 .option3-content .option3 .slide-item:hover .name, .%1$s .section_pricing.style-3 .option3-content .option3 .slide-item:hover .button {background-color: %2$s;}', esc_attr($sc_id), esc_attr($color_bg_hover) );
}
if ( ! empty( $color_text_hover) ) {
    $custom_css .= sprintf('.%1$s .section_pricing .slide-item:hover .button, .%1$s .section_pricing.style-1 .option1-content .slide-item:hover .rate, .%1$s .section_pricing.style-1 .option1-content .slide-item:hover .row-edit.sup, .%1$s .section_pricing.style-1 .option1-content .slide-item:hover .row-edit.sub, .%1$s .section_pricing.style-1 .option1-content .slide-item:hover .row-edit.number, .%1$s .section_pricing.style-2 .option2-content .slide-item:hover .rate, .%1$s .section_pricing.style-2 .option2-content .slide-item:hover span.row-edit.number, .%1$s .section_pricing.style-2 .option2-content .slide-item:hover .row-edit.sup, .%1$s .section_pricing.style-3 .option3-content .option3 .slide-item:hover .name, .%1$s .section_pricing.style-3 .option3-content .option3 .slide-item:hover .button {color: %2$s;}', esc_attr($sc_id), esc_attr($color_text_hover) );
}
if ( ! empty( $color_text_featured ) ) {
    $custom_css .= sprintf('.%1$s .section_pricing.style-1 .choice-text, .%1$s .section_pricing.style-2 .choice-text,
    .%1$s .section_pricing.style-3 .choice-text, .%1$s .section_pricing.style-4 .choice-text, .%1$s .section_pricing.style-5 .choice-text {color: %2$s;}', esc_attr($sc_id), esc_attr($color_text_featured) );
}
if ( ! empty( $color_bg_featured ) ) {
    $custom_css .= sprintf('.%1$s .section_pricing.style-1 .choice-text, .%1$s .section_pricing.style-2 .choice-text,
    .%1$s .section_pricing.style-3 .choice-text, .%1$s .section_pricing.style-4 .choice-text, .%1$s .section_pricing.style-5 .choice-text {background-color: %2$s;}', esc_attr($sc_id), esc_attr($color_bg_featured) );
}

if ( ! empty( $title_color ) ) {
    $custom_css .= sprintf('.%1$s .section_pricing .slide-item div.row-edit.name {color: %2$s;}', esc_attr($sc_id), esc_attr($title_color) );
}
if ( ! empty( $description_color ) ) {
    $custom_css .= sprintf('.%1$s .section_pricing.style-1 .choice-text, .%1$s .section_pricing.style-2 .choice-text,
    .%1$s .section_pricing.style-3 .choice-text, .%1$s .section_pricing.style-4 .choice-text, .%1$s .section_pricing.style-5 .choice-text, .%1$s .section_pricing.style-2 .option2-content .slide-item span.row-edit {color: %2$s;}', esc_attr($sc_id), esc_attr($description_color) );
}
if ( ! empty( $price_color ) ) {
    $custom_css .= sprintf('.%1$s .section_pricing .slide-item .rate .row-edit.number, .%1$s .section_pricing .slide-item .rate .row-edit.sup, .%1$s .section_pricing .slide-item div.btn1.price span {color: %2$s;}', esc_attr($sc_id), esc_attr($price_color) );
}
if ( ! empty( $attributes_color ) ) {
    $custom_css .= sprintf('.%1$s .section_pricing .slide-item ul.list-group .row-edit.list-group-item {color: %2$s;}', esc_attr($sc_id), esc_attr($attributes_color) );
}
if ( ! empty( $attributes_color_border ) ) {
    $custom_css .= sprintf('.%1$s .section_pricing .slide-item ul.list-group .list-group-item { border-color: %2$s;}', esc_attr($sc_id), esc_attr($attributes_color_border) );
}
if ( ! empty( $unit_color ) ) {
    $custom_css .= sprintf(' .%1$s .section_pricing .slide-item .row-edit.sub {color: %2$s;}', esc_attr($sc_id), esc_attr($unit_color) );
}
if ( ! empty( $item_bg_color ) ) {
    $custom_css .= sprintf('#%1$s .section_pricing.style-1 .slide-item, #%1$s .section_pricing.style-2 .slide-item, #%1$s .section_pricing.style-3 .slide-item, #%1$s .section_pricing.style-4 .slide-item, #%1$s .section_pricing.style-5 .slide-item { background-color: %2$s;}', esc_attr($sc_id), esc_attr($item_bg_color) );
}
if ( ! empty( $color_border_box ) ) {
    $custom_css .= sprintf('.%1$s .section_pricing.style-1 .slide-item, .%1$s .section_pricing.style-2 .slide-item, .%1$s .section_pricing.style-3 .slide-item, .%1$s .section_pricing.style-4 .slide-item, .%1$s .section_pricing.style-5 .slide-item { border: 1px solid %2$s;}', esc_attr($sc_id), esc_attr($color_border_box) );
}
if ( ! empty( $color_button ) ) {
    $custom_css .= sprintf('.%1$s .section_pricing.style-1 .button, .%1$s .section_pricing.style-2 .button, .%1$s .section_pricing.style-3 .button, .%1$s .section_pricing.style-4 .button, .%1$s .section_pricing.style-5 .button { color: %2$s;}', esc_attr($sc_id), esc_attr($color_button) );
}
if ( ! empty( $color_button_hv ) ) {
    $custom_css .= sprintf('.%1$s .section_pricing.style-1 .slide-item:hover .button, .%1$s .section_pricing.style-2 .slide-item:hover .button, .%1$s .section_pricing.style-3 .slide-item:hover .button, .%1$s .section_pricing.style-4 .slide-item:hover .button, .%1$s .section_pricing.style-5 .slide-item:hover .button { color: %2$s;}', esc_attr($sc_id), esc_attr($color_button_hv) );
}
if ( ! empty( $color_button_border ) ) {
    $custom_css .= sprintf('.%1$s .section_pricing.style-1 .button, .%1$s .section_pricing.style-2 .button, .%1$s .section_pricing.style-3 .button, .%1$s .section_pricing.style-4 .button, .%1$s .section_pricing.style-5 .button { border-color: %2$s;}', esc_attr($sc_id), esc_attr($color_button_border) );
}
if ( ! empty( $color_button_border_hv ) ) {
    $custom_css .= sprintf('.%1$s .section_pricing.style-1 .slide-item:hover .button, .%1$s .section_pricing.style-2 .slide-item:hover .button, .%1$s .section_pricing.style-3 .slide-item:hover .button, .%1$s .section_pricing.style-4 .slide-item:hover .button, .%1$s .section_pricing.style-5 .slide-item:hover .button { border-color: %2$s;}', esc_attr($sc_id), esc_attr($color_button_border_hv) );
}
if ( ! empty( $color_button_bg ) ) {
    $custom_css .= sprintf('.%1$s .section_pricing.style-1 .button, .%1$s .section_pricing.style-2 .button, .%1$s .section_pricing.style-3 .button, .%1$s .section_pricing.style-4 .button, .%1$s .section_pricing.style-5 .button { background-color: %2$s;}', esc_attr($sc_id), esc_attr($color_button_bg) );
}
if ( ! empty( $color_button_bg_hv ) ) {
    $custom_css .= sprintf('.%1$s .section_pricing.style-1 .slide-item:hover .button, .%1$s .section_pricing.style-2 .slide-item:hover .button, .%1$s .section_pricing.style-3 .slide-item:hover .button, .%1$s .section_pricing.style-4 .slide-item:hover .button, .%1$s .section_pricing.style-5 .slide-item:hover .button { background-color: %2$s;}', esc_attr($sc_id), esc_attr($color_button_bg_hv) );
}

if ( !empty( $custom_css ) ) {
	do_action( COSMOS_CORE_ADD_INLINE_CSS, $custom_css );
}
?>

<div id="<?php echo esc_attr($sc_id);?>" class="pix-shortcode <?php echo esc_attr("sc-$sc_name");?> <?php  echo esc_attr($block_class) ?> <?php echo esc_attr($css_animation_class); ?>"  data-animate="<?php echo esc_attr($css_animation); ?>" data-delay="<?php echo esc_attr($delay_animation); ?>" data-id="<?php echo esc_attr($sc_id);?>">
	<div class="section_pricing style-<?php  echo esc_attr($style) ?>" 
		data-type="bg"
		data-item="<?php  echo esc_attr($item) ?>"
		data-autoplay="<?php  echo esc_attr($autoplay) ?>"
		data-shownav="<?php  echo esc_attr($show_nav) ?>" >
        <div class="option<?php  echo esc_attr($style) ?>-content carousel">
            <div class="option<?php  echo esc_attr($style) ?> slider carousel-items">
                <?php 
                	/*
						%1$s is title
						%2$s is price
						%3$s is unit
						%4$s is atts
						%5$s is button
						%6$s is description
						%7$s is featured
					*/
					if ($style == 1) {
						$html_format = ('
							<div class="col-xs-12">
							    <div class="slide-item">
							    	<div class="rate">
							        	%2$s
							        	%3$s
							        </div>
							        %1$s
							        <ul class="list-group">
							            %4$s
							            %5$s
							        </ul>
							    </div>
							</div>
							');
						$price_format = ('<span class="row-edit number" data-type="title">%1$s</span>');
						$currency_format = '<sup class="row-edit sup" data-type="icon">%1$s</sup>';
						$unit_format = '<sub class="row-edit sub" data-type="title">/%1$s</sub>';
					} elseif ($style == 2) {
						$html_format = ('
							<div class="col-xs-12">
							    <div class="slide-item">
							        %1$s
							        %6$s
							        <div class="rate">
							        	%2$s
						        	</div>
							        %3$s
							        <ul class="list-group">
							            %4$s
							            %5$s
							        </ul>
							        %7$s
							    </div>
							</div>
							');
						$price_format = ('<span class="row-edit number" data-type="title">%1$s</span>');
						$currency_format = '<sup class="row-edit sup" data-type="icon">%1$s</sup>';
						$unit_format = '<sub class="row-edit sub" data-type="title">/%1$s</sub>';
					} elseif ($style == 3) {
						$html_format = ('
							<div class="col-xs-12">
							    <div class="slide-item">
							        %1$s
							        <ul class="list-group">
							            %4$s
							            <li>
							            	<div class="btn-group">
							                    <div class="btn1 price">
							            			%2$s
							                    </div>
							                    %3$s
							                </div>
							            </li>
							            %5$s
							        </ul>
							    </div>
							</div>
							');
						$price_format = ('<span class="row-edit price" data-type="title">%1$s</span>');
						$currency_format = '<span class="row-edit currency" data-type="icon">%1$s</span>';
						$unit_format = '<div class="row-edit btn2 sub" data-type="title">' . esc_html__('Per','pix-core') . ' %1$s</div>';
					}
					$html_option = array(
						'html_format'  		=> $html_format,
						'price_format' 		=> $price_format,
						'currency_format' 	=> $currency_format,
						'unit_format' 		=> $unit_format
					);
					$model->render_sc($html_option);
                ?>
            </div>
            <?php if ($show_nav == 'yes') { ?>
            <div class="carousel-prev" data-type="icon"><i class="fa fa-angle-left" aria-hidden="true"></i></div>
            <div class="carousel-next" data-type="icon"><i class="fa fa-angle-right" aria-hidden="true"></i></div>
            <?php } ?>
        </div>
	</div>
</div>