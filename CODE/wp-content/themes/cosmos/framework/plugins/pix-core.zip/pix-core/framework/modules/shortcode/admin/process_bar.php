<?php
$sc_controller = new Cosmos_Core_Shortcodes_Controller();
$style =  array(
	esc_html__('Style 1', 'pix-core') => '1',
	esc_html__('Style 2', 'pix-core') => '2',
);

$column = array(
    esc_html__( 'One', 'pix-core' )  => '1',
    esc_html__( 'Two', 'pix-core' )  => '2',
    esc_html__( 'Three', 'pix-core' )=> '3',
    esc_html__( 'Four', 'pix-core' ) => '4',
);
$params = array(
	array(
		'type'        => 'dropdown',
		'admin_label' => true,
		"class"       => "",
		'heading'     => esc_html__( 'Style', 'pix-core' ),
		'param_name'  => 'style',
		'value'       => $style,
		'description' => esc_html__( 'Choose style.',  'pix-core'  )
	),
    array(
        'type'       => 'dropdown',
        'heading'    => esc_html__( 'Column', 'pix-core' ),
        'param_name' => 'column',
        'value'      => $column,
        'std'        => '1',
        'description'=> esc_html__( 'Choose column number will be displayed.', 'pix-core' ),
        'dependency'    => array(
			'element'		=> 'style',
			'value'         => array( '2' )
		),
    ),
	array(
		'type'       => 'param_group',
		'heading'    => esc_html__( 'Proccess Bar', 'pix-core' ),
		'param_name' => 'process_content',
		'callbacks'   => array(
		   'after_add' => 'vcChartParamAfterAddCallback'
		),
		'params'     => array(
			array(
				'type'        => 'textfield',
				'admin_label' => true,
				"class"       => "",
				'heading'     => esc_html__( 'Title', 'pix-core' ),
				'param_name'  => 'title',
				'value'       => '',
				'description' => esc_html__( 'Enter title.',  'pix-core'  )
			),
			array(
				'type'        => 'textfield',
				'admin_label' => true,
				"class"       => "",
				'heading'     => esc_html__( 'Number of percent', 'pix-core' ),
				'param_name'  => 'number',
				'value'       => '',
				'description' => esc_html__( "Enter number of percent here", 'pix-core' )
			),
		),
	),

	array(
		"type"        => "colorpicker",
		"class"       => "",
		"heading"     => esc_html__( "Title Color", 'pix-core' ),
		"param_name"  => "title_color",
		"description" => esc_html__( "Choose the title color.", 'pix-core' ),
		'group'       => esc_html__('Options', 'pix-core'),
	),
	array(
		"type"        => "colorpicker",
		"class"       => "",
		"heading"     => esc_html__( "Number Color", 'pix-core' ),
		"param_name"  => "number_color",
		"description" => esc_html__( "Choose the number color.", 'pix-core' ),
		'group'       => esc_html__('Options', 'pix-core'),
	),
	array(
		"type"        => "colorpicker",
		"class"       => "",
		"heading"     => esc_html__( "Border Color", 'pix-core' ),
		"param_name"  => "border_color",
		"description" => esc_html__( "Choose the border color.", 'pix-core' ),
		'group'       => esc_html__('Options', 'pix-core'),
		'dependency'    => array(
			'element'		=> 'style',
			'value'         => array( '1' )
		),
	),
	array(
		"type"        => "colorpicker",
		"class"       => "",
		"heading"     => esc_html__( "Process Color", 'pix-core' ),
		"param_name"  => "process_color",
		"description" => esc_html__( "Choose the process color.", 'pix-core' ),
		'group'       => esc_html__('Options', 'pix-core'),
	),
	array(
		"type"        => "colorpicker",
		"class"       => "",
		"heading"     => esc_html__( "Not Process Color", 'pix-core' ),
		"param_name"  => "not_process_color",
		"description" => esc_html__( "Choose color for not process.", 'pix-core' ),
		'group'       => esc_html__('Options', 'pix-core'),
	),
	array(
		'type'            => 'textfield',
		'heading'         => esc_html__( 'Extra Class', 'pix-core' ),
		'param_name'      => 'extra_class',
		'description'     => esc_html__( 'Style particular content element differently - add a class name and refer to it in custom CSS.', 'pix-core' )
	),
	$sc_controller->cosmos_animation_style(),
	$sc_controller->cosmos_animation_delay(),

);

vc_map(
	array(
		"name"			=> esc_html__( 'PIX Process Bar', 'pix-core' ),
		"base"			=> "pixcore_process_bar_sc",
		"class"			=> "pixcore-sc",
		"category"		=> COSMOS_CORE_SC_CATEGORY,
		'icon'			=> 'icon-pixcore_process_bar_sc',
		"description"	=> esc_html__( 'Process bar.', 'pix-core' ),
		"params"		=> $params
	)
);